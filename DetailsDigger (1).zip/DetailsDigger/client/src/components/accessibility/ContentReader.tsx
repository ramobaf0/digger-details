import React, { useRef, useState, ReactNode, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Volume2, Square } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';

interface ContentReaderProps {
  children: ReactNode;
  title?: string;
  className?: string;
  badgeText?: string;
}

const ContentReader: React.FC<ContentReaderProps> = ({ 
  children, 
  title,
  className,
  badgeText = "Accessibility"
}) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const contentRef = useRef<HTMLDivElement>(null);
  const synthRef = useRef<SpeechSynthesis | null>(null);
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);

  useEffect(() => {
    // Check if browser supports speech synthesis
    if (typeof window !== 'undefined' && window.speechSynthesis) {
      synthRef.current = window.speechSynthesis;
    }
  }, []);

  // Function to extract readable text from the DOM node
  const extractTextFromContent = () => {
    if (!contentRef.current) return '';

    // Clone the node to avoid modifying the original DOM
    const clone = contentRef.current.cloneNode(true) as HTMLElement;
    
    // Remove elements that shouldn't be read (e.g., buttons, icons)
    const unwantedElements = clone.querySelectorAll('button, svg, .sr-only, [aria-hidden="true"]');
    unwantedElements.forEach(el => el.parentNode?.removeChild(el));
    
    // Get text content and clean it up
    let text = clone.textContent || '';
    
    // Add the title at the beginning if available
    if (title) {
      text = `${title}. ${text}`;
    }
    
    return text
      .replace(/\s+/g, ' ') // Replace multiple spaces with a single space
      .trim();
  };

  const handleSpeak = () => {
    if (!synthRef.current) return;
    
    if (isPlaying) {
      synthRef.current.cancel();
      setIsPlaying(false);
      return;
    }
    
    const textToRead = extractTextFromContent();
    if (!textToRead) return;
    
    // Create a new utterance for this specific content
    utteranceRef.current = new SpeechSynthesisUtterance(textToRead);
    utteranceRef.current.rate = 0.9; // Slightly slower for better comprehension
    utteranceRef.current.onend = () => setIsPlaying(false);
    
    setIsPlaying(true);
    synthRef.current.speak(utteranceRef.current);
  };

  return (
    <div className={cn("relative", className)}>
      <div className="absolute top-2 right-2 z-10 flex gap-2">
        <Badge variant="outline" className="bg-white/90 dark:bg-black/70 text-xs">
          {badgeText}
        </Badge>
        <Button
          variant="secondary"
          size="icon"
          className="h-8 w-8 rounded-full bg-white/90 dark:bg-black/70 shadow-sm"
          onClick={handleSpeak}
          aria-label={isPlaying ? "Stop reading" : "Read this content aloud"}
        >
          {isPlaying ? <Square className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
        </Button>
      </div>

      <div ref={contentRef} className="content-reader-text">
        {children}
      </div>
    </div>
  );
};

export default ContentReader;