import React, { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { VolumeIcon, Square } from 'lucide-react';

interface VoiceOverProps {
  text: string;
  label?: string;
}

const VoiceOver: React.FC<VoiceOverProps> = ({ text, label = 'Read aloud' }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const synthRef = useRef<SpeechSynthesis | null>(null);
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);

  useEffect(() => {
    // Check if browser supports speech synthesis
    if (typeof window !== 'undefined' && window.speechSynthesis) {
      synthRef.current = window.speechSynthesis;
      
      // Create speech utterance object
      utteranceRef.current = new SpeechSynthesisUtterance(text);
      utteranceRef.current.rate = 0.9; // Slightly slower for better comprehension
      
      // Event handler for when speech ends
      utteranceRef.current.onend = () => {
        setIsPlaying(false);
      };
      
      // Cleanup function
      return () => {
        if (synthRef.current && synthRef.current.speaking) {
          synthRef.current.cancel();
        }
      };
    }
  }, [text]);

  const handleSpeak = () => {
    if (!synthRef.current || !utteranceRef.current) return;
    
    if (isPlaying) {
      synthRef.current.cancel();
      setIsPlaying(false);
      return;
    }
    
    setIsPlaying(true);
    synthRef.current.speak(utteranceRef.current);
  };

  return (
    <div className="inline-flex items-center my-2 relative" aria-live="polite">
      <Button
        variant="outline"
        size="sm"
        onClick={handleSpeak}
        className="flex items-center gap-2 text-sm rounded-md"
        aria-label={isPlaying ? "Stop reading" : "Read this content aloud"}
      >
        {isPlaying ? (
          <>
            <Square className="h-4 w-4" />
            <span>Stop</span>
          </>
        ) : (
          <>
            <VolumeIcon className="h-4 w-4" />
            <span>{label}</span>
          </>
        )}
      </Button>
    </div>
  );
};

export default VoiceOver;