import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { useQuery } from "@tanstack/react-query";
import { TimelineEvent } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";

interface TimelineProps {
  showControls?: boolean;
  limit?: number;
}

const Timeline = ({ showControls = true, limit }: TimelineProps) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [filter, setFilter] = useState("all");

  const { data: events, isLoading } = useQuery<TimelineEvent[]>({
    queryKey: ["/api/timeline"],
  });

  if (isLoading) {
    return (
      <div className="space-y-8">
        {[1, 2, 3, 4].map((i) => (
          <div key={i} className="relative flex flex-col md:flex-row">
            <div className="md:w-1/2 md:pr-12 md:text-right mb-4 md:mb-0">
              <Skeleton className="h-32 w-full rounded-lg" />
            </div>
            <div className="md:w-1/2 md:pl-12 ml-6 md:ml-0">
              <div className="absolute left-0 md:left-1/2 transform -translate-x-1/2 w-6 h-6 rounded-full bg-secondary border-4 border-primary"></div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  const filteredEvents = events
    ? events.filter((event) => filter === "all" || event.category === filter)
    : [];
    
  const displayEvents = limit && !isExpanded ? filteredEvents.slice(0, limit) : filteredEvents;

  return (
    <div>
      {showControls && (
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl lg:text-3xl font-heading font-bold">Historical Timeline</h2>
          <div className="flex gap-2">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => setFilter(filter === "all" ? "political" : "all")}
            >
              <span className="mr-2">Filter</span>
              {filter !== "all" && <span className="text-xs bg-primary/10 px-2 py-1 rounded">{filter}</span>}
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => setIsExpanded(!isExpanded)}
            >
              {isExpanded ? "Collapse" : "Expand All"}
            </Button>
          </div>
        </div>
      )}
      
      <div className="relative">
        {/* Timeline line */}
        <div className="absolute left-0 md:left-1/2 transform md:-translate-x-1/2 w-1 h-full bg-primary"></div>
        
        {/* Timeline events */}
        <div className="space-y-8">
          {displayEvents.map((event, index) => (
            <div key={event.id} className="relative flex flex-col md:flex-row">
              {index % 2 === 0 ? (
                <>
                  <div className="md:w-1/2 md:pr-12 md:text-right mb-4 md:mb-0">
                    <div className="bg-white p-4 rounded-lg shadow-md">
                      <h3 className="font-heading font-bold text-lg">{event.year}: {event.title}</h3>
                      <p className="text-sm">{event.description}</p>
                    </div>
                  </div>
                  <div className="md:w-1/2 md:pl-12 ml-6 md:ml-0">
                    <div className="absolute left-0 md:left-1/2 transform -translate-x-1/2 w-6 h-6 rounded-full bg-secondary border-4 border-primary"></div>
                  </div>
                </>
              ) : (
                <>
                  <div className="md:w-1/2 md:pr-12 md:text-right invisible md:visible"></div>
                  <div className="md:w-1/2 md:pl-12 ml-6 md:ml-0">
                    <div className="absolute left-0 md:left-1/2 transform -translate-x-1/2 w-6 h-6 rounded-full bg-secondary border-4 border-primary"></div>
                    <div className="bg-white p-4 rounded-lg shadow-md">
                      <h3 className="font-heading font-bold text-lg">{event.year}: {event.title}</h3>
                      <p className="text-sm">{event.description}</p>
                    </div>
                  </div>
                </>
              )}
            </div>
          ))}
        </div>
      </div>
      
      {limit && filteredEvents.length > limit && !isExpanded && (
        <div className="mt-6 text-center">
          <Button 
            variant="outline" 
            className="text-primary border-primary"
            onClick={() => setIsExpanded(true)}
          >
            View Detailed Timeline
          </Button>
        </div>
      )}
    </div>
  );
};

export default Timeline;
