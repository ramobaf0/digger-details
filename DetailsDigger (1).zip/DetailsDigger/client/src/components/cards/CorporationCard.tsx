import { Link } from "wouter";
import { ArrowRight } from "lucide-react";
import { Corporation } from "@shared/schema";

interface CorporationCardProps {
  corporation: Corporation;
}

const CorporationCard = ({ corporation }: CorporationCardProps) => {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <div className="bg-primary text-white py-3 px-4">
        <h3 className="font-heading font-bold text-xl">{corporation.name}</h3>
        <p className="text-sm">{corporation.industry}</p>
      </div>
      <div className="p-4">
        <div className="mb-3">
          <h4 className="font-semibold text-secondary">Role in Apartheid</h4>
          <p className="text-sm">{corporation.apartheidRole}</p>
        </div>
        <div className="mb-3">
          <h4 className="font-semibold text-secondary">Post-1994</h4>
          <p className="text-sm">{corporation.post1994}</p>
        </div>
        <Link href={`/corporations/${corporation.id}`}>
          <button className="mt-2 text-primary font-semibold hover:underline text-sm flex items-center">
            <span>View detailed profile</span>
            <ArrowRight className="ml-1 h-4 w-4" />
          </button>
        </Link>
      </div>
    </div>
  );
};

export default CorporationCard;
