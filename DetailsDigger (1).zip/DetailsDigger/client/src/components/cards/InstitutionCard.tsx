import { Institution } from "@shared/schema";

interface InstitutionCardProps {
  institution: Institution;
}

const InstitutionCard = ({ institution }: InstitutionCardProps) => {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <div className="bg-secondary text-white py-3 px-4">
        <h3 className="font-heading font-bold text-xl">{institution.name}</h3>
      </div>
      <div className="p-4">
        <div className="mb-4">
          <h4 className="font-semibold text-primary">Historical Role</h4>
          <p className="text-sm">{institution.historicalRole}</p>
        </div>
        <div className="mb-4">
          <h4 className="font-semibold text-primary">Current Impact</h4>
          <p className="text-sm">{institution.currentImpact}</p>
        </div>
        <div>
          <h4 className="font-semibold text-primary">Key Facts</h4>
          <ul className="text-sm list-disc pl-5">
            <li>Established: {institution.established}</li>
            <li>Transformation status: {institution.transformationStatus}</li>
            <li>Key areas of influence: {institution.areasOfInfluence}</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default InstitutionCard;
