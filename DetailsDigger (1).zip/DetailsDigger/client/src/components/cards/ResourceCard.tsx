import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Resource } from "@shared/schema";
import { FileText, FileImage, Video } from "lucide-react";

interface ResourceCardProps {
  resource: Resource;
}

const ResourceCard = ({ resource }: ResourceCardProps) => {
  const getIconClassName = (type: string) => {
    switch (type) {
      case "pdf":
        return "text-secondary";
      case "presentation":
        return "text-secondary";
      case "video":
        return "text-secondary";
      default:
        return "text-secondary";
    }
  };

  const getIcon = (type: string) => {
    switch (type) {
      case "pdf":
        return <FileText className="h-5 w-5 mr-2" />;
      case "presentation":
        return <FileImage className="h-5 w-5 mr-2" />;
      case "video":
        return <Video className="h-5 w-5 mr-2" />;
      default:
        return <FileText className="h-5 w-5 mr-2" />;
    }
  };
  
  // Determine background color based on category
  let bgColorClass;
  switch (resource.category) {
    case "education":
      bgColorClass = "bg-accent";
      break;
    case "economic":
      bgColorClass = "bg-primary";
      break;
    case "advocacy":
      bgColorClass = "bg-secondary";
      break;
    default:
      bgColorClass = "bg-primary";
  }

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <div className={`h-40 ${bgColorClass} flex items-center justify-center`}>
        <div className="text-white text-5xl">
          {resource.icon}
        </div>
      </div>
      <div className="p-4">
        <h3 className="font-heading font-bold text-lg mb-2">{resource.title}</h3>
        <p className="text-sm mb-4">{resource.description}</p>
        <ul className="text-sm space-y-2 mb-4">
          {resource.files.map((file, index) => (
            <li key={index} className="flex items-center">
              {getIcon(file.type)}
              <span>{file.name}</span>
            </li>
          ))}
        </ul>
        <Link href={`/resources/${resource.id}`}>
          <Button className={`w-full py-2 ${bgColorClass}`}>
            Download Resources
          </Button>
        </Link>
      </div>
    </div>
  );
};

export default ResourceCard;
