import { Link, useLocation } from "wouter";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Button } from "@/components/ui/button";
import { X } from "lucide-react";

interface SidebarProps {
  isOpen: boolean;
  toggleSidebar: () => void;
}

const Sidebar = ({ isOpen, toggleSidebar }: SidebarProps) => {
  const [location] = useLocation();

  const sidebarClasses = `${
    isOpen
      ? "fixed top-0 left-0 h-full z-50 w-64 lg:relative"
      : "hidden lg:block"
  } w-64 bg-white shadow-lg`;

  return (
    <aside className={sidebarClasses}>
      <ScrollArea className="h-screen">
        <div className="p-4">
          <div className="flex justify-between items-center mb-4 lg:hidden">
            <h2 className="font-heading text-xl font-bold">Explore Content</h2>
            <Button variant="ghost" size="sm" onClick={toggleSidebar}>
              <X className="h-5 w-5" />
            </Button>
          </div>
          <div className="hidden lg:block">
            <h2 className="font-heading text-xl font-bold mb-4">Explore Content</h2>
          </div>
          <div className="space-y-4">
            <div>
              <h3 className="font-semibold mb-2 text-primary">Educational Modules</h3>
              <ul className="pl-2 space-y-2">
                <li>
                  <Link href="/">
                    <div className="hover:text-secondary cursor-pointer text-red-600 font-semibold">We Are Not Your Survival Tools</div>
                  </Link>
                </li>
                <li>
                  <Link href="/#timeline">
                    <div className="hover:text-secondary cursor-pointer">Historical Timeline</div>
                  </Link>
                </li>
                <li>
                  <Link href="/#corporations">
                    <div className="hover:text-secondary cursor-pointer">Corporate Profiteers</div>
                  </Link>
                </li>
                <li>
                  <Link href="/#education">
                    <div className="hover:text-secondary cursor-pointer">Educational Institutions</div>
                  </Link>
                </li>
                <li>
                  <Link href="/youth-empowerment">
                    <div className="hover:text-secondary cursor-pointer text-accent font-semibold">Youth Empowerment Guide</div>
                  </Link>
                </li>
                <li>
                  <Link href="/#about">
                    <div className="hover:text-secondary cursor-pointer">About This Project</div>
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-2 text-primary">Self-Reliance Resources</h3>
              <ul className="pl-2 space-y-2">
                <li>
                  <Link href="/resources/1">
                    <div className="hover:text-secondary cursor-pointer">Community Education</div>
                  </Link>
                </li>
                <li>
                  <Link href="/resources/2">
                    <div className="hover:text-secondary cursor-pointer">Economic Initiatives</div>
                  </Link>
                </li>
                <li>
                  <Link href="/resources/3">
                    <div className="hover:text-secondary cursor-pointer">Advocacy Tools</div>
                  </Link>
                </li>
                <li>
                  <Link href="/cultural-preservation">
                    <div className="hover:text-secondary cursor-pointer">Cultural Preservation</div>
                  </Link>
                </li>
                <li>
                  <Link href="/modern-fraudsters">
                    <div className="hover:text-secondary cursor-pointer text-red-600 font-semibold">Modern Apartheid Fraudsters</div>
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-2 text-primary">Tools & Downloads</h3>
              <ul className="pl-2 space-y-2">
                <li>
                  <Link href="/api/resources/download/1/ce1">
                    <div className="hover:text-secondary cursor-pointer">Teaching Materials</div>
                  </Link>
                </li>
                <li>
                  <Link href="/api/resources/download/2/ei1">
                    <div className="hover:text-secondary cursor-pointer">Economic Research Papers</div>
                  </Link>
                </li>
                <li>
                  <Link href="/api/resources/download/3/ap1">
                    <div className="hover:text-secondary cursor-pointer">Policy Templates</div>
                  </Link>
                </li>
                <li>
                  <Link href="/api/resources/download/4/cp2">
                    <div className="hover:text-secondary cursor-pointer">Digital Archive</div>
                  </Link>
                </li>
              </ul>
            </div>
            <div className="pt-4 border-t">
              <Button variant="secondary" className="w-full">
                Contribute Resources
              </Button>
            </div>
          </div>
        </div>
      </ScrollArea>
    </aside>
  );
};

export default Sidebar;
