import { Link } from "wouter";
import { Home, History, Building, Landmark, AlertTriangle, Users, BookOpen } from "lucide-react";

const MobileNavigation = () => {
  return (
    <div className="lg:hidden fixed bottom-0 left-0 right-0 bg-white shadow-[0_-2px_10px_rgba(0,0,0,0.1)] z-50">
      <div className="flex flex-wrap justify-between px-2 py-2">
        <Link href="/">
          <div className="flex flex-col items-center p-2">
            <AlertTriangle className="h-5 w-5 text-red-600" />
            <span className="text-xs mt-1 text-red-600">Fraud Alert</span>
          </div>
        </Link>
        <Link href="/timeline">
          <div className="flex flex-col items-center p-2">
            <History className="h-5 w-5 text-primary" />
            <span className="text-xs mt-1">Timeline</span>
          </div>
        </Link>
        <Link href="/youth-empowerment">
          <div className="flex flex-col items-center p-2">
            <Users className="h-5 w-5 text-primary" />
            <span className="text-xs mt-1">Youth</span>
          </div>
        </Link>
        <Link href="/corporations">
          <div className="flex flex-col items-center p-2">
            <Building className="h-5 w-5 text-primary" />
            <span className="text-xs mt-1">Corporations</span>
          </div>
        </Link>
        <Link href="/cultural-preservation">
          <div className="flex flex-col items-center p-2">
            <Landmark className="h-5 w-5 text-primary" />
            <span className="text-xs mt-1">Culture</span>
          </div>
        </Link>
        <Link href="/resources/1">
          <div className="flex flex-col items-center p-2">
            <BookOpen className="h-5 w-5 text-primary" />
            <span className="text-xs mt-1">Resources</span>
          </div>
        </Link>
      </div>
    </div>
  );
};

export default MobileNavigation;
