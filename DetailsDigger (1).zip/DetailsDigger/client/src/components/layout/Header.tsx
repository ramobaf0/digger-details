import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, User } from "lucide-react";

const Header = () => {
  const [location, setLocation] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setLocation(`/search?q=${encodeURIComponent(searchQuery)}`);
    }
  };

  return (
    <header className="bg-primary text-white shadow-md sticky top-0 z-50">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center gap-3">
          <Link href="/">
            <div className="text-2xl font-heading font-bold cursor-pointer">South African Legacy</div>
          </Link>
        </div>
        <div className="flex items-center gap-3">
          <Button variant="secondary" size="sm" className="hidden md:flex">
            Download Resources
          </Button>
          <div className="relative">
            <Button variant="ghost" size="sm" className="flex items-center gap-2">
              <User className="h-5 w-5" />
              <span className="hidden md:inline">Account</span>
            </Button>
          </div>
        </div>
      </div>
      <div className="bg-accent">
        <div className="container mx-auto px-4 py-2">
          <div className="flex justify-between items-center">
            <nav className="hidden lg:flex space-x-6">
              <Link href="/">
                <div className="text-white hover:text-opacity-80 font-semibold cursor-pointer">Home</div>
              </Link>
              <Link href="/timeline">
                <div className="text-white hover:text-opacity-80 font-semibold cursor-pointer">Timeline</div>
              </Link>
              <Link href="/corporations">
                <div className="text-white hover:text-opacity-80 font-semibold cursor-pointer">Corporate Profiteers</div>
              </Link>
              <Link href="/institutions">
                <div className="text-white hover:text-opacity-80 font-semibold cursor-pointer">Educational Institutions</div>
              </Link>
              <Link href="/resources/1">
                <div className="text-white hover:text-opacity-80 font-semibold cursor-pointer">Self-Reliance Resources</div>
              </Link>
              <Link href="/about">
                <div className="text-white hover:text-opacity-80 font-semibold cursor-pointer">About</div>
              </Link>
            </nav>
            <form onSubmit={handleSearch} className="w-full lg:w-auto lg:ml-auto">
              <div className="relative">
                <Input
                  type="text"
                  placeholder="Search for specific content..."
                  className="w-full lg:w-64 px-4 py-1 rounded-full text-dark pr-8"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
                <button type="submit" className="absolute right-3 top-1/2 transform -translate-y-1/2">
                  <Search className="h-4 w-4 text-primary" />
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
