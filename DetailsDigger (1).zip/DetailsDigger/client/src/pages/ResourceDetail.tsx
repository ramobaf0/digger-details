import { useParams, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { ArrowLeft, FileText, FileImage, Video, Download, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Resource } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";

const ResourceDetail = () => {
  const { id } = useParams();
  const { data: resource, isLoading, error } = useQuery<Resource>({
    queryKey: [`/api/resources/${id}`],
  });

  if (isLoading) {
    return (
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <Link href="/#resources">
            <Button variant="ghost" className="mb-4">
              <ArrowLeft className="mr-2 h-4 w-4" /> Back to Resources
            </Button>
          </Link>
          <Skeleton className="h-12 w-3/4 mb-2" />
          <Skeleton className="h-6 w-1/2 mb-8" />
          <Skeleton className="h-64 w-full mb-6" />
        </div>
      </div>
    );
  }

  if (error || !resource) {
    return (
      <div className="max-w-4xl mx-auto">
        <div className="bg-red-50 border border-red-200 rounded-md p-6 mb-8">
          <div className="flex items-start">
            <AlertTriangle className="h-6 w-6 text-red-500 mr-3 mt-0.5" />
            <div>
              <h3 className="font-heading font-bold text-lg text-red-800 mb-2">
                Error Loading Resource Details
              </h3>
              <p className="text-red-700">
                We couldn't load the details for this resource. It may not exist or there might be a connection issue.
              </p>
              <Link href="/#resources">
                <Button variant="secondary" className="mt-4">
                  Return to Resources
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Determine background color based on category
  let bgColorClass;
  switch (resource.category) {
    case "education":
      bgColorClass = "bg-accent";
      break;
    case "economic":
      bgColorClass = "bg-primary";
      break;
    case "advocacy":
      bgColorClass = "bg-secondary";
      break;
    default:
      bgColorClass = "bg-primary";
  }

  const getIcon = (type: string) => {
    switch (type) {
      case "pdf":
        return <FileText className="h-5 w-5 mr-3" />;
      case "presentation":
        return <FileImage className="h-5 w-5 mr-3" />;
      case "video":
        return <Video className="h-5 w-5 mr-3" />;
      default:
        return <FileText className="h-5 w-5 mr-3" />;
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <Link href="/#resources">
        <Button variant="ghost" className="mb-4">
          <ArrowLeft className="mr-2 h-4 w-4" /> Back to Resources
        </Button>
      </Link>

      <div className="bg-white rounded-xl overflow-hidden shadow-md mb-8">
        <div className={`${bgColorClass} text-white p-6`}>
          <div className="flex items-center">
            <div className="text-4xl mr-4">
              {resource.icon}
            </div>
            <div>
              <h1 className="text-3xl font-heading font-bold">{resource.title}</h1>
              <p className="text-xl">Self-Reliance Resource</p>
            </div>
          </div>
        </div>

        <div className="p-6">
          <div className="mb-8">
            <h2 className="text-2xl font-heading font-bold mb-4">Resource Overview</h2>
            <p>{resource.description}</p>
          </div>

          <div className="mb-8">
            <h3 className="text-xl font-heading font-bold mb-4">Downloadable Materials</h3>
            <div className="grid gap-4">
              {resource.files.map((file, index) => (
                <div key={index} className="bg-gray-50 rounded-lg p-4">
                  <div className="flex justify-between items-center">
                    <div className="flex items-center">
                      {getIcon(file.type)}
                      <div>
                        <h4 className="font-semibold">{file.name}</h4>
                        <p className="text-sm text-gray-500">{file.description}</p>
                      </div>
                    </div>
                    <Button variant="outline" size="sm" className="flex items-center" asChild>
                      <a href={`/api/resources/download/${resource.id}/${file.id}`} download>
                        <Download className="h-4 w-4 mr-2" />
                        Download
                      </a>
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mb-8">
            <h3 className="text-xl font-heading font-bold mb-4">How to Use These Resources</h3>
            <div className="bg-gray-50 p-4 rounded-lg">
              <p className="mb-4">{resource.useInstructions}</p>
              <div className="grid md:grid-cols-2 gap-4">
                {resource.useCases?.map((useCase, index) => (
                  <div key={index} className="bg-white p-3 rounded shadow-sm">
                    <h4 className="font-semibold mb-1">{useCase.title}</h4>
                    <p className="text-sm">{useCase.description}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="border-t pt-6">
            <h3 className="text-xl font-heading font-bold mb-4">Implementation Guide</h3>
            <ol className="list-decimal pl-5 space-y-3">
              {resource.implementationSteps?.map((step, index) => (
                <li key={index}>
                  <p className="font-semibold">{step.title}</p>
                  <p className="text-sm">{step.description}</p>
                </li>
              ))}
            </ol>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <h2 className="text-2xl font-heading font-bold mb-4">Related Resources</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {resource.relatedResources?.map((related, index) => (
            <Link key={index} href={`/resources/${related.id}`}>
              <div className="p-4 border rounded-lg hover:border-primary hover:shadow-md transition-all cursor-pointer">
                <h4 className="font-semibold mb-2">{related.title}</h4>
                <p className="text-sm text-gray-600 mb-2">{related.description}</p>
                <div className="text-primary text-sm font-semibold flex items-center">
                  View Resource <ArrowLeft className="h-3 w-3 ml-1 rotate-180" />
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ResourceDetail;
