import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Book, FilePlus, Share2, Users } from "lucide-react";

const About = () => {
  return (
    <div className="max-w-4xl mx-auto">
      <Link href="/">
        <Button variant="ghost" className="mb-4">
          <ArrowLeft className="mr-2 h-4 w-4" /> Back to Home
        </Button>
      </Link>

      <div className="bg-white rounded-xl shadow-md p-6 mb-8">
        <h1 className="text-3xl font-heading font-bold mb-6">
          About South African Legacy Project
        </h1>
        <p className="mb-6">
          This educational platform was created to document and raise awareness about how
          apartheid's legacy continues through economic structures, educational institutions,
          and systemic inequality in modern South Africa.
        </p>

        <div className="mb-8">
          <h2 className="text-2xl font-heading font-bold mb-4">Our Mission</h2>
          <div className="p-4 border-l-4 border-primary bg-gray-50">
            <p>
              To provide comprehensive, evidence-based educational resources that expose the
              ongoing economic beneficiaries of apartheid, while empowering communities to build
              self-reliant alternatives through education, economic initiatives, and advocacy.
            </p>
          </div>
        </div>

        <div className="mb-8">
          <h2 className="text-2xl font-heading font-bold mb-4">Core Objectives</h2>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="flex items-center mb-3">
                <Book className="h-6 w-6 text-primary mr-2" />
                <h3 className="font-semibold text-lg">Document History</h3>
              </div>
              <p className="text-sm">
                Create accessible historical resources that accurately capture the economic and
                institutional aspects of apartheid history often overlooked in mainstream
                narratives.
              </p>
            </div>
            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="flex items-center mb-3">
                <FilePlus className="h-6 w-6 text-primary mr-2" />
                <h3 className="font-semibold text-lg">Expose Beneficiaries</h3>
              </div>
              <p className="text-sm">
                Identify and document corporations and institutions that profited from apartheid
                and continue to benefit from its legacy in contemporary South Africa.
              </p>
            </div>
            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="flex items-center mb-3">
                <Share2 className="h-6 w-6 text-primary mr-2" />
                <h3 className="font-semibold text-lg">Promote Alternatives</h3>
              </div>
              <p className="text-sm">
                Showcase and support community-led initiatives for building self-reliant
                educational, economic, and social structures outside of legacy institutions.
              </p>
            </div>
            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="flex items-center mb-3">
                <Users className="h-6 w-6 text-primary mr-2" />
                <h3 className="font-semibold text-lg">Empower Communities</h3>
              </div>
              <p className="text-sm">
                Provide practical resources, tools, and methodologies for communities to develop
                their own educational frameworks grounded in African knowledge systems.
              </p>
            </div>
          </div>
        </div>

        <div className="mb-8">
          <h2 className="text-2xl font-heading font-bold mb-4">
            Research Methodology & Sources
          </h2>
          <p className="mb-4">
            This platform draws from multiple academic, journalistic, and community sources. All
            claims are documented and fact-checked. Key resources include:
          </p>
          <ul className="space-y-3 pl-5 list-disc">
            <li>
              <strong>Historical archives and Truth and Reconciliation Commission records</strong>
              <p className="text-sm">
                Primary source documents from the apartheid era and the post-apartheid
                reconciliation process provide factual grounding for our historical timelines.
              </p>
            </li>
            <li>
              <strong>Academic research from South African and international universities</strong>
              <p className="text-sm">
                Peer-reviewed studies on the economic impacts of apartheid and its ongoing
                legacies inform our analysis of systemic inequality.
              </p>
            </li>
            <li>
              <strong>Corporate annual reports and public financial disclosures</strong>
              <p className="text-sm">
                Official company documents reveal how corporations benefited during apartheid and
                their current economic positions.
              </p>
            </li>
            <li>
              <strong>Oral histories and community testimonies from affected communities</strong>
              <p className="text-sm">
                Lived experiences and community knowledge provide critical context and
                perspectives often missing from official records.
              </p>
            </li>
          </ul>
        </div>

        <div className="mb-8">
          <h2 className="text-2xl font-heading font-bold mb-4">Contributing to This Project</h2>
          <p className="mb-4">
            This is a community-driven educational resource. We welcome contributions in the
            following areas:
          </p>
          <div className="grid md:grid-cols-3 gap-4">
            <div className="border p-4 rounded-lg">
              <h3 className="font-semibold mb-2">Research</h3>
              <p className="text-sm mb-3">
                Share historical documents, corporate records, or academic research related to
                apartheid's economic systems.
              </p>
              <Button size="sm" variant="secondary" className="w-full">Contribute Research</Button>
            </div>
            <div className="border p-4 rounded-lg">
              <h3 className="font-semibold mb-2">Educational Materials</h3>
              <p className="text-sm mb-3">
                Submit lesson plans, teaching guides, or curriculum resources for community
                education initiatives.
              </p>
              <Button size="sm" variant="secondary" className="w-full">Share Materials</Button>
            </div>
            <div className="border p-4 rounded-lg">
              <h3 className="font-semibold mb-2">Community Stories</h3>
              <p className="text-sm mb-3">
                Document community experiences, self-reliance initiatives, or oral histories
                related to apartheid's impact.
              </p>
              <Button size="sm" variant="secondary" className="w-full">Tell Your Story</Button>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <h2 className="text-2xl font-heading font-bold mb-4">Contact Information</h2>
        <p className="mb-6">
          For questions, feedback, or to discuss contributions to the South African Legacy
          project, please reach out to our team:
        </p>
        <div className="grid md:grid-cols-2 gap-6">
          <div className="p-4 border rounded-lg">
            <h3 className="font-semibold mb-2">General Inquiries</h3>
            <p className="text-sm">contact@southafricanlegacy.org</p>
          </div>
          <div className="p-4 border rounded-lg">
            <h3 className="font-semibold mb-2">Content Contributions</h3>
            <p className="text-sm">contribute@southafricanlegacy.org</p>
          </div>
          <div className="p-4 border rounded-lg">
            <h3 className="font-semibold mb-2">Research Team</h3>
            <p className="text-sm">research@southafricanlegacy.org</p>
          </div>
          <div className="p-4 border rounded-lg">
            <h3 className="font-semibold mb-2">Educational Resources</h3>
            <p className="text-sm">education@southafricanlegacy.org</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;
