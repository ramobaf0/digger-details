import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Building, Search, Filter, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Corporation } from "@shared/schema";

const CorporationsList = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [industryFilter, setIndustryFilter] = useState("all");

  const { data: corporations = [], isLoading } = useQuery<Corporation[]>({
    queryKey: ["/api/corporations"],
  });

  const filteredCorporations = corporations.filter((corp) => {
    const matchesSearch = 
      corp.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      corp.description.toLowerCase().includes(searchTerm.toLowerCase());
      
    const matchesIndustry = 
      industryFilter === "all" || 
      corp.industry.toLowerCase() === industryFilter.toLowerCase();
      
    return matchesSearch && matchesIndustry;
  });

  // Get unique industries
  const uniqueIndustries = Array.from(
    new Set(corporations.map(corp => corp.industry.toLowerCase()))
  );
  const industries = ["all", ...uniqueIndustries];

  return (
    <div className="container mx-auto">
      <div className="flex flex-col items-start mb-8">
        <h1 className="text-3xl font-heading font-bold mb-2">Corporate Profiteers</h1>
        <p className="text-lg text-gray-700 mb-6">
          Explore companies that benefited from apartheid and continue to profit in post-apartheid South Africa.
        </p>
        
        <div className="w-full flex flex-col sm:flex-row gap-4 mb-6">
          <div className="relative flex-grow">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
            <Input
              type="text"
              placeholder="Search corporations..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <div className="flex gap-2 flex-wrap">
            <Filter className="text-gray-500" size={20} />
            {industries.map((industry) => (
              <Button 
                key={industry} 
                variant={industryFilter === industry ? "default" : "outline"}
                className="text-xs"
                onClick={() => setIndustryFilter(industry)}
              >
                {industry.charAt(0).toUpperCase() + industry.slice(1)}
              </Button>
            ))}
          </div>
        </div>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(6)].map((_, i) => (
            <Card key={i} className="bg-gray-50 animate-pulse">
              <CardHeader>
                <div className="w-3/4 h-6 bg-gray-200 rounded"></div>
                <div className="w-1/2 h-4 bg-gray-200 rounded mt-2"></div>
              </CardHeader>
              <CardContent>
                <div className="w-full h-20 bg-gray-200 rounded"></div>
              </CardContent>
              <CardFooter>
                <div className="w-1/3 h-8 bg-gray-200 rounded"></div>
              </CardFooter>
            </Card>
          ))}
        </div>
      ) : (
        <>
          {filteredCorporations.length === 0 ? (
            <div className="text-center py-12">
              <Building className="h-16 w-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-600 mb-2">No corporations found</h3>
              <p className="text-gray-500">
                Try adjusting your search or filter settings
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredCorporations.map((corporation) => (
                <Card key={corporation.id} className="hover:shadow-md transition border-t-4 border-t-primary">
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-start mb-1">
                      <CardTitle className="text-xl">{corporation.name}</CardTitle>
                      <Badge variant="outline" className="bg-primary/10 text-primary">
                        {corporation.industry}
                      </Badge>
                    </div>
                    <CardDescription className="flex items-center gap-1">
                      <Calendar className="h-3 w-3" /> 
                      Active since apartheid era
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="pb-0">
                    <p className="text-sm line-clamp-4 mb-4">{corporation.description}</p>
                    <div className="text-xs text-red-700 bg-red-50 rounded p-2 mb-3">
                      <strong>Apartheid role:</strong> {corporation.apartheidRole.substring(0, 100)}...
                    </div>
                    <div className="text-xs text-slate-700 bg-slate-50 rounded p-2">
                      <strong>Post-1994 activities:</strong> {corporation.post1994.substring(0, 100)}...
                    </div>
                  </CardContent>
                  <CardFooter className="pt-4">
                    <Button variant="outline" asChild className="w-full">
                      <Link href={`/corporations/${corporation.id}`}>
                        View Complete Profile
                      </Link>
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
};

export default CorporationsList;