import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { GraduationCap, Search, Filter, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Institution } from "@shared/schema";

const InstitutionsList = () => {
  const [searchTerm, setSearchTerm] = useState("");

  const { data: institutions = [], isLoading } = useQuery<Institution[]>({
    queryKey: ["/api/institutions"],
  });

  const filteredInstitutions = institutions.filter((inst) => {
    const matchesSearch = 
      inst.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      inst.description.toLowerCase().includes(searchTerm.toLowerCase());
      
    return matchesSearch;
  });

  return (
    <div className="container mx-auto">
      <div className="flex flex-col items-start mb-8">
        <h1 className="text-3xl font-heading font-bold mb-2">Educational Institutions</h1>
        <p className="text-lg text-gray-700 mb-6">
          Explore educational institutions that played significant roles in supporting apartheid and their current status.
        </p>
        
        <div className="w-full flex flex-col sm:flex-row gap-4 mb-6">
          <div className="relative flex-grow">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
            <Input
              type="text"
              placeholder="Search institutions..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {[...Array(4)].map((_, i) => (
            <Card key={i} className="bg-gray-50 animate-pulse">
              <CardHeader>
                <div className="w-3/4 h-6 bg-gray-200 rounded"></div>
                <div className="w-1/2 h-4 bg-gray-200 rounded mt-2"></div>
              </CardHeader>
              <CardContent>
                <div className="w-full h-20 bg-gray-200 rounded"></div>
              </CardContent>
              <CardFooter>
                <div className="w-1/3 h-8 bg-gray-200 rounded"></div>
              </CardFooter>
            </Card>
          ))}
        </div>
      ) : (
        <>
          {filteredInstitutions.length === 0 ? (
            <div className="text-center py-12">
              <GraduationCap className="h-16 w-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-600 mb-2">No institutions found</h3>
              <p className="text-gray-500">
                Try adjusting your search settings
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {filteredInstitutions.map((institution) => (
                <Card key={institution.id} className="hover:shadow-md transition border-t-4 border-t-primary">
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-start mb-1">
                      <CardTitle className="text-xl">{institution.name}</CardTitle>
                      <Badge variant="outline" className="bg-primary/10 text-primary">
                        {institution.established}
                      </Badge>
                    </div>
                    <CardDescription className="flex items-center gap-1">
                      <Calendar className="h-3 w-3" /> 
                      Established: {institution.established}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="pb-0">
                    <p className="text-sm line-clamp-3 mb-4">{institution.description}</p>
                    <div className="text-xs text-red-700 bg-red-50 rounded p-2 mb-3">
                      <strong>Historical Role:</strong> {institution.historicalRole.substring(0, 120)}...
                    </div>
                    <div className="text-xs text-slate-700 bg-slate-50 rounded p-2">
                      <strong>Current Impact:</strong> {institution.currentImpact.substring(0, 120)}...
                    </div>
                  </CardContent>
                  <CardFooter className="pt-4">
                    <Button variant="outline" asChild className="w-full">
                      <Link href={`/institutions/${institution.id}`}>
                        View Complete Profile
                      </Link>
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
};

export default InstitutionsList;