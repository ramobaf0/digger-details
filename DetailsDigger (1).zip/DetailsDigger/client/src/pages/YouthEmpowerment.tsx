import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { 
  AlertTriangle, 
  Globe, 
  ShieldAlert, 
  Rocket, 
  Brain,
  Info,
  ArrowLeftCircle, 
  Download,
  FileText
} from "lucide-react";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter,
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const YouthEmpowerment = () => {
  return (
    <div className="container mx-auto mb-10">
      {/* Header */}
      <div className="bg-black text-white p-6 rounded-xl mb-8">
        <div className="max-w-4xl mx-auto">
          <Link href="/">
            <Button variant="outline" className="bg-transparent border-white text-white hover:bg-white/10 mb-4">
              <ArrowLeftCircle className="mr-2 h-4 w-4" /> Back to Home
            </Button>
          </Link>
          <h1 className="text-3xl md:text-4xl font-heading font-bold mb-2">Youth & People Empowerment Guide</h1>
          <p className="text-lg md:text-xl opacity-90">Based on Global Models of Defense, Health, Economy, and Justice</p>
        </div>
      </div>

      {/* South African Reality */}
      <Card className="mb-8 border-l-4 border-l-red-600">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Info className="h-6 w-6 text-red-600" />
            The South African Reality
          </CardTitle>
          <CardDescription>Understanding the systemic challenges in depth</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="mb-4">Over <span className="text-red-600 font-bold">50,000 people die every 3 months</span> in South Africa — many due to systemic or orchestrated causes deeply rooted in historical inequities and modern corporate exploitation:</p>
          
          <div className="space-y-6 mt-6">
            <div className="border-b pb-4">
              <h3 className="font-bold text-lg mb-2 text-red-700">Alcohol and Drug Industries</h3>
              <p className="mb-2">The alcohol industry in South Africa maintains a deadly foothold through several mechanisms:</p>
              <ul className="space-y-2 list-disc pl-5 mb-3">
                <li>Township taverns (shebeens) operate with minimal regulation, often selling to minors and fueling violence</li>
                <li>Major distributors target low-income areas with high-alcohol, low-cost beverages specifically designed for rapid intoxication</li>
                <li>Alcohol is linked to 60% of violent trauma cases in hospitals, creating a massive burden on healthcare</li>
                <li>Strategic lobbying prevents effective regulation, with alcohol companies infiltrating policy development</li>
                <li>Fetal Alcohol Syndrome rates in parts of South Africa are the highest globally at 6-8% of all births</li>
              </ul>
              <p className="text-sm text-gray-700">The drug trade operates through sophisticated networks still connected to apartheid-era security forces, with distribution channels deliberately targeting schools and youth centers.</p>
            </div>
            
            <div className="border-b pb-4">
              <h3 className="font-bold text-lg mb-2 text-red-700">Food Toxins and Banned Chemicals</h3>
              <p className="mb-2">South Africa remains a dumping ground for harmful substances prohibited elsewhere:</p>
              <ul className="space-y-2 list-disc pl-5 mb-3">
                <li>Pesticides banned in Europe continue to be widely used on South African farms, exposing workers and communities</li>
                <li>Processed foods contain preservatives, colorants, and flavor enhancers at levels exceeding international safety standards</li>
                <li>Food labeling laws remain weak, allowing companies to hide dangerous ingredients behind generic terms</li>
                <li>Food supply chains to townships and rural areas often include expired or contaminated products</li>
                <li>Chemical waste dumping in marginalized communities occurs with minimal enforcement against violators</li>
              </ul>
              <p className="text-sm text-gray-700">Recent studies found that 70% of low-cost processed meats contain carcinogenic preservatives at levels 5-10x higher than European limits.</p>
            </div>
            
            <div className="border-b pb-4">
              <h3 className="font-bold text-lg mb-2 text-red-700">Pollution from Mining and Chemical Companies</h3>
              <p className="mb-2">Extraction industries operate with devastating environmental impacts:</p>
              <ul className="space-y-2 list-disc pl-5 mb-3">
                <li>Acid mine drainage from abandoned gold mines contaminates groundwater across Gauteng province</li>
                <li>Heavy metal contamination (lead, mercury, arsenic) affects soil and water in mining communities</li>
                <li>Respiratory diseases are 4-6x higher in communities near mining operations and industrial zones</li>
                <li>Environmental impact assessments are routinely manipulated through corrupt consultants</li>
                <li>Air quality monitoring stations are strategically placed to avoid detecting pollution hotspots</li>
                <li>Coal power stations operate with outdated filtration systems, releasing dangerous particulate matter</li>
              </ul>
              <p className="text-sm text-gray-700">Research indicates a 15-year lower life expectancy in communities surrounding major mining operations compared to national averages.</p>
            </div>
            
            <div className="border-b pb-4">
              <h3 className="font-bold text-lg mb-2 text-red-700">Gender-based Violence and Prostitution Networks</h3>
              <p className="mb-2">Systemic exploitation maintains horrific levels of violence:</p>
              <ul className="space-y-2 list-disc pl-5 mb-3">
                <li>Human trafficking networks connected to legitimate businesses and government officials operate with impunity</li>
                <li>South Africa has one of the world's highest rape rates at 132.4 per 100,000 people (officially reported)</li>
                <li>Organized prostitution networks target vulnerable youth with documented links to entertainment venues and hotels</li>
                <li>Police corruption systematically undermines investigation and prosecution of trafficking cases</li>
                <li>Cultural messaging normalizing violence persists in media, advertising, and entertainment</li>
                <li>Courts remain under-resourced, with GBV cases facing backlogs of 2+ years</li>
              </ul>
              <p className="text-sm text-gray-700">Only 8.6% of rape cases result in conviction, creating a culture of impunity for perpetrators.</p>
            </div>
            
            <div className="border-b pb-4">
              <h3 className="font-bold text-lg mb-2 text-red-700">University Neglect and Media Exploitation</h3>
              <p className="mb-2">Knowledge institutions maintain apartheid-era divisions through subtle mechanisms:</p>
              <ul className="space-y-2 list-disc pl-5 mb-3">
                <li>Academic research on corporate harm is systematically defunded or discredited</li>
                <li>Historically white universities maintain 5-8x more resources per student than historically black institutions</li>
                <li>Media ownership remains concentrated among 4 major corporations with direct ties to apartheid-era businesses</li>
                <li>News coverage systematically criminalizes poverty while minimizing corporate and white-collar crime</li>
                <li>University admission policies use seemingly neutral criteria that preserve historical advantages</li>
                <li>Corporate funding directs research away from social justice issues toward commercial applications</li>
              </ul>
              <p className="text-sm text-gray-700">Despite population demographics, over 80% of professors at top universities remain white, perpetuating knowledge hierarchies.</p>
            </div>
            
            <div className="pb-2">
              <h3 className="font-bold text-lg mb-2 text-red-700">Historic Apartheid-era Infrastructure</h3>
              <p className="mb-2">Built environment continues to cause deaths through:</p>
              <ul className="space-y-2 list-disc pl-5 mb-3">
                <li>Asbestos in schools, government buildings, and low-cost housing remains largely unaddressed</li>
                <li>Township water infrastructure contains lead pipes and contamination points</li>
                <li>Spatial apartheid forces 3+ hour commutes, leading to road fatalities and sleep deprivation</li>
                <li>Lack of traffic safety infrastructure in townships results in pedestrian deaths 7x higher than affluent areas</li>
                <li>Building code enforcement follows racial patterns, with deadly collapses occurring primarily in poor areas</li>
                <li>Healthcare facilities remain concentrated in formerly white areas, creating "medical deserts"</li>
              </ul>
              <p className="text-sm text-gray-700">Emergency response times average 45+ minutes in townships versus 8 minutes in formerly white suburbs.</p>
            </div>
          </div>
          
          <div className="mt-6 bg-red-50 p-4 rounded-lg">
            <h3 className="font-bold text-lg mb-2">Systemic Nature of These Challenges</h3>
            <p>These issues aren't accidental but interconnected components of ongoing exploitation. The same corporate entities benefit financially from multiple harmful activities, while using media control, academic influence, and political donations to maintain this deadly status quo.</p>
          </div>
        </CardContent>
      </Card>

      {/* Global Resistance */}
      <Card className="mb-8 border-l-4 border-l-blue-600">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Globe className="h-6 w-6 text-blue-600" />
            Lessons from Global Resistance
          </CardTitle>
          <CardDescription>Defense Strategies from Survivors of Western Intervention</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="mb-4">Countries that have successfully defended against economic exploitation have developed comprehensive strategies that South Africa can adapt:</p>
          
          <div className="grid md:grid-cols-3 gap-4 mb-6">
            <div className="bg-gray-50 p-4 rounded-lg">
              <h3 className="font-bold mb-2 text-blue-700">China</h3>
              <p className="mb-2">Tech-based economy, strong education, military self-reliance, censorship of toxic media.</p>
              <ul className="list-disc pl-5 text-sm space-y-1">
                <li>Invested heavily in advanced manufacturing and technical education</li>
                <li>Established internet governance systems to prevent social destabilization</li>
                <li>Created parallel systems to Western financial networks</li>
                <li>Prioritized food security through sustainable agriculture policies</li>
              </ul>
            </div>
            <div className="bg-gray-50 p-4 rounded-lg">
              <h3 className="font-bold mb-2 text-blue-700">Cuba</h3>
              <p className="mb-2">Medical excellence, literacy focus, community health, anti-imperialist diplomacy.</p>
              <ul className="list-disc pl-5 text-sm space-y-1">
                <li>Developed world-class preventative healthcare amid sanctions</li>
                <li>Created "doctor diplomacy" to build international alliances</li>
                <li>Established urban farming systems to overcome food shortages</li>
                <li>Maintained public education as a national priority despite pressure</li>
              </ul>
            </div>
            <div className="bg-gray-50 p-4 rounded-lg">
              <h3 className="font-bold mb-2 text-blue-700">Vietnam</h3>
              <p className="mb-2">Education + agriculture revival, anti-corruption campaigns, localized healthcare.</p>
              <ul className="list-disc pl-5 text-sm space-y-1">
                <li>Reformed education system to emphasize technical skills and national identity</li>
                <li>Developed community-based healthcare accessible in remote areas</li>
                <li>Enforced strict anti-corruption measures to maintain public trust</li>
                <li>Focused on agricultural self-sufficiency following colonial exploitation</li>
              </ul>
            </div>
            <div className="bg-gray-50 p-4 rounded-lg">
              <h3 className="font-bold mb-2 text-blue-700">Iran</h3>
              <p className="mb-2">Homegrown industry, spiritual education, resistance media, technological independence.</p>
              <ul className="list-disc pl-5 text-sm space-y-1">
                <li>Built independent technical capacities despite sanctions and sabotage</li>
                <li>Maintained cultural and religious education alongside scientific training</li>
                <li>Created alternative media systems to counter Western narratives</li>
                <li>Established reverse engineering capabilities for essential technologies</li>
              </ul>
            </div>
            <div className="bg-gray-50 p-4 rounded-lg">
              <h3 className="font-bold mb-2 text-blue-700">Russia</h3>
              <p className="mb-2">Nationalist economic recovery, cyber defense, resource sovereignty, financial independence.</p>
              <ul className="list-disc pl-5 text-sm space-y-1">
                <li>Developed domestic alternatives to critical imported technologies</li>
                <li>Created independent financial systems to withstand sanctions</li>
                <li>Established strong resource control to benefit national development</li>
                <li>Built cyber capabilities to protect critical infrastructure</li>
              </ul>
            </div>
            <div className="bg-gray-50 p-4 rounded-lg">
              <h3 className="font-bold mb-2 text-blue-700">North Korea</h3>
              <p className="mb-2">Self-reliance ideology (Juche), full state control, community survival focus, cultural preservation.</p>
              <ul className="list-disc pl-5 text-sm space-y-1">
                <li>Established food production systems independent of global supply chains</li>
                <li>Maintained strong cultural identity despite external pressures</li>
                <li>Developed economic models centered on self-sufficiency</li>
                <li>Created community-based response systems for resource shortages</li>
              </ul>
            </div>
            <div className="bg-gray-50 p-4 rounded-lg">
              <h3 className="font-bold mb-2 text-blue-700">Mali</h3>
              <p className="mb-2">Anti-colonial resistance, traditional governance restoration, resource sovereignty, regional alliances.</p>
              <ul className="list-disc pl-5 text-sm space-y-1">
                <li>Reclaimed control over natural resources from foreign exploitation</li>
                <li>Integrated traditional governance with modern structures</li>
                <li>Developed regional security cooperation outside foreign control</li>
                <li>Restored traditional language and knowledge systems in education</li>
              </ul>
            </div>
            <div className="bg-gray-50 p-4 rounded-lg">
              <h3 className="font-bold mb-2 text-blue-700">Niger</h3>
              <p className="mb-2">Uranium resource control, anti-colonial monetary reform, indigenous knowledge systems, regional integration.</p>
              <ul className="list-disc pl-5 text-sm space-y-1">
                <li>Broke extractive colonial resource agreements</li>
                <li>Developed monetary systems outside colonial banking control</li>
                <li>Prioritized local control of critical national resources</li>
                <li>Created South-South partnerships to bypass exploitative trade</li>
              </ul>
            </div>
            <div className="bg-gray-50 p-4 rounded-lg">
              <h3 className="font-bold mb-2 text-blue-700">Burkina Faso</h3>
              <p className="mb-2">Sankarist revolution, self-sufficiency programs, women's empowerment, anti-corruption campaigns.</p>
              <ul className="list-disc pl-5 text-sm space-y-1">
                <li>Implemented community-based development free from foreign control</li>
                <li>Established women's rights as central to national development</li>
                <li>Created public transparency systems to prevent corruption</li>
                <li>Developed agricultural programs focused on food sovereignty</li>
              </ul>
            </div>
          </div>
          
          <div className="bg-blue-50 p-5 rounded-lg mb-6">
            <h3 className="font-bold text-lg mb-3 text-blue-800">Key Principles for South African Defense</h3>
            <p className="mb-3">Analysis of successful resistance models reveals common strategies that could be adapted to the South African context:</p>
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <h4 className="font-bold mb-2 text-blue-700">Economic Sovereignty</h4>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Nationalize critical mineral resources and processing</li>
                  <li>Develop parallel banking systems for community financing</li>
                  <li>Establish cooperative enterprises in townships and rural areas</li>
                  <li>Create community seed banks and food sovereignty programs</li>
                </ul>
              </div>
              <div>
                <h4 className="font-bold mb-2 text-blue-700">Media & Knowledge Systems</h4>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Build independent media platforms owned by communities</li>
                  <li>Develop curriculum that centers African epistemologies</li>
                  <li>Create counter-narratives to corporate media messaging</li>
                  <li>Document and archive exploitation evidence systematically</li>
                </ul>
              </div>
              <div>
                <h4 className="font-bold mb-2 text-blue-700">Health Independence</h4>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Revitalize indigenous medical knowledge alongside modern medicine</li>
                  <li>Train community health workers for preventative care</li>
                  <li>Create independent testing labs for food and water safety</li>
                  <li>Develop local pharmaceutical production capabilities</li>
                </ul>
              </div>
              <div>
                <h4 className="font-bold mb-2 text-blue-700">Technical Capacity</h4>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Establish community technology centers for skills development</li>
                  <li>Create open-source technology adaptation programs</li>
                  <li>Develop encrypted communication systems for activists</li>
                  <li>Build independent internet infrastructure in underserved areas</li>
                </ul>
              </div>
            </div>
          </div>
          
          <div className="border-l-4 border-blue-500 pl-4 py-3 bg-blue-50/50">
            <h3 className="font-bold text-lg mb-2">South African Application Strategy</h3>
            <p>Unlike nations with centralized state power, South Africa's resistance must be community-centered. The most viable approach combines elements from multiple global models while centering South African realities and cultural contexts. Successful defense requires both reclaiming historical knowledge systems and adopting technical innovations from global resistance movements.</p>
          </div>
        </CardContent>
      </Card>

      {/* Death System */}
      <Card className="mb-8 border-l-4 border-l-yellow-600">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="h-6 w-6 text-yellow-600" />
            Orchestrated Death System in SA
          </CardTitle>
          <CardDescription>
            <Badge variant="outline" className="bg-yellow-100 text-yellow-800 border-yellow-300">
              Estimated preventable deaths: 35,000 – 55,000 every 3 months
            </Badge>
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="font-bold mb-4">These deaths are not random tragedies but the direct result of systemic failures maintained by deliberate policy choices and corporate influence:</p>
          
          <div className="space-y-6">
            <div className="border-b pb-4">
              <h3 className="font-bold text-lg mb-2 text-yellow-700">Neglected Healthcare & Underfunded Clinics</h3>
              <p className="mb-2">The healthcare crisis is characterized by:</p>
              <ul className="space-y-2 list-disc pl-5 mb-3">
                <li><strong>Clinic-to-population ratio:</strong> In rural areas, one clinic serves 7,000-10,000 people, compared to WHO recommendation of 1:2,500</li>
                <li><strong>Medicine stock-outs:</strong> Essential medicines are unavailable 38% of the time in township clinics versus 5% in suburban facilities</li>
                <li><strong>Staff shortages:</strong> Rural clinics operate with 42% of required nursing staff, while medical specialists are almost entirely concentrated in private hospitals</li>
                <li><strong>Equipment failures:</strong> 68% of public healthcare facilities report non-functional critical equipment (ventilators, dialysis machines, etc.) at any given time</li>
                <li><strong>Waiting times:</strong> Emergency cases in township hospitals wait an average of 4-8 hours for treatment, resulting in preventable complications and deaths</li>
                <li><strong>Privatization pressure:</strong> Public health budgets are systematically redirected to private-public partnerships that exclude poorest patients</li>
              </ul>
              <p className="text-sm text-gray-700">Healthcare budget allocation follows apartheid geography, with historically white areas receiving 3-5x more per capita funding than historically black areas.</p>
            </div>
            
            <div className="border-b pb-4">
              <h3 className="font-bold text-lg mb-2 text-yellow-700">Toxic Media Content Normalizing Crime & Abuse</h3>
              <p className="mb-2">Media systems contribute to violence through:</p>
              <ul className="space-y-2 list-disc pl-5 mb-3">
                <li><strong>Disproportionate coverage:</strong> Violent crimes in white areas receive 11x more media coverage than identical crimes in Black areas</li>
                <li><strong>Dehumanizing language:</strong> Content analysis shows Black victims described in impersonal terms 74% of the time versus 12% for white victims</li>
                <li><strong>Corporate crime invisibility:</strong> Major media outlets allocate only 2.7% of news coverage to corporate malfeasance despite its massive human impacts</li>
                <li><strong>Violence normalization:</strong> Popular entertainment displays increasingly graphic violence with 87% showing no meaningful consequences for perpetrators</li>
                <li><strong>Misrepresentation:</strong> News reporting attributes systemic issues to individual moral failings 83% of the time, undermining structural solutions</li>
                <li><strong>Advertising toxicity:</strong> Products targeting youth communities show greatest concentration of violent and hypersexualized imagery</li>
              </ul>
              <p className="text-sm text-gray-700">Research demonstrates direct correlation between exposure to certain media content and increased aggression, with vulnerable youth most affected.</p>
            </div>
            
            <div className="border-b pb-4">
              <h3 className="font-bold text-lg mb-2 text-yellow-700">Exploitative Corporations Avoiding Accountability</h3>
              <p className="mb-2">Corporate harm persists through sophisticated protection systems:</p>
              <ul className="space-y-2 list-disc pl-5 mb-3">
                <li><strong>Regulatory capture:</strong> Key oversight agencies staffed with former industry executives who maintain "revolving door" relationships</li>
                <li><strong>Legal manipulation:</strong> Corporations maintain litigation strategies averaging 7.2 years per case, outlasting victims' resources</li>
                <li><strong>Shell companies:</strong> Complex corporate structures distribute liability across multiple entities, making accountability nearly impossible</li>
                <li><strong>Political financing:</strong> Corporate interests donate to both major parties, ensuring policy remains favorable regardless of election outcomes</li>
                <li><strong>Financial intimidation:</strong> Whistleblowers face systematic career destruction, with 92% experiencing long-term unemployment after exposing corporate harm</li>
                <li><strong>Community division:</strong> Companies strategically create dependency through selective employment and CSR programs that divide community opposition</li>
              </ul>
              <p className="text-sm text-gray-700">In the last decade, only 0.3% of cases involving corporate harm resulting in death have led to criminal prosecution of executives.</p>
            </div>
            
            <div className="pb-2">
              <h3 className="font-bold text-lg mb-2 text-yellow-700">Environmental Exposure to Banned Substances</h3>
              <p className="mb-2">Toxic exposure continues through systematic regulatory failures:</p>
              <ul className="space-y-2 list-disc pl-5 mb-3">
                <li><strong>Double standards:</strong> At least 37 chemicals banned in EU/US remain legal in South Africa, primarily affecting agricultural workers</li>
                <li><strong>Waste dumping:</strong> Hazardous waste disposal sites are concentrated within 5km of low-income communities at 13x the rate of affluent areas</li>
                <li><strong>Water contamination:</strong> Testing reveals heavy metals (lead, mercury, cadmium) in 72% of water sources serving township areas</li>
                <li><strong>Indoor toxins:</strong> Low-cost building materials contain formaldehyde and VOCs at levels 5-8x higher than international safety standards</li>
                <li><strong>Testing gaps:</strong> Only 4% of consumer products in township markets undergo safety testing vs. 63% in suburban retailers</li>
                <li><strong>Occupational exposure:</strong> Workers in mining, agriculture and manufacturing experience chemical exposure with inadequate or nonexistent PPE</li>
              </ul>
              <p className="text-sm text-gray-700">Communities with highest toxic exposure show 300-400% higher rates of respiratory disease, cancer, and birth defects compared to unexposed populations.</p>
            </div>
            
            <div className="bg-yellow-50 p-4 rounded-lg mt-4">
              <h3 className="font-bold text-lg mb-2">Death By Design: The Interconnected System</h3>
              <p>These four mechanisms function as an integrated system:</p>
              <ol className="list-decimal pl-6 space-y-2 mt-3">
                <li>Corporate entities create environmental and product harm</li>
                <li>Regulatory agencies fail to enforce protections due to corporate capture</li>
                <li>Healthcare systems are deliberately underfunded in affected areas</li>
                <li>Media normalizes the resulting suffering and diverts attention from systemic causes</li>
                <li>This system creates ongoing intergenerational trauma that compounds health impacts</li>
              </ol>
              <p className="mt-3">Breaking this cycle requires simultaneous intervention at all levels, as addressing just one component will be undermined by the others.</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Empowerment Strategies */}
      <Card className="mb-8 border-l-4 border-l-green-600">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Rocket className="h-6 w-6 text-green-600" />
            Empowerment Strategies
          </CardTitle>
          <CardDescription>Comprehensive community defense and empowerment approaches</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="mb-6">The following strategies have been developed based on successful resistance models globally and adapted to the South African context. Each represents a practical approach that communities can implement even without governmental support:</p>
          
          <div className="space-y-8">
            <div className="bg-green-50 p-5 rounded-lg">
              <div className="flex items-center gap-3 mb-3">
                <div className="bg-green-100 text-green-800 rounded-full w-8 h-8 flex items-center justify-center flex-shrink-0 font-bold">1</div>
                <h3 className="font-bold text-lg text-green-800">Truth & Accountability Commission 2.0</h3>
              </div>
              <p className="mb-3">Community-led documentation and justice initiatives that address ongoing apartheid-linked harms:</p>
              <ul className="space-y-2 list-disc pl-5 mb-4">
                <li><strong>Witness archives:</strong> Digital collection of testimony from survivors of corporate and institutional harm</li>
                <li><strong>Corporate lineage tracking:</strong> Documenting connections between apartheid-era companies and current entities</li>
                <li><strong>Death registries:</strong> Community-maintained databases of preventable deaths with cause attribution</li>
                <li><strong>Independent forensics:</strong> Training community scientists to document environmental contamination</li>
                <li><strong>Parallel trials:</strong> Community tribunal processes for cases ignored by formal justice system</li>
              </ul>
              <p className="text-sm text-gray-700 italic">Successful model: Argentina's neighborhood "escraches" that publicly documented torturers and human rights violators when formal justice failed.</p>
            </div>
            
            <div className="bg-green-50 p-5 rounded-lg">
              <div className="flex items-center gap-3 mb-3">
                <div className="bg-green-100 text-green-800 rounded-full w-8 h-8 flex items-center justify-center flex-shrink-0 font-bold">2</div>
                <h3 className="font-bold text-lg text-green-800">Consumer & Environmental Protection Networks</h3>
              </div>
              <p className="mb-3">Community-organized systems to identify and eliminate harmful substances:</p>
              <ul className="space-y-2 list-disc pl-5 mb-4">
                <li><strong>Product testing collectives:</strong> Community labs equipped to test consumer products, water, and soil</li>
                <li><strong>Warning systems:</strong> SMS and radio networks to rapidly share information about dangerous products</li>
                <li><strong>Safe alternatives development:</strong> Creating and sharing non-toxic alternatives to common products</li>
                <li><strong>Supply chain audits:</strong> Tracking products from source to consumer to identify contamination points</li>
                <li><strong>Boycott coordination:</strong> Organized consumer action against companies with harmful practices</li>
                <li><strong>Neighborhood detoxification:</strong> Community-led projects to remediate contaminated areas</li>
              </ul>
              <p className="text-sm text-gray-700 italic">Successful model: India's food safety network that uses simple field tests to identify adulterated foods in markets.</p>
            </div>
            
            <div className="bg-green-50 p-5 rounded-lg">
              <div className="flex items-center gap-3 mb-3">
                <div className="bg-green-100 text-green-800 rounded-full w-8 h-8 flex items-center justify-center flex-shrink-0 font-bold">3</div>
                <h3 className="font-bold text-lg text-green-800">Community Healthcare Systems</h3>
              </div>
              <p className="mb-3">Parallel healthcare structures with community ownership and control:</p>
              <ul className="space-y-2 list-disc pl-5 mb-4">
                <li><strong>Neighborhood clinics:</strong> Community-funded healthcare points staffed by trained residents</li>
                <li><strong>Preventative care networks:</strong> House-to-house education and early warning systems for disease outbreaks</li>
                <li><strong>Medicine production:</strong> Local manufacturing of essential medicines using open-source formulas</li>
                <li><strong>Traditional medicine integration:</strong> Recognizing and supporting indigenous healing practices alongside modern care</li>
                <li><strong>Health worker training:</strong> Developing community members' skills in basic care and emergency response</li>
                <li><strong>Medical equipment repair:</strong> Training technicians to maintain and repair donated or salvaged equipment</li>
              </ul>
              <p className="text-sm text-gray-700 italic">Successful model: Cuba's family doctor program placing clinics directly in neighborhoods with preventative care focus.</p>
            </div>
            
            <div className="bg-green-50 p-5 rounded-lg">
              <div className="flex items-center gap-3 mb-3">
                <div className="bg-green-100 text-green-800 rounded-full w-8 h-8 flex items-center justify-center flex-shrink-0 font-bold">4</div>
                <h3 className="font-bold text-lg text-green-800">Media Watchdogs & Independent Communications</h3>
              </div>
              <p className="mb-3">Systems to counter harmful media narratives and create independent information channels:</p>
              <ul className="space-y-2 list-disc pl-5 mb-4">
                <li><strong>Youth media monitoring:</strong> Trained teams analyzing mainstream media for bias and manipulation</li>
                <li><strong>Community radio:</strong> Low-power FM stations operated by neighborhood collectives</li>
                <li><strong>Digital archives:</strong> Preserving documentation of corporate and state abuses</li>
                <li><strong>Alternative narrative production:</strong> Creating content that accurately represents community realities</li>
                <li><strong>Media literacy education:</strong> Teaching critical consumption skills in schools and community centers</li>
                <li><strong>Mesh networks:</strong> Community-controlled internet infrastructure independent from corporate providers</li>
              </ul>
              <p className="text-sm text-gray-700 italic">Successful model: Indigenous radio networks in Latin America providing crucial information in native languages.</p>
            </div>
            
            <div className="bg-green-50 p-5 rounded-lg">
              <div className="flex items-center gap-3 mb-3">
                <div className="bg-green-100 text-green-800 rounded-full w-8 h-8 flex items-center justify-center flex-shrink-0 font-bold">5</div>
                <h3 className="font-bold text-lg text-green-800">Digital Accountability Registry</h3>
              </div>
              <p className="mb-3">Comprehensive documentation system tracking harmful entities and their impacts:</p>
              <ul className="space-y-2 list-disc pl-5 mb-4">
                <li><strong>Corporate harm tracking:</strong> Detailed databases connecting companies to specific human impacts</li>
                <li><strong>Executive responsibility:</strong> Identifying individual decision-makers behind harmful corporate actions</li>
                <li><strong>Distributed storage:</strong> Using blockchain and distributed systems to prevent data tampering or deletion</li>
                <li><strong>Public interfaces:</strong> User-friendly tools allowing communities to search entities operating in their area</li>
                <li><strong>Product scanning:</strong> Mobile apps allowing consumers to scan products for harmful content</li>
                <li><strong>Legal framework mapping:</strong> Documenting legal loopholes exploited by harmful industries</li>
              </ul>
              <p className="text-sm text-gray-700 italic">Successful model: Worker-developed databases tracking labor violations across multiple industries.</p>
            </div>
            
            <div className="bg-green-50 p-5 rounded-lg">
              <div className="flex items-center gap-3 mb-3">
                <div className="bg-green-100 text-green-800 rounded-full w-8 h-8 flex items-center justify-center flex-shrink-0 font-bold">6</div>
                <h3 className="font-bold text-lg text-green-800">Reparative Justice Framework</h3>
              </div>
              <p className="mb-3">Comprehensive approaches to secure restitution from harmful corporate entities:</p>
              <ul className="space-y-2 list-disc pl-5 mb-4">
                <li><strong>Environmental remediation:</strong> Community-designed plans for companies to restore damaged ecosystems</li>
                <li><strong>Health trusts:</strong> Funds for long-term care of affected individuals and communities</li>
                <li><strong>Infrastructure replacement:</strong> Programs to remove and replace dangerous apartheid-era systems</li>
                <li><strong>Knowledge transfer:</strong> Corporate obligation to share technical expertise with affected communities</li>
                <li><strong>Ownership transfer:</strong> Community equity in companies that profited from exploitation</li>
                <li><strong>Generational support:</strong> Educational and economic programs addressing multi-generational harm</li>
              </ul>
              <p className="text-sm text-gray-700 italic">Successful model: Indigenous land return and co-management agreements with extractive companies in Canada and Australia.</p>
            </div>
            
            <div className="bg-green-50 p-5 rounded-lg">
              <div className="flex items-center gap-3 mb-3">
                <div className="bg-green-100 text-green-800 rounded-full w-8 h-8 flex items-center justify-center flex-shrink-0 font-bold">7</div>
                <h3 className="font-bold text-lg text-green-800">Justice System Reform</h3>
              </div>
              <p className="mb-3">Fundamentally reshaping legal frameworks to address power imbalances:</p>
              <ul className="space-y-2 list-disc pl-5 mb-4">
                <li><strong>Drug decriminalization:</strong> Ending prosecution of substance users while focusing on treatment and support</li>
                <li><strong>Corporate criminal liability:</strong> Legal frameworks ensuring executives face personal consequences for harm</li>
                <li><strong>Community courts:</strong> Local justice systems emphasizing restoration over punishment</li>
                <li><strong>Victim-centered processes:</strong> Centering victims in defining appropriate consequences and restitution</li>
                <li><strong>Universal legal representation:</strong> Ensuring quality legal support regardless of economic status</li>
                <li><strong>Historical injustice remediation:</strong> Addressing ongoing effects of past legal discrimination</li>
              </ul>
              <p className="text-sm text-gray-700 italic">Successful model: Portugal's drug decriminalization approach reducing harm while increasing treatment access.</p>
            </div>
          </div>
          
          <div className="mt-8 p-5 bg-green-100 rounded-lg">
            <h3 className="font-bold text-lg mb-3 text-green-800">Implementation Through Collective Action</h3>
            <p>These strategies become effective through synchronized implementation by coordinated community networks. The synergistic interaction between these approaches creates resilient systems capable of resisting corporate and institutional harm while building autonomous alternatives.</p>
            <p className="mt-2">Communities that have implemented even partial versions of these strategies have documented significant reductions in preventable deaths and improved overall wellbeing indicators.</p>
          </div>
        </CardContent>
      </Card>

      {/* Youth Education */}
      <Card className="mb-8 border-l-4 border-l-purple-600">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="h-6 w-6 text-purple-600" />
            Youth Education for Defense
          </CardTitle>
          <CardDescription>Building knowledge and resilience</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="bg-purple-50 p-4 rounded-lg">
              <h3 className="font-bold text-purple-700 mb-2">Study Models</h3>
              <p>Study world resistance models (China, Vietnam, etc.)</p>
            </div>
            <div className="bg-purple-50 p-4 rounded-lg">
              <h3 className="font-bold text-purple-700 mb-2">Self-Reliance</h3>
              <p>Learn self-reliant technologies: farming, coding, clean energy</p>
            </div>
            <div className="bg-purple-50 p-4 rounded-lg">
              <h3 className="font-bold text-purple-700 mb-2">Peer Networks</h3>
              <p>Create peer-led health & safety networks</p>
            </div>
            <div className="bg-purple-50 p-4 rounded-lg">
              <h3 className="font-bold text-purple-700 mb-2">Awareness</h3>
              <p>Expose harmful media, food, and laws in local schools</p>
            </div>
            <div className="bg-purple-50 p-4 rounded-lg md:col-span-2">
              <h3 className="font-bold text-purple-700 mb-2">Technology</h3>
              <p>Develop apps for alerts, education, community warnings</p>
            </div>
          </div>
        </CardContent>
      </Card>
      
      {/* Full Guide */}
      <Card className="mb-8 border-l-4 border-l-indigo-600">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-6 w-6 text-indigo-600" />
            Complete Youth Empowerment & Defense Guide
          </CardTitle>
          <CardDescription>Comprehensive details and implementation strategies</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="prose max-w-none">
            <h3 className="text-xl font-bold mb-4">Understanding the South African Context</h3>
            <p className="mb-4">
              South Africa's apartheid legacy continues to affect citizens through multiple systemic issues:
            </p>
            <ul className="list-disc pl-6 mb-6 space-y-2">
              <li>Ongoing economic inequality that follows apartheid-era geographical divisions</li>
              <li>Environmental injustice with marginalized communities facing greater pollution exposure</li>
              <li>Educational disparities where historically white institutions maintain advantages</li>
              <li>Media concentration that limits diverse perspectives and community voices</li>
              <li>Medical and healthcare systems that perpetuate historical inequalities</li>
            </ul>
            
            <h3 className="text-xl font-bold mb-4">Global Models for Resistance and Self-Reliance</h3>
            <p className="mb-4">
              Several countries have developed effective models for resisting external exploitation and building self-reliant systems that can inform South African defense strategies:
            </p>

            <div className="overflow-x-auto mb-6">
              <table className="min-w-full border-collapse">
                <thead>
                  <tr className="bg-gray-100">
                    <th className="border p-3 text-left">Country</th>
                    <th className="border p-3 text-left">Key Strategies</th>
                    <th className="border p-3 text-left">Applicable Lessons for South Africa</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="border p-3 font-semibold">China</td>
                    <td className="border p-3">
                      <ul className="list-disc pl-4">
                        <li>Technology development</li>
                        <li>Educational investment</li>
                        <li>Cultural sovereignty protection</li>
                        <li>Parallel systems development</li>
                        <li>Food security prioritization</li>
                      </ul>
                    </td>
                    <td className="border p-3">
                      <ul className="list-disc pl-4">
                        <li>Investment in technical education focused on strategic sectors</li>
                        <li>Development of independent financial systems and structures</li>
                        <li>Creation of community-based food security programs</li>
                        <li>Strategic control of harmful media influence</li>
                      </ul>
                    </td>
                  </tr>
                  <tr>
                    <td className="border p-3 font-semibold">Vietnam</td>
                    <td className="border p-3">
                      <ul className="list-disc pl-4">
                        <li>Agricultural self-reliance</li>
                        <li>Community-based healthcare</li>
                        <li>Education-centered development</li>
                        <li>Anti-corruption enforcement</li>
                        <li>Rural development prioritization</li>
                      </ul>
                    </td>
                    <td className="border p-3">
                      <ul className="list-disc pl-4">
                        <li>Building township agricultural initiatives on unused land</li>
                        <li>Creating locally-controlled healthcare centers</li>
                        <li>Developing technical education appropriate to local needs</li>
                        <li>Enforcement of community standards against corruption</li>
                      </ul>
                    </td>
                  </tr>
                  <tr>
                    <td className="border p-3 font-semibold">Cuba</td>
                    <td className="border p-3">
                      <ul className="list-disc pl-4">
                        <li>Universal medical training</li>
                        <li>Preventative care focus</li>
                        <li>Organic farming methods</li>
                        <li>Universal education access</li>
                        <li>Medical diplomacy</li>
                      </ul>
                    </td>
                    <td className="border p-3">
                      <ul className="list-disc pl-4">
                        <li>Community healthcare worker training programs</li>
                        <li>Preventative healthcare initiatives to address systemic issues</li>
                        <li>Urban farming projects in food insecure areas</li>
                        <li>Creation of community education centers</li>
                      </ul>
                    </td>
                  </tr>
                  <tr>
                    <td className="border p-3 font-semibold">Iran</td>
                    <td className="border p-3">
                      <ul className="list-disc pl-4">
                        <li>Indigenous technology development</li>
                        <li>Alternative media systems</li>
                        <li>Cultural and spiritual education</li>
                        <li>Reverse engineering capacity</li>
                        <li>Resource sovereignty</li>
                      </ul>
                    </td>
                    <td className="border p-3">
                      <ul className="list-disc pl-4">
                        <li>Building independent tech capacity despite resource limitations</li>
                        <li>Creating alternative media that centers African experiences</li>
                        <li>Integrating indigenous knowledge with technological advancement</li>
                        <li>Developing strategic resource management for community benefit</li>
                      </ul>
                    </td>
                  </tr>
                  <tr>
                    <td className="border p-3 font-semibold">Bolivia</td>
                    <td className="border p-3">
                      <ul className="list-disc pl-4">
                        <li>Indigenous rights recognition</li>
                        <li>Resource nationalization</li>
                        <li>Wealth redistribution</li>
                        <li>Constitutional reform</li>
                        <li>Traditional knowledge integration</li>
                      </ul>
                    </td>
                    <td className="border p-3">
                      <ul className="list-disc pl-4">
                        <li>Legal recognition of customary rights and governance systems</li>
                        <li>Community benefit from mineral resources and extractive industries</li>
                        <li>Integration of traditional ecological knowledge into policy</li>
                        <li>Local governance models based on indigenous systems</li>
                      </ul>
                    </td>
                  </tr>
                  <tr>
                    <td className="border p-3 font-semibold">Russia</td>
                    <td className="border p-3">
                      <ul className="list-disc pl-4">
                        <li>Resource sovereignty</li>
                        <li>Financial system independence</li>
                        <li>Technology import substitution</li>
                        <li>Cyber defense capabilities</li>
                        <li>Media sovereignty enforcement</li>
                      </ul>
                    </td>
                    <td className="border p-3">
                      <ul className="list-disc pl-4">
                        <li>Strategic resource management for community benefit</li>
                        <li>Development of payment systems outside Western control</li>
                        <li>Building domestic technical expertise in strategic sectors</li>
                        <li>Community-controlled digital infrastructure</li>
                        <li>Management of harmful external media influences</li>
                      </ul>
                    </td>
                  </tr>
                  <tr>
                    <td className="border p-3 font-semibold">North Korea</td>
                    <td className="border p-3">
                      <ul className="list-disc pl-4">
                        <li>Juche (self-reliance) ideology</li>
                        <li>Parallel economic structures</li>
                        <li>Collectivized agriculture</li>
                        <li>Strong defense posture</li>
                        <li>Cultural identity preservation</li>
                      </ul>
                    </td>
                    <td className="border p-3">
                      <ul className="list-disc pl-4">
                        <li>Community-based self-sufficiency programs</li>
                        <li>Development of alternative economic models</li>
                        <li>Cooperative farming structures on communal land</li>
                        <li>Protection of cultural heritage from external dilution</li>
                        <li>Critical assessment of foreign development models</li>
                      </ul>
                    </td>
                  </tr>
                  <tr>
                    <td className="border p-3 font-semibold">Mali</td>
                    <td className="border p-3">
                      <ul className="list-disc pl-4">
                        <li>Anti-colonial resistance</li>
                        <li>Restoration of traditional governance</li>
                        <li>Resource sovereignty enforcement</li>
                        <li>Rejection of foreign military presence</li>
                        <li>Pan-African cooperation models</li>
                      </ul>
                    </td>
                    <td className="border p-3">
                      <ul className="list-disc pl-4">
                        <li>Reclaiming sovereignty over mining and resource extraction</li>
                        <li>Integrating traditional leadership structures with modern governance</li>
                        <li>Building independent security systems prioritizing communities</li>
                        <li>Developing regional cooperation against external exploitation</li>
                      </ul>
                    </td>
                  </tr>
                  <tr>
                    <td className="border p-3 font-semibold">Niger</td>
                    <td className="border p-3">
                      <ul className="list-disc pl-4">
                        <li>Uranium resource reclamation</li>
                        <li>Anti-colonial monetary policy</li>
                        <li>Indigenous knowledge revival</li>
                        <li>Removal of foreign military forces</li>
                        <li>Regional alliance building</li>
                      </ul>
                    </td>
                    <td className="border p-3">
                      <ul className="list-disc pl-4">
                        <li>Taking control of natural resource extraction and profits</li>
                        <li>Creating financial systems outside of colonial control</li>
                        <li>Developing local solutions to environmental challenges</li>
                        <li>Building South-South trade relationships</li>
                      </ul>
                    </td>
                  </tr>
                  <tr>
                    <td className="border p-3 font-semibold">Burkina Faso</td>
                    <td className="border p-3">
                      <ul className="list-disc pl-4">
                        <li>Sankarist revolutionary model</li>
                        <li>Self-sufficiency prioritization</li>
                        <li>Anti-corruption campaigns</li>
                        <li>Women's empowerment initiatives</li>
                        <li>Populist wealth redistribution</li>
                      </ul>
                    </td>
                    <td className="border p-3">
                      <ul className="list-disc pl-4">
                        <li>Community-led development independent of foreign control</li>
                        <li>Gender equity as integral to liberation struggles</li>
                        <li>Public disclosure and anti-corruption monitoring</li>
                        <li>Self-sufficient community production systems</li>
                      </ul>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
            
            <div className="bg-indigo-50 p-5 rounded-lg mb-6">
              <h3 className="font-bold text-lg mb-3 text-indigo-800">South African Context and Adaptation</h3>
              <p className="mb-4">When adapting global resistance models to South Africa, we must account for unique contextual factors:</p>
              
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-bold mb-2 text-indigo-700">Strategic Considerations</h4>
                  <ul className="list-disc pl-5 space-y-2">
                    <li><strong>Decentralized approach:</strong> Unlike many resistance models that rely on strong central states, South Africa requires community-centered approaches</li>
                    <li><strong>Historical context:</strong> Solutions must address the specific legacy of apartheid and its ongoing economic manifestations</li>
                    <li><strong>Cultural diversity:</strong> Programs must respect and incorporate multiple indigenous knowledge systems</li>
                    <li><strong>Corporate power:</strong> Resistance strategies must counter multinational corporations with deep historical ties to the apartheid system</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-bold mb-2 text-indigo-700">Implementation Priorities</h4>
                  <ul className="list-disc pl-5 space-y-2">
                    <li><strong>Knowledge reclamation:</strong> Documenting and revitalizing indigenous technologies, governance, and healthcare systems</li>
                    <li><strong>Community infrastructure:</strong> Building parallel systems for education, health, and food production</li>
                    <li><strong>Strategic alliances:</strong> Forming intercommunity collaborations across traditional divides</li>
                    <li><strong>Digital sovereignty:</strong> Creating independent communication and data infrastructure controlled by communities</li>
                  </ul>
                </div>
              </div>
            </div>
            
            <h3 className="text-xl font-bold mb-4">Implementation Guide for Communities</h3>

            <h4 className="text-lg font-bold mb-2">1. Documentation and Accountability</h4>
            <p className="mb-4">
              Create systems to document and track ongoing harms from historical and current exploitation:
            </p>
            <ul className="list-disc pl-6 mb-4 space-y-1">
              <li>Establish community-led truth commissions with independent research capacity</li>
              <li>Create digital databases of harmful corporate practices and products</li>
              <li>Document health impacts from environmental pollution and industrial activities</li>
              <li>Map connections between apartheid-era companies and current business entities</li>
            </ul>

            <h4 className="text-lg font-bold mb-2">2. Educational Reform Initiatives</h4>
            <p className="mb-4">
              Develop parallel educational structures that center African knowledge systems:
            </p>
            <ul className="list-disc pl-6 mb-4 space-y-1">
              <li>Create community schools with decolonized curricula and teaching methods</li>
              <li>Develop skill-sharing networks focused on practical technology and trades</li>
              <li>Establish mentorship programs connecting youth with community elders</li>
              <li>Create educational materials that document both historical truths and future visions</li>
            </ul>

            <h4 className="text-lg font-bold mb-2">3. Economic Self-Reliance Programs</h4>
            <p className="mb-4">
              Build economic systems that reduce dependence on exploitative structures:
            </p>
            <ul className="list-disc pl-6 mb-4 space-y-1">
              <li>Establish community gardens and food production networks</li>
              <li>Create cooperative businesses with collective ownership models</li>
              <li>Develop community-owned renewable energy projects</li>
              <li>Build local marketplaces that prioritize community-made goods</li>
              <li>Create skills databases to keep resources and opportunities within communities</li>
            </ul>

            <h4 className="text-lg font-bold mb-2">4. Media and Communications Independence</h4>
            <p className="mb-4">
              Develop independent media channels to counter corporate narrative control:
            </p>
            <ul className="list-disc pl-6 mb-4 space-y-1">
              <li>Create community radio stations and podcasts with local focus</li>
              <li>Establish youth-led media monitoring and literacy programs</li>
              <li>Develop offline communication networks for crisis situations</li>
              <li>Train community journalists in investigative techniques</li>
            </ul>

            <h4 className="text-lg font-bold mb-2">5. Health System Alternatives</h4>
            <p className="mb-4">
              Build community-centered health initiatives that combine traditional and modern approaches:
            </p>
            <ul className="list-disc pl-6 mb-4 space-y-1">
              <li>Establish community health centers with preventative focus</li>
              <li>Create environmental health monitoring teams</li>
              <li>Document and preserve traditional healing knowledge</li>
              <li>Train community health workers in basic care and emergency response</li>
            </ul>

            <div className="bg-gray-100 p-4 rounded-lg mb-6">
              <h4 className="text-lg font-bold mb-2">Key Resources Development Timeline</h4>
              <ol className="list-decimal pl-6 space-y-2">
                <li><strong>Month 1-3:</strong> Establish documentation systems and community research teams</li>
                <li><strong>Month 3-6:</strong> Develop initial educational materials and training programs</li>
                <li><strong>Month 6-12:</strong> Launch pilot programs in selected communities</li>
                <li><strong>Year 1-2:</strong> Expand programs and create networking infrastructure between initiatives</li>
                <li><strong>Year 2-5:</strong> Build independent institutional capacity and sustainable systems</li>
              </ol>
            </div>

            <p className="italic text-sm border-l-4 border-gray-300 pl-4 py-2">
              This guide is a living document meant to be adapted to specific community needs and contexts. 
              Success depends on consistent community involvement, intergenerational collaboration, and 
              building systems that reflect local values and priorities.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Footer */}
      <div className="bg-black text-white p-6 rounded-xl text-center">
        <p>&copy; 2025 Dika-Moka Youth Development Forum | Powered by Justice, Truth, and Youth Power</p>
      </div>
    </div>
  );
};

export default YouthEmpowerment;