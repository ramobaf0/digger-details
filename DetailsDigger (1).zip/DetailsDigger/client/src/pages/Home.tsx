import { useEffect, useRef } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { 
  History, 
  Building, 
  GraduationCap, 
  HandHelping,
  CheckCircle,
  FileText
} from "lucide-react";
import { Card } from "@/components/ui/card";
import Timeline from "@/components/timeline/Timeline";
import CorporationCard from "@/components/cards/CorporationCard";
import InstitutionCard from "@/components/cards/InstitutionCard";
import ResourceCard from "@/components/cards/ResourceCard";
import { Corporation, Institution, Resource } from "@shared/schema";

const Home = () => {
  const [location] = useLocation();
  const timelineRef = useRef<HTMLDivElement>(null);
  const corporationsRef = useRef<HTMLDivElement>(null);
  const educationRef = useRef<HTMLDivElement>(null);
  const resourcesRef = useRef<HTMLDivElement>(null);

  const { data: corporations = [] } = useQuery<Corporation[]>({
    queryKey: ["/api/corporations"],
  });

  const { data: institutions = [] } = useQuery<Institution[]>({
    queryKey: ["/api/institutions"],
  });

  const { data: resources = [] } = useQuery<Resource[]>({
    queryKey: ["/api/resources"],
  });

  useEffect(() => {
    // Handle anchor links
    if (location.includes("#")) {
      const id = location.split("#")[1];
      const element = document.getElementById(id);
      if (element) {
        setTimeout(() => {
          const yOffset = -80; // header height adjustment
          const y = element.getBoundingClientRect().top + window.pageYOffset + yOffset;
          window.scrollTo({ top: y, behavior: "smooth" });
        }, 300);
      }
    } else {
      window.scrollTo(0, 0);
    }
  }, [location]);

  return (
    <>
      <section id="home" className="mb-12">
        <div className="bg-primary text-white rounded-xl overflow-hidden">
          <div className="grid md:grid-cols-2 gap-6">
            <div className="p-6 md:p-10 flex flex-col justify-center">
              <h1 className="text-3xl md:text-4xl lg:text-5xl font-heading font-bold mb-4">
                Apartheid Profiteers Report
              </h1>
              <h2 className="text-xl md:text-2xl font-heading mb-6">
                Legacy of Exploitation in South Africa's Democratic Era
              </h2>
              <p className="mb-6">
                This educational platform reveals how apartheid's legacy continues through economic
                structures, institutions, and systemic inequality in modern South Africa.
              </p>
              <div className="flex flex-wrap gap-3">
                <Button variant="default" className="bg-white text-primary hover:bg-white/90" asChild>
                  <Link href="/timeline">View Timeline</Link>
                </Button>
                <Button variant="secondary" asChild>
                  <Link href="#corporations">Explore Profiteers</Link>
                </Button>
              </div>
            </div>
            <div className="bg-gradient-to-r from-accent to-primary p-10 flex items-center justify-center">
              <div className="bg-white/10 p-3 rounded-lg shadow-lg">
                <svg width="320" height="240" viewBox="0 0 320 240" className="rounded-lg">
                  <rect width="320" height="240" fill="#2D9D78" />
                  <path d="M0,120 L320,120" stroke="white" strokeWidth="2" />
                  <path d="M160,0 L160,240" stroke="white" strokeWidth="2" />
                  <text x="160" y="120" textAnchor="middle" fill="white" fontSize="24" fontWeight="bold">
                    South African Historical Resource
                  </text>
                </svg>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white p-5 rounded-lg shadow-md hover:shadow-lg transition">
              <div className="text-secondary text-3xl mb-3">
                <History className="h-8 w-8" />
              </div>
              <h3 className="font-heading font-bold text-lg mb-2">Historical Context</h3>
              <p className="text-sm">
                Understand apartheid's origins, implementation, and formal ending in 1994.
              </p>
            </div>

            <div className="bg-white p-5 rounded-lg shadow-md hover:shadow-lg transition">
              <div className="text-secondary text-3xl mb-3">
                <Building className="h-8 w-8" />
              </div>
              <h3 className="font-heading font-bold text-lg mb-2">Corporate Legacy</h3>
              <p className="text-sm">
                Explore companies that profited during apartheid and continue to benefit today.
              </p>
            </div>

            <div className="bg-white p-5 rounded-lg shadow-md hover:shadow-lg transition">
              <div className="text-secondary text-3xl mb-3">
                <GraduationCap className="h-8 w-8" />
              </div>
              <h3 className="font-heading font-bold text-lg mb-2">Educational Institutions</h3>
              <p className="text-sm">
                Learn how universities perpetuated systemic racism and inequality.
              </p>
            </div>

            <div className="bg-white p-5 rounded-lg shadow-md hover:shadow-lg transition">
              <div className="text-secondary text-3xl mb-3">
                <HandHelping className="h-8 w-8" />
              </div>
              <h3 className="font-heading font-bold text-lg mb-2">Path to Self-Reliance</h3>
              <p className="text-sm">
                Discover resources for community education, economic empowerment and advocacy.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section id="timeline" className="mb-12" ref={timelineRef}>
        <Timeline limit={7} />
      </section>

      <section id="corporations" className="mb-12" ref={corporationsRef}>
        <h2 className="text-2xl lg:text-3xl font-heading font-bold mb-6">Corporate Profiteers</h2>
        <p className="mb-6">
          These major South African corporations directly or indirectly profited from the apartheid
          regime and continue to benefit economically in the post-apartheid democratic era.
        </p>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {corporations.slice(0, 5).map((corporation) => (
            <CorporationCard key={corporation.id} corporation={corporation} />
          ))}

          <Card className="bg-white shadow-md overflow-hidden border-2 border-dashed border-gray-300 flex items-center justify-center">
            <Link href="/corporations">
              <div className="py-12 text-center w-full">
                <div className="flex flex-col items-center">
                  <Building className="h-12 w-12 text-primary mb-2" />
                  <p className="text-primary font-semibold">View All Corporations</p>
                  <p className="text-xs text-gray-500 mt-1">Explore the complete database</p>
                </div>
              </div>
            </Link>
          </Card>
        </div>
      </section>

      <section id="education" className="mb-12" ref={educationRef}>
        <h2 className="text-2xl lg:text-3xl font-heading font-bold mb-6">Educational Institutions</h2>
        <p className="mb-6">
          These universities and educational institutions played significant roles in supporting
          the apartheid system through ideological foundation, administrative training, and
          maintaining segregated education.
        </p>

        <div className="grid md:grid-cols-2 gap-6">
          {institutions.slice(0, 3).map((institution) => (
            <InstitutionCard key={institution.id} institution={institution} />
          ))}
          
          <Card className="bg-white shadow-md overflow-hidden border-2 border-dashed border-gray-300 flex items-center justify-center">
            <Link href="/institutions">
              <div className="py-12 text-center w-full">
                <div className="flex flex-col items-center">
                  <GraduationCap className="h-12 w-12 text-primary mb-2" />
                  <p className="text-primary font-semibold">View All Institutions</p>
                  <p className="text-xs text-gray-500 mt-1">Explore educational impacts</p>
                </div>
              </div>
            </Link>
          </Card>
        </div>

        <div className="mt-8 p-6 bg-white rounded-lg shadow-md">
          <h3 className="font-heading font-bold text-xl mb-4">
            Educational Inequality: The Continuing Legacy
          </h3>
          <div className="grid md:grid-cols-3 gap-6">
            <div>
              <h4 className="font-semibold text-secondary mb-2">Infrastructure Gap</h4>
              <p className="text-sm">
                Historically white institutions continue to have superior facilities, libraries,
                and research resources compared to historically Black institutions.
              </p>
            </div>
            <div>
              <h4 className="font-semibold text-secondary mb-2">Curriculum Issues</h4>
              <p className="text-sm">
                Teaching materials, theoretical frameworks, and historical perspectives remain
                largely Eurocentric despite calls for decolonization.
              </p>
            </div>
            <div>
              <h4 className="font-semibold text-secondary mb-2">Power Pipeline</h4>
              <p className="text-sm">
                Graduates from these institutions still dominate leadership positions in business,
                government, and civic institutions.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section id="resources" className="mb-12" ref={resourcesRef}>
        <h2 className="text-2xl lg:text-3xl font-heading font-bold mb-6">Self-Reliance Resources</h2>
        <p className="mb-6">
          These resources provide practical tools for communities and educators to build
          self-reliance through education, economic initiatives, and cultural preservation.
        </p>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {resources.slice(0, 3).map((resource) => (
            <ResourceCard key={resource.id} resource={resource} />
          ))}
        </div>

        <div className="mt-8 bg-white rounded-lg shadow-md p-6">
          <h3 className="font-heading font-bold text-xl mb-4">Building a Self-Reliant Educational Framework</h3>
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-semibold text-secondary mb-2">Core Principles</h4>
              <ul className="text-sm space-y-2">
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-accent mt-1 mr-2" />
                  <span>
                    <strong>Community Ownership:</strong> Educational content and methods
                    determined by community needs, not external institutions.
                  </span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-accent mt-1 mr-2" />
                  <span>
                    <strong>Indigenous Knowledge:</strong> Centering African knowledge systems,
                    oral histories, and cultural frameworks.
                  </span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-accent mt-1 mr-2" />
                  <span>
                    <strong>Economic Integration:</strong> Education linked directly to community
                    economic development and self-sufficiency.
                  </span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-accent mt-1 mr-2" />
                  <span>
                    <strong>Critical Analysis:</strong> Teaching historical awareness and critical
                    thinking about systemic racism and colonialism.
                  </span>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-secondary mb-2">Implementation Steps</h4>
              <ol className="text-sm space-y-2 list-decimal pl-5">
                <li>Form community education committees with diverse representation</li>
                <li>Conduct needs assessment and resource mapping within communities</li>
                <li>Develop locally relevant curricula and teaching methods</li>
                <li>Train community educators and facilitators</li>
                <li>Create sustainable funding models independent of corporate donors</li>
                <li>Establish regular knowledge-sharing across communities</li>
                <li>Document successes and challenges for continuous improvement</li>
              </ol>
            </div>
          </div>
        </div>
      </section>

      <section id="about" className="mb-12">
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-2xl font-heading font-bold mb-4">About This Project</h2>
          <p className="mb-4">
            This educational platform was created to document and raise awareness about how
            apartheid's legacy continues through economic structures, educational institutions,
            and systemic inequality in modern South Africa.
          </p>

          <div className="grid md:grid-cols-2 gap-6 mt-6">
            <div>
              <h3 className="font-heading font-bold text-lg mb-3">Our Mission</h3>
              <p className="text-sm">
                To provide comprehensive, evidence-based educational resources that expose the
                ongoing economic beneficiaries of apartheid, while empowering communities to
                build self-reliant alternatives through education, economic initiatives, and
                advocacy.
              </p>
            </div>
            <div>
              <h3 className="font-heading font-bold text-lg mb-3">Contribute to This Project</h3>
              <p className="text-sm">
                This is a community-driven educational resource. We welcome contributions of
                research, educational materials, historical documentation, and community
                resources.
              </p>
              <Button className="mt-4 w-full md:w-auto">
                Become a Contributor
              </Button>
            </div>
          </div>

          <div className="mt-8">
            <h3 className="font-heading font-bold text-lg mb-3">
              Research Methodology & Sources
            </h3>
            <p className="text-sm mb-4">
              This platform draws from multiple academic, journalistic, and community sources.
              All claims are documented and fact-checked. Key resources include:
            </p>
            <ul className="text-sm space-y-2">
              <li className="flex items-start">
                <FileText className="h-5 w-5 text-secondary mr-2 mt-1" />
                <span>
                  Historical archives and Truth and Reconciliation Commission records
                </span>
              </li>
              <li className="flex items-start">
                <FileText className="h-5 w-5 text-secondary mr-2 mt-1" />
                <span>
                  Academic research from South African and international universities
                </span>
              </li>
              <li className="flex items-start">
                <FileText className="h-5 w-5 text-secondary mr-2 mt-1" />
                <span>Corporate annual reports and public financial disclosures</span>
              </li>
              <li className="flex items-start">
                <FileText className="h-5 w-5 text-secondary mr-2 mt-1" />
                <span>Oral histories and community testimonies from affected communities</span>
              </li>
            </ul>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;
