import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import type { Resource } from "@shared/schema";

// Define types for the nested JSON fields
interface FileItem {
  id: string;
  name: string;
  type: string;
  description: string;
}

interface UseCase {
  title: string;
  description: string;
}

interface ImplementationStep {
  title: string;
  description: string;
}

interface RelatedResource {
  id: number;
  title: string;
  description: string;
}

const CulturalPreservation = () => {
  const { toast } = useToast();
  const { data: resource, isLoading, error } = useQuery<Resource>({
    queryKey: ['/api/resources/4'],
    retry: 3,
    staleTime: 60000
  });

  const handleDownload = (fileId: string, fileName: string) => {
    toast({
      title: "Guide accessed",
      description: `You're now viewing: ${fileName}`,
    });
  };

  if (isLoading) {
    return (
      <div className="container mx-auto p-6 animate-pulse">
        <div className="h-8 bg-gray-200 rounded w-2/3 mb-4"></div>
        <div className="h-4 bg-gray-200 rounded w-full mb-6"></div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="h-40 bg-gray-200 rounded"></div>
          <div className="h-40 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  if (error || !resource) {
    return (
      <Alert variant="destructive" className="container mx-auto mt-6">
        <AlertTitle>Error</AlertTitle>
        <AlertDescription>
          Unable to load Cultural Preservation resources. Please try again later.
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <div className="container mx-auto p-4 md:p-6">
      <div className="mb-8">
        <h1 className="text-3xl md:text-4xl font-bold mb-4 bg-gradient-to-r from-blue-600 to-purple-600 text-transparent bg-clip-text">
          {resource.title}
        </h1>
        <p className="text-gray-600 dark:text-gray-300 text-lg mb-6">
          {resource.description}
        </p>
        <Badge variant="outline" className="mb-6">
          Category: {resource.category}
        </Badge>
        <Separator className="my-6" />
      </div>

      <Tabs defaultValue="overview" className="mb-10">
        <TabsList className="mb-6 w-full md:w-auto flex justify-between md:justify-start space-x-2">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="resources">Resource Files</TabsTrigger>
          <TabsTrigger value="use-cases">Use Cases</TabsTrigger>
          <TabsTrigger value="implementation">Implementation Guide</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl">Cultural Preservation Overview</CardTitle>
              <CardDescription>
                Essential tools for preserving and revitalizing indigenous knowledge and cultural traditions
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="prose prose-lg dark:prose-invert max-w-none">
                <p>
                  Cultural preservation is a critical component of resistance against the ongoing effects of apartheid. 
                  During apartheid, indigenous knowledge systems, languages, and cultural practices were systematically 
                  suppressed as part of the regime's attempt to impose Western cultural hegemony.
                </p>
                
                <p className="mt-4">
                  These resources provide comprehensive methodologies and tools for communities to document, preserve, 
                  and revitalize their cultural heritage. By restoring cultural knowledge that was deliberately suppressed, 
                  communities can rebuild essential ties to traditional wisdom, healing practices, sustainable living methods, 
                  and identity formation.
                </p>

                <h3 className="text-xl font-semibold mt-6">Key Benefits</h3>
                <ul className="list-disc pl-6 mt-2 space-y-2">
                  <li><strong>Cultural Sovereignty:</strong> Reclaiming authority over cultural expression and knowledge</li>
                  <li><strong>Healing Historical Trauma:</strong> Reconnecting with suppressed cultural practices as a form of collective healing</li>
                  <li><strong>Sustainable Knowledge:</strong> Preserving traditional ecological wisdom and sustainable practices</li>
                  <li><strong>Intergenerational Connection:</strong> Creating bridges between elders and youth</li>
                  <li><strong>Economic Opportunities:</strong> Developing cultural enterprises and tourism based on authentic cultural knowledge</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="resources" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {resource.files && Array.isArray(resource.files) && (resource.files as FileItem[]).map((file) => (
              <Card key={file.id} className="flex flex-col h-full">
                <CardHeader>
                  <CardTitle>{file.name}</CardTitle>
                  <CardDescription>{file.description}</CardDescription>
                </CardHeader>
                <CardFooter className="mt-auto pt-4">
                  <Button 
                    onClick={() => handleDownload(file.id, file.name)}
                    className="w-full"
                  >
                    View Guide
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>

          <div className="mt-8 p-6 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
            <h3 className="text-xl font-semibold mb-4">Instructions for Use</h3>
            <p className="text-gray-700 dark:text-gray-200">
              {resource.useInstructions}
            </p>
          </div>
        </TabsContent>

        <TabsContent value="use-cases" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Practical Applications</CardTitle>
              <CardDescription>Real-world scenarios where these resources can make an impact</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {resource.useCases && Array.isArray(resource.useCases) && (resource.useCases as UseCase[]).map((useCase, index) => (
                  <div key={index} className="p-4 border rounded-lg">
                    <h3 className="text-lg font-semibold mb-2">{useCase.title}</h3>
                    <p className="text-gray-600 dark:text-gray-300">{useCase.description}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="mt-6">
            <CardHeader>
              <CardTitle>Cultural Preservation in Action</CardTitle>
              <CardDescription>Examples of successful cultural preservation initiatives</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="prose dark:prose-invert max-w-none">
                <h3>Indigenous Language Apps</h3>
                <p>
                  Community-led initiatives have developed mobile applications for teaching and preserving indigenous 
                  South African languages, making them accessible to younger generations through technology.
                </p>

                <h3 className="mt-4">Community Museums</h3>
                <p>
                  Local communities have established small museums and cultural centers to preserve artifacts, 
                  document oral histories, and showcase traditional practices, independent of state institutions.
                </p>

                <h3 className="mt-4">Medicinal Knowledge Documentation</h3>
                <p>
                  Traditional healers have collaborated with community researchers to document indigenous medicinal 
                  plants and healing practices, protecting this knowledge from corporate exploitation while ensuring 
                  its transmission to future generations.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="implementation" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Implementation Guide</CardTitle>
              <CardDescription>Step-by-step approach to establishing cultural preservation initiatives</CardDescription>
            </CardHeader>
            <CardContent>
              <Accordion type="single" collapsible className="w-full">
                {resource.implementationSteps && Array.isArray(resource.implementationSteps) && (resource.implementationSteps as ImplementationStep[]).map((step, index) => (
                  <AccordionItem key={index} value={`step-${index}`}>
                    <AccordionTrigger>
                      <div className="flex items-center">
                        <div className="bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-100 w-8 h-8 rounded-full flex items-center justify-center mr-3">
                          {index + 1}
                        </div>
                        <span>{step.title}</span>
                      </div>
                    </AccordionTrigger>
                    <AccordionContent className="pl-12">
                      <p className="mb-4">{step.description}</p>
                      {index === 0 && (
                        <div className="mt-4 p-4 bg-gray-50 dark:bg-gray-800 rounded-md">
                          <h4 className="font-medium mb-2">Suggested Activities:</h4>
                          <ul className="list-disc pl-5 space-y-1">
                            <li>Conduct community surveys to identify cultural knowledge holders</li>
                            <li>Create an inventory of at-risk cultural elements needing urgent preservation</li>
                            <li>Map geographic locations with cultural significance</li>
                            <li>Document identified cultural assets through photographs, recordings, and text</li>
                          </ul>
                        </div>
                      )}
                      {index === 1 && (
                        <div className="mt-4 p-4 bg-gray-50 dark:bg-gray-800 rounded-md">
                          <h4 className="font-medium mb-2">Key Considerations:</h4>
                          <ul className="list-disc pl-5 space-y-1">
                            <li>Develop protocols for respectful documentation that honor cultural sensitivities</li>
                            <li>Establish permission processes for recording traditional knowledge</li>
                            <li>Ensure community ownership of all documented materials</li>
                            <li>Create systems for handling sacred or restricted cultural knowledge</li>
                          </ul>
                        </div>
                      )}
                      {index === 2 && (
                        <div className="mt-4 p-4 bg-gray-50 dark:bg-gray-800 rounded-md">
                          <h4 className="font-medium mb-2">Preservation Options:</h4>
                          <ul className="list-disc pl-5 space-y-1">
                            <li>Physical archives with climate-controlled storage for artifacts and documents</li>
                            <li>Digital repositories with appropriate security and access controls</li>
                            <li>Regular community events for sharing and practicing cultural knowledge</li>
                            <li>Partnerships with sympathetic institutions for technical support</li>
                          </ul>
                        </div>
                      )}
                      {index === 3 && (
                        <div className="mt-4 p-4 bg-gray-50 dark:bg-gray-800 rounded-md">
                          <h4 className="font-medium mb-2">Transmission Methods:</h4>
                          <ul className="list-disc pl-5 space-y-1">
                            <li>Master-apprentice programs pairing elders with younger community members</li>
                            <li>Regular workshops and classes in traditional practices</li>
                            <li>Integration of cultural knowledge into community education programs</li>
                            <li>Cultural camps and immersive learning experiences</li>
                          </ul>
                        </div>
                      )}
                      {index === 4 && (
                        <div className="mt-4 p-4 bg-gray-50 dark:bg-gray-800 rounded-md">
                          <h4 className="font-medium mb-2">Engagement Strategies:</h4>
                          <ul className="list-disc pl-5 space-y-1">
                            <li>Community cultural festivals and celebrations</li>
                            <li>Educational resources for schools and community groups</li>
                            <li>Digital presence through websites and social media</li>
                            <li>Collaborations with artists to interpret and express cultural heritage</li>
                          </ul>
                        </div>
                      )}
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </CardContent>
          </Card>

          <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="p-6 bg-green-50 dark:bg-green-900/20 rounded-lg">
              <h3 className="text-xl font-semibold mb-4">Success Factors</h3>
              <ul className="list-disc pl-5 space-y-2">
                <li><strong>Community Ownership:</strong> Ensuring the community controls the entire process</li>
                <li><strong>Elder Leadership:</strong> Respecting traditional knowledge keepers' authority</li>
                <li><strong>Sustainable Resources:</strong> Building initiatives that don't depend on external funding</li>
                <li><strong>Accessibility:</strong> Making preserved knowledge accessible to community members</li>
                <li><strong>Digital Integration:</strong> Using appropriate technology to engage younger generations</li>
              </ul>
            </div>
            
            <div className="p-6 bg-red-50 dark:bg-red-900/20 rounded-lg">
              <h3 className="text-xl font-semibold mb-4">Common Challenges</h3>
              <ul className="list-disc pl-5 space-y-2">
                <li><strong>Knowledge Loss:</strong> Urgency due to passing of elder knowledge holders</li>
                <li><strong>Resource Limitations:</strong> Limited funding and equipment for documentation</li>
                <li><strong>Cultural Disconnection:</strong> Youth may initially show limited interest</li>
                <li><strong>Exploitation Risk:</strong> Protection of cultural knowledge from appropriation</li>
                <li><strong>Historical Trauma:</strong> Emotional challenges in addressing suppressed culture</li>
              </ul>
            </div>
          </div>
        </TabsContent>
      </Tabs>

      <div className="mt-10">
        <h2 className="text-2xl font-bold mb-6">Related Resources</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {resource.relatedResources && Array.isArray(resource.relatedResources) && (resource.relatedResources as RelatedResource[]).map((related) => (
            <Card key={related.id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <CardTitle>{related.title}</CardTitle>
                <CardDescription>{related.description}</CardDescription>
              </CardHeader>
              <CardFooter>
                <Link href={`/resources/${related.id}`}>
                  <Button 
                    variant="outline" 
                    className="w-full"
                  >
                    View Resource
                  </Button>
                </Link>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
};

export default CulturalPreservation;