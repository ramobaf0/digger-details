import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowLeft } from "lucide-react";
import Timeline from "@/components/timeline/Timeline";
import { TimelineEvent } from "@shared/schema";

const TimelinePage = () => {
  const { data: events } = useQuery<TimelineEvent[]>({
    queryKey: ["/api/timeline"],
  });

  const categories = events
    ? [...new Set(events.map((event) => event.category))]
    : [];

  return (
    <div className="max-w-4xl mx-auto">
      <Link href="/">
        <Button variant="ghost" className="mb-4">
          <ArrowLeft className="mr-2 h-4 w-4" /> Back to Home
        </Button>
      </Link>

      <div className="bg-white rounded-xl shadow-md p-6 mb-8">
        <h1 className="text-3xl font-heading font-bold mb-6">
          South African Apartheid Timeline
        </h1>
        <p className="mb-6">
          This timeline traces the development of apartheid from its formal inception in 1948
          through its dismantling in 1994, and examines how its economic and social legacy 
          continues to impact South Africa today.
        </p>

        <Tabs defaultValue="all" className="mb-8">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-heading font-semibold">Filter Timeline</h2>
            <TabsList>
              <TabsTrigger value="all">All Events</TabsTrigger>
              {categories.map((category) => (
                <TabsTrigger key={category} value={category}>
                  {category.charAt(0).toUpperCase() + category.slice(1)}
                </TabsTrigger>
              ))}
            </TabsList>
          </div>

          <TabsContent value="all">
            <Timeline showControls={false} />
          </TabsContent>
          
          {categories.map((category) => (
            <TabsContent key={category} value={category}>
              <div className="relative">
                <div className="absolute left-0 md:left-1/2 transform md:-translate-x-1/2 w-1 h-full bg-primary"></div>
                
                <div className="space-y-8">
                  {events
                    ?.filter((event) => event.category === category)
                    .map((event, index) => (
                      <div key={event.id} className="relative flex flex-col md:flex-row">
                        {index % 2 === 0 ? (
                          <>
                            <div className="md:w-1/2 md:pr-12 md:text-right mb-4 md:mb-0">
                              <div className="bg-white p-4 rounded-lg shadow-md">
                                <h3 className="font-heading font-bold text-lg">{event.year}: {event.title}</h3>
                                <p className="text-sm">{event.description}</p>
                              </div>
                            </div>
                            <div className="md:w-1/2 md:pl-12 ml-6 md:ml-0">
                              <div className="absolute left-0 md:left-1/2 transform -translate-x-1/2 w-6 h-6 rounded-full bg-secondary border-4 border-primary"></div>
                            </div>
                          </>
                        ) : (
                          <>
                            <div className="md:w-1/2 md:pr-12 md:text-right invisible md:visible"></div>
                            <div className="md:w-1/2 md:pl-12 ml-6 md:ml-0">
                              <div className="absolute left-0 md:left-1/2 transform -translate-x-1/2 w-6 h-6 rounded-full bg-secondary border-4 border-primary"></div>
                              <div className="bg-white p-4 rounded-lg shadow-md">
                                <h3 className="font-heading font-bold text-lg">{event.year}: {event.title}</h3>
                                <p className="text-sm">{event.description}</p>
                              </div>
                            </div>
                          </>
                        )}
                      </div>
                    ))}
                </div>
              </div>
            </TabsContent>
          ))}
        </Tabs>

        <div className="bg-gray-50 p-4 rounded-lg">
          <h3 className="font-heading font-bold text-lg mb-3">
            Understanding the Timeline
          </h3>
          <p className="mb-3">
            This timeline highlights key events in South African history related to apartheid
            and its economic legacies. It is designed to show how policies implemented during
            the apartheid era continue to shape economic inequality today.
          </p>
          <p>
            Corporate and institutional involvement is highlighted to demonstrate how various
            entities profited from and supported the apartheid system, and how many continue to
            benefit in post-apartheid South Africa.
          </p>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <h2 className="text-2xl font-heading font-bold mb-4">
          Educational Resources
        </h2>
        <p className="mb-4">
          The following resources provide additional context and information about South
          Africa's apartheid history:
        </p>
        <div className="grid md:grid-cols-2 gap-4">
          <Link href="/resources/teaching-materials">
            <div className="p-4 border rounded-lg hover:border-primary hover:shadow-md transition-all cursor-pointer">
              <h3 className="font-semibold mb-2">Teaching Materials</h3>
              <p className="text-sm">
                Comprehensive lesson plans and classroom activities about apartheid history.
              </p>
            </div>
          </Link>
          <Link href="/resources/full-report">
            <div className="p-4 border rounded-lg hover:border-primary hover:shadow-md transition-all cursor-pointer">
              <h3 className="font-semibold mb-2">Full Research Report</h3>
              <p className="text-sm">
                In-depth analysis of apartheid's economic legacy and corporate beneficiaries.
              </p>
            </div>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default TimelinePage;
