import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AlertCircle, ArrowLeft, Home } from "lucide-react";
import { Link } from "wouter";

export default function NotFound() {
  return (
    <div className="w-full flex items-center justify-center py-16">
      <Card className="w-full max-w-md mx-4 border-2 border-red-100">
        <CardContent className="pt-6">
          <div className="flex flex-col items-center text-center mb-6">
            <AlertCircle className="h-16 w-16 text-red-500 mb-4" />
            <h1 className="text-3xl font-heading font-bold text-gray-900 mb-2">Page Not Found</h1>
            <p className="text-gray-600 mb-6">
              The page you're looking for doesn't exist or has been moved.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 w-full justify-center">
              <Link href="/">
                <Button className="w-full sm:w-auto flex items-center gap-2">
                  <Home className="h-4 w-4" /> Go to Home
                </Button>
              </Link>
              <Button 
                variant="outline" 
                className="w-full sm:w-auto flex items-center gap-2"
                onClick={() => window.history.back()}
              >
                <ArrowLeft className="h-4 w-4" /> Go Back
              </Button>
            </div>
          </div>
          
          <div className="mt-8 pt-6 border-t border-gray-200">
            <h2 className="font-heading font-bold text-lg mb-3">Available Pages:</h2>
            <ul className="grid grid-cols-2 gap-2 text-sm">
              <li>
                <Link href="/">
                  <div className="text-primary hover:underline cursor-pointer">Home</div>
                </Link>
              </li>
              <li>
                <Link href="/timeline">
                  <div className="text-primary hover:underline cursor-pointer">Timeline</div>
                </Link>
              </li>
              <li>
                <Link href="/about">
                  <div className="text-primary hover:underline cursor-pointer">About</div>
                </Link>
              </li>
              <li>
                <Link href="/ai-assistant">
                  <div className="text-primary hover:underline cursor-pointer">AI Assistant</div>
                </Link>
              </li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
