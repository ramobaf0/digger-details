import { useState, useEffect } from "react";
import { useLocation, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowLeft, Search as SearchIcon } from "lucide-react";
import { Corporation, Institution, Resource, TimelineEvent } from "@shared/schema";

type SearchResults = {
  corporations: Corporation[];
  institutions: Institution[];
  resources: Resource[];
  timelineEvents: TimelineEvent[];
};

const Search = () => {
  const [location] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [activeTab, setActiveTab] = useState("all");

  useEffect(() => {
    // Extract query from URL
    const urlSearchParams = new URLSearchParams(location.split("?")[1]);
    const query = urlSearchParams.get("q");
    if (query) {
      setSearchQuery(query);
    }
  }, [location]);

  const { data: results, isLoading, error } = useQuery<SearchResults>({
    queryKey: [`/api/search?q=${encodeURIComponent(searchQuery)}`],
    enabled: searchQuery.length > 0,
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // Update URL without navigating away
    if (searchQuery.trim()) {
      window.history.pushState(
        {},
        "",
        `/search?q=${encodeURIComponent(searchQuery)}`
      );
    }
  };

  // Calculate total results
  const totalResults =
    (results?.corporations?.length || 0) +
    (results?.institutions?.length || 0) +
    (results?.resources?.length || 0) +
    (results?.timelineEvents?.length || 0);

  return (
    <div className="max-w-4xl mx-auto">
      <Link href="/">
        <Button variant="ghost" className="mb-4">
          <ArrowLeft className="mr-2 h-4 w-4" /> Back to Home
        </Button>
      </Link>

      <div className="bg-white rounded-xl shadow-md p-6 mb-8">
        <h1 className="text-3xl font-heading font-bold mb-6">Search Resources</h1>

        <form onSubmit={handleSearch} className="mb-8">
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Input
                type="text"
                placeholder="Search for specific content..."
                className="w-full px-4 py-2 rounded-md pr-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <div className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400">
                <SearchIcon className="h-5 w-5" />
              </div>
            </div>
            <Button type="submit">Search</Button>
          </div>
        </form>

        {searchQuery && (
          <div className="mb-6">
            <p className="text-gray-600">
              {isLoading
                ? "Searching..."
                : `Found ${totalResults} results for "${searchQuery}"`}
            </p>
          </div>
        )}

        {searchQuery && !isLoading && (
          <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="mb-6">
              <TabsTrigger value="all">
                All Results ({totalResults})
              </TabsTrigger>
              <TabsTrigger value="corporations">
                Corporations ({results?.corporations?.length || 0})
              </TabsTrigger>
              <TabsTrigger value="institutions">
                Institutions ({results?.institutions?.length || 0})
              </TabsTrigger>
              <TabsTrigger value="resources">
                Resources ({results?.resources?.length || 0})
              </TabsTrigger>
              <TabsTrigger value="timeline">
                Timeline ({results?.timelineEvents?.length || 0})
              </TabsTrigger>
            </TabsList>

            <TabsContent value="all">
              <div className="space-y-8">
                {results?.corporations && results.corporations.length > 0 && (
                  <div>
                    <h2 className="text-xl font-heading font-bold mb-4">Corporations</h2>
                    <div className="space-y-4">
                      {results.corporations.map((corp) => (
                        <Link key={corp.id} href={`/corporations/${corp.id}`}>
                          <div className="p-4 border rounded-lg hover:border-primary hover:shadow-md transition-all cursor-pointer">
                            <h3 className="font-semibold">{corp.name}</h3>
                            <p className="text-sm text-gray-500">{corp.industry}</p>
                            <p className="text-sm mt-1 line-clamp-2">{corp.apartheidRole}</p>
                          </div>
                        </Link>
                      ))}
                    </div>
                  </div>
                )}

                {results?.institutions && results.institutions.length > 0 && (
                  <div>
                    <h2 className="text-xl font-heading font-bold mb-4">Educational Institutions</h2>
                    <div className="space-y-4">
                      {results.institutions.map((inst) => (
                        <Link key={inst.id} href={`/institutions/${inst.id}`}>
                          <div className="p-4 border rounded-lg hover:border-primary hover:shadow-md transition-all cursor-pointer">
                            <h3 className="font-semibold">{inst.name}</h3>
                            <p className="text-sm text-gray-500">Established {inst.established}</p>
                            <p className="text-sm mt-1 line-clamp-2">{inst.historicalRole}</p>
                          </div>
                        </Link>
                      ))}
                    </div>
                  </div>
                )}

                {results?.resources && results.resources.length > 0 && (
                  <div>
                    <h2 className="text-xl font-heading font-bold mb-4">Self-Reliance Resources</h2>
                    <div className="space-y-4">
                      {results.resources.map((resource) => (
                        <Link key={resource.id} href={`/resources/${resource.id}`}>
                          <div className="p-4 border rounded-lg hover:border-primary hover:shadow-md transition-all cursor-pointer">
                            <h3 className="font-semibold">{resource.title}</h3>
                            <p className="text-sm text-gray-500">{resource.category} resource</p>
                            <p className="text-sm mt-1 line-clamp-2">{resource.description}</p>
                          </div>
                        </Link>
                      ))}
                    </div>
                  </div>
                )}

                {results?.timelineEvents && results.timelineEvents.length > 0 && (
                  <div>
                    <h2 className="text-xl font-heading font-bold mb-4">Timeline Events</h2>
                    <div className="space-y-4">
                      {results.timelineEvents.map((event) => (
                        <Link key={event.id} href="/timeline">
                          <div className="p-4 border rounded-lg hover:border-primary hover:shadow-md transition-all cursor-pointer">
                            <h3 className="font-semibold">{event.year}: {event.title}</h3>
                            <p className="text-sm text-gray-500">{event.category}</p>
                            <p className="text-sm mt-1">{event.description}</p>
                          </div>
                        </Link>
                      ))}
                    </div>
                  </div>
                )}

                {totalResults === 0 && (
                  <div className="text-center py-8">
                    <p className="text-gray-500 mb-2">No results found for "{searchQuery}"</p>
                    <p className="text-sm">Try different keywords or browse our categories</p>
                  </div>
                )}
              </div>
            </TabsContent>

            <TabsContent value="corporations">
              <div className="space-y-4">
                {results?.corporations && results.corporations.length > 0 ? (
                  results.corporations.map((corp) => (
                    <Link key={corp.id} href={`/corporations/${corp.id}`}>
                      <div className="p-4 border rounded-lg hover:border-primary hover:shadow-md transition-all cursor-pointer">
                        <h3 className="font-semibold">{corp.name}</h3>
                        <p className="text-sm text-gray-500">{corp.industry}</p>
                        <p className="text-sm mt-2">{corp.apartheidRole}</p>
                        <p className="text-sm mt-2">{corp.post1994}</p>
                      </div>
                    </Link>
                  ))
                ) : (
                  <div className="text-center py-8">
                    <p className="text-gray-500">No corporations found for "{searchQuery}"</p>
                  </div>
                )}
              </div>
            </TabsContent>

            <TabsContent value="institutions">
              <div className="space-y-4">
                {results?.institutions && results.institutions.length > 0 ? (
                  results.institutions.map((inst) => (
                    <Link key={inst.id} href={`/institutions/${inst.id}`}>
                      <div className="p-4 border rounded-lg hover:border-primary hover:shadow-md transition-all cursor-pointer">
                        <h3 className="font-semibold">{inst.name}</h3>
                        <p className="text-sm text-gray-500">Established {inst.established}</p>
                        <p className="text-sm mt-2">{inst.historicalRole}</p>
                        <p className="text-sm mt-2">{inst.currentImpact}</p>
                      </div>
                    </Link>
                  ))
                ) : (
                  <div className="text-center py-8">
                    <p className="text-gray-500">No institutions found for "{searchQuery}"</p>
                  </div>
                )}
              </div>
            </TabsContent>

            <TabsContent value="resources">
              <div className="space-y-4">
                {results?.resources && results.resources.length > 0 ? (
                  results.resources.map((resource) => (
                    <Link key={resource.id} href={`/resources/${resource.id}`}>
                      <div className="p-4 border rounded-lg hover:border-primary hover:shadow-md transition-all cursor-pointer">
                        <h3 className="font-semibold">{resource.title}</h3>
                        <p className="text-sm text-gray-500">{resource.category} resource</p>
                        <p className="text-sm mt-2">{resource.description}</p>
                        <div className="mt-2">
                          <span className="text-sm font-semibold text-primary">
                            {resource.files.length} file(s) available
                          </span>
                        </div>
                      </div>
                    </Link>
                  ))
                ) : (
                  <div className="text-center py-8">
                    <p className="text-gray-500">No resources found for "{searchQuery}"</p>
                  </div>
                )}
              </div>
            </TabsContent>

            <TabsContent value="timeline">
              <div className="space-y-4">
                {results?.timelineEvents && results.timelineEvents.length > 0 ? (
                  results.timelineEvents.map((event) => (
                    <Link key={event.id} href="/timeline">
                      <div className="p-4 border rounded-lg hover:border-primary hover:shadow-md transition-all cursor-pointer">
                        <h3 className="font-semibold">{event.year}: {event.title}</h3>
                        <p className="text-sm text-gray-500">{event.category}</p>
                        <p className="text-sm mt-2">{event.description}</p>
                      </div>
                    </Link>
                  ))
                ) : (
                  <div className="text-center py-8">
                    <p className="text-gray-500">No timeline events found for "{searchQuery}"</p>
                  </div>
                )}
              </div>
            </TabsContent>
          </Tabs>
        )}
      </div>

      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <h2 className="text-2xl font-heading font-bold mb-4">Popular Search Topics</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Button variant="outline" onClick={() => setSearchQuery("mining companies")}>
            Mining Companies
          </Button>
          <Button variant="outline" onClick={() => setSearchQuery("educational inequality")}>
            Educational Inequality
          </Button>
          <Button variant="outline" onClick={() => setSearchQuery("economic transformation")}>
            Economic Transformation
          </Button>
          <Button variant="outline" onClick={() => setSearchQuery("self-reliance")}>
            Self-Reliance
          </Button>
          <Button variant="outline" onClick={() => setSearchQuery("afrikaner institutions")}>
            Afrikaner Institutions
          </Button>
          <Button variant="outline" onClick={() => setSearchQuery("land rights")}>
            Land Rights
          </Button>
          <Button variant="outline" onClick={() => setSearchQuery("decolonization")}>
            Decolonization
          </Button>
          <Button variant="outline" onClick={() => setSearchQuery("corporate accountability")}>
            Corporate Accountability
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Search;
