import { useParams, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { ArrowLeft, GraduationCap, AlertTriangle, Book, Users, Building, FileText } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Institution } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";

const InstitutionDetail = () => {
  const { id } = useParams();
  const { data: institution, isLoading, error } = useQuery<Institution>({
    queryKey: [`/api/institutions/${id}`],
  });

  if (isLoading) {
    return (
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <Link href="/#education">
            <Button variant="ghost" className="mb-4">
              <ArrowLeft className="mr-2 h-4 w-4" /> Back to Educational Institutions
            </Button>
          </Link>
          <Skeleton className="h-12 w-3/4 mb-2" />
          <Skeleton className="h-6 w-1/2 mb-8" />
          <Skeleton className="h-64 w-full mb-6" />
        </div>
      </div>
    );
  }

  if (error || !institution) {
    return (
      <div className="max-w-4xl mx-auto">
        <div className="bg-red-50 border border-red-200 rounded-md p-6 mb-8">
          <div className="flex items-start">
            <AlertTriangle className="h-6 w-6 text-red-500 mr-3 mt-0.5" />
            <div>
              <h3 className="font-heading font-bold text-lg text-red-800 mb-2">
                Error Loading Institution Details
              </h3>
              <p className="text-red-700">
                We couldn't load the details for this institution. It may not exist or there might be a connection issue.
              </p>
              <Link href="/#education">
                <Button variant="secondary" className="mt-4">
                  Return to Educational Institutions
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto">
      <Link href="/#education">
        <Button variant="ghost" className="mb-4">
          <ArrowLeft className="mr-2 h-4 w-4" /> Back to Educational Institutions
        </Button>
      </Link>

      <div className="bg-white rounded-xl overflow-hidden shadow-md mb-8">
        <div className="bg-secondary text-white p-6">
          <div className="flex items-center">
            <GraduationCap className="h-12 w-12 mr-4" />
            <div>
              <h1 className="text-3xl font-heading font-bold">{institution.name}</h1>
              <p className="text-xl">Established {institution.established}</p>
            </div>
          </div>
        </div>

        <div className="p-6">
          <div className="mb-8">
            <h2 className="text-2xl font-heading font-bold mb-4">Institution Overview</h2>
            <p>{institution.description}</p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 mb-8">
            <div>
              <h3 className="text-xl font-heading font-bold text-primary mb-3">
                Historical Role During Apartheid
              </h3>
              <p className="mb-4">{institution.historicalRole}</p>
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="font-semibold mb-2">Key Historical Facts</h4>
                <ul className="list-disc pl-5 space-y-2">
                  {institution.keyHistoricalFacts?.map((fact, index) => (
                    <li key={index}>{fact}</li>
                  ))}
                </ul>
              </div>
            </div>

            <div>
              <h3 className="text-xl font-heading font-bold text-primary mb-3">
                Current Impact & Influence
              </h3>
              <p className="mb-4">{institution.currentImpact}</p>
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="font-semibold mb-2">Areas of Influence</h4>
                <div className="grid grid-cols-2 gap-2">
                  {institution.areasOfInfluence.split(', ').map((area, index) => (
                    <div key={index} className="flex items-center">
                      <div className="w-2 h-2 rounded-full bg-primary mr-2"></div>
                      <span>{area}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div className="mb-8">
            <h3 className="text-xl font-heading font-bold mb-4">Transformation Challenges</h3>
            <div className="p-4 border-l-4 border-secondary bg-gray-50">
              <p className="mb-2">
                <span className="font-semibold">Transformation Status: </span>
                {institution.transformationStatus}
              </p>
              <p>{institution.transformationChallenges}</p>
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-6 mb-8">
            <div className="p-4 bg-gray-50 rounded-lg">
              <div className="flex items-center mb-3">
                <Book className="h-5 w-5 text-primary mr-2" />
                <h4 className="font-semibold">Curriculum Issues</h4>
              </div>
              <p className="text-sm">{institution.curriculumIssues}</p>
            </div>
            <div className="p-4 bg-gray-50 rounded-lg">
              <div className="flex items-center mb-3">
                <Users className="h-5 w-5 text-primary mr-2" />
                <h4 className="font-semibold">Staff Diversity</h4>
              </div>
              <p className="text-sm">{institution.staffDiversity}</p>
            </div>
            <div className="p-4 bg-gray-50 rounded-lg">
              <div className="flex items-center mb-3">
                <Building className="h-5 w-5 text-primary mr-2" />
                <h4 className="font-semibold">Infrastructure</h4>
              </div>
              <p className="text-sm">{institution.infrastructure}</p>
            </div>
          </div>

          <div className="border-t pt-6">
            <h3 className="text-xl font-heading font-bold mb-4">References & Resources</h3>
            <div className="grid md:grid-cols-2 gap-4">
              {institution.resources?.map((resource, index) => (
                <a
                  key={index}
                  href={resource.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
                >
                  <FileText className="h-5 w-5 text-primary mr-2" />
                  <span>{resource.title}</span>
                </a>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <h2 className="text-2xl font-heading font-bold mb-4">Community Alternatives</h2>
        <p className="mb-4">
          In response to the historical legacy and current practices of {institution.name}, various community-led educational initiatives have developed:
        </p>
        <ul className="list-disc pl-5 space-y-2 mb-6">
          <li>
            <strong>Community history classes</strong> - Teaching accurate South African history outside the formal curriculum.
          </li>
          <li>
            <strong>Indigenous knowledge centers</strong> - Preserving and sharing traditional knowledge systems.
          </li>
          <li>
            <strong>Critical literacy programs</strong> - Developing analytical skills to question dominant narratives.
          </li>
          <li>
            <strong>Mentorship networks</strong> - Connecting youth with community leaders and professionals.
          </li>
        </ul>
      </div>
    </div>
  );
};

export default InstitutionDetail;
