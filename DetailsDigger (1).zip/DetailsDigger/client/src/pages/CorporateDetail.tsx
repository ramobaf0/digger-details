import { useParams, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { ArrowLeft, Building, BarChart, ExternalLink, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Corporation } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";

const CorporateDetail = () => {
  const { id } = useParams();
  const { data: corporation, isLoading, error } = useQuery<Corporation>({
    queryKey: [`/api/corporations/${id}`],
  });

  if (isLoading) {
    return (
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <Link href="/#corporations">
            <Button variant="ghost" className="mb-4">
              <ArrowLeft className="mr-2 h-4 w-4" /> Back to Corporate Profiteers
            </Button>
          </Link>
          <Skeleton className="h-12 w-3/4 mb-2" />
          <Skeleton className="h-6 w-1/2 mb-8" />
          <Skeleton className="h-64 w-full mb-6" />
        </div>
      </div>
    );
  }

  if (error || !corporation) {
    return (
      <div className="max-w-4xl mx-auto">
        <div className="bg-red-50 border border-red-200 rounded-md p-6 mb-8">
          <div className="flex items-start">
            <AlertTriangle className="h-6 w-6 text-red-500 mr-3 mt-0.5" />
            <div>
              <h3 className="font-heading font-bold text-lg text-red-800 mb-2">
                Error Loading Corporation Details
              </h3>
              <p className="text-red-700">
                We couldn't load the details for this corporation. It may not exist or there might be a connection issue.
              </p>
              <Link href="/#corporations">
                <Button variant="secondary" className="mt-4">
                  Return to Corporate Profiteers
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto">
      <Link href="/#corporations">
        <Button variant="ghost" className="mb-4">
          <ArrowLeft className="mr-2 h-4 w-4" /> Back to Corporate Profiteers
        </Button>
      </Link>

      <div className="bg-white rounded-xl overflow-hidden shadow-md mb-8">
        <div className="bg-primary text-white p-6">
          <div className="flex items-center">
            <Building className="h-12 w-12 mr-4" />
            <div>
              <h1 className="text-3xl font-heading font-bold">{corporation.name}</h1>
              <p className="text-xl">{corporation.industry}</p>
            </div>
          </div>
        </div>

        <div className="p-6">
          <div className="mb-8">
            <h2 className="text-2xl font-heading font-bold mb-4">Company Overview</h2>
            <p>{corporation.description}</p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 mb-8">
            <div>
              <h3 className="text-xl font-heading font-bold text-secondary mb-3">
                Role During Apartheid
              </h3>
              <p className="mb-4">{corporation.apartheidRole}</p>
              <ul className="list-disc pl-5 space-y-2">
                {corporation.apartheidPractices?.map((practice, index) => (
                  <li key={index}>{practice}</li>
                ))}
              </ul>
            </div>

            <div>
              <h3 className="text-xl font-heading font-bold text-secondary mb-3">
                Post-1994 Activities
              </h3>
              <p className="mb-4">{corporation.post1994}</p>
              <ul className="list-disc pl-5 space-y-2">
                {corporation.currentPractices?.map((practice, index) => (
                  <li key={index}>{practice}</li>
                ))}
              </ul>
            </div>
          </div>

          {corporation.economicImpact && (
            <div className="mb-8">
              <h3 className="text-xl font-heading font-bold mb-4">Economic Impact</h3>
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="flex items-center mb-4">
                  <BarChart className="h-6 w-6 text-primary mr-2" />
                  <span className="font-semibold">Key Metrics</span>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="bg-white p-3 rounded shadow-sm">
                    <div className="text-sm text-gray-500">Annual Revenue</div>
                    <div className="text-lg font-semibold">{corporation.economicImpact.revenue}</div>
                  </div>
                  <div className="bg-white p-3 rounded shadow-sm">
                    <div className="text-sm text-gray-500">Market Share</div>
                    <div className="text-lg font-semibold">{corporation.economicImpact.marketShare}</div>
                  </div>
                  <div className="bg-white p-3 rounded shadow-sm">
                    <div className="text-sm text-gray-500">Employees</div>
                    <div className="text-lg font-semibold">{corporation.economicImpact.employees}</div>
                  </div>
                  <div className="bg-white p-3 rounded shadow-sm">
                    <div className="text-sm text-gray-500">BEE Status</div>
                    <div className="text-lg font-semibold">{corporation.economicImpact.beeStatus}</div>
                  </div>
                </div>
              </div>
            </div>
          )}

          <div className="border-t pt-6">
            <h3 className="text-xl font-heading font-bold mb-4">Additional Resources</h3>
            <div className="grid md:grid-cols-2 gap-4">
              {corporation.resources?.map((resource, index) => (
                <a
                  key={index}
                  href={resource.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
                >
                  <ExternalLink className="h-5 w-5 text-primary mr-2" />
                  <span>{resource.title}</span>
                </a>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <h2 className="text-2xl font-heading font-bold mb-4">Calls for Accountability</h2>
        <p className="mb-4">
          Various civil society organizations are calling for corporate accountability and
          reparations from {corporation.name} and other apartheid profiteers. These include:
        </p>
        <ul className="list-disc pl-5 space-y-2 mb-6">
          <li>
            <strong>Truth and economic justice campaigns</strong> - Documenting and publicizing
            corporate complicity in apartheid.
          </li>
          <li>
            <strong>Reparations movements</strong> - Demanding financial compensation for affected
            communities.
          </li>
          <li>
            <strong>Community reinvestment initiatives</strong> - Calling for meaningful investment
            in historically disadvantaged areas.
          </li>
          <li>
            <strong>Structural reform advocacy</strong> - Pushing for changes to corporate
            governance and ownership structures.
          </li>
        </ul>
      </div>
    </div>
  );
};

export default CorporateDetail;
