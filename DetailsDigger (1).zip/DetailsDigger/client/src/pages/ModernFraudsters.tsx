import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import VoiceOver from "@/components/accessibility/VoiceOver";
import ContentReader from "@/components/accessibility/ContentReader";

// Import uploaded assets
import voxLogoPath from "@assets/1000044824.jpg";
import smsImagePath from "@assets/Screenshot_20250419-083937 (1).png";
import ceoImagePath from "@assets/Screenshot_20240128_161650_Google.jpg";

const ModernFraudsters = () => {
  return (
    <div className="container mx-auto p-4 md:p-6">
      <div className="mb-8">
        <h1 className="text-3xl md:text-4xl font-bold mb-4 bg-gradient-to-r from-red-600 to-purple-600 text-transparent bg-clip-text">
          We Are Not Your Survival Tools
        </h1>
        <p className="text-gray-600 dark:text-gray-300 text-lg mb-6">
          Documenting how corporate entities profit from apartheid legacy through continued exploitation 
          and fraud targeting vulnerable South African communities.
        </p>
        <Badge variant="outline" className="mb-6">
          Category: Corporate Accountability
        </Badge>
        <Separator className="my-6" />
      </div>

      <Tabs defaultValue="overview" className="mb-10">
        <TabsList className="mb-6 w-full md:w-auto flex justify-between md:justify-start space-x-2">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="tactics">Predatory Tactics</TabsTrigger>
          <TabsTrigger value="cases">Case Studies</TabsTrigger>
          <TabsTrigger value="defense">Self-Defense</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl">Modern Economic Exploitation</CardTitle>
              <CardDescription>
                How corporate entities exploit apartheid's economic legacy to target vulnerable communities
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="prose prose-lg dark:prose-invert max-w-none">
                <p>
                  While the formal system of apartheid ended in 1994, its economic legacy remains deeply entrenched in South African society. 
                  This economic inequality creates opportunities for corporate entities to exploit vulnerable communities through 
                  predatory business practices, fraud schemes, and debt traps.
                </p>
                
                <div className="my-8 grid grid-cols-1 md:grid-cols-2 gap-6">
                  <ContentReader 
                    title="Historical Context" 
                    badgeText="Listen"
                    className="bg-gray-100 dark:bg-gray-800 p-6 rounded-lg"
                  >
                    <h3 className="text-xl font-semibold mb-3">Historical Context</h3>
                    <p className="text-gray-700 dark:text-gray-300">
                      Apartheid created vast economic disparities through land dispossession, educational inequality, and systematic 
                      exclusion from economic opportunities. These disparities continue to make previously disadvantaged communities 
                      vulnerable to predatory business practices.
                    </p>
                  </ContentReader>
                  
                  <ContentReader
                    title="Modern Exploitation"
                    badgeText="Listen"
                    className="bg-gray-100 dark:bg-gray-800 p-6 rounded-lg"
                  >
                    <h3 className="text-xl font-semibold mb-3">Modern Exploitation</h3>
                    <p className="text-gray-700 dark:text-gray-300">
                      Companies that profit from apartheid's legacy engage in debt trapping, misrepresentation, 
                      hidden fees, and exploitation of information asymmetry to extract wealth from communities 
                      still recovering from historical injustice.
                    </p>
                  </ContentReader>
                </div>

                <h3 className="text-xl font-semibold mt-6">Corporate Responsibility and Accountability</h3>
                <p>
                  Companies operating in post-apartheid South Africa have a responsibility to acknowledge the historical 
                  context in which they operate. Ethical business practices require transparency, fair dealing, and a 
                  commitment to addressing rather than exploiting historical injustices.
                </p>

                <div className="my-8 flex flex-col md:flex-row gap-6 items-center justify-center">
                  <img 
                    src={smsImagePath} 
                    alt="Fraud SMS Example in South Africa" 
                    className="rounded-lg shadow-md max-w-full md:max-w-xs"
                  />
                  <div className="flex flex-col">
                    <div className="flex items-center gap-2 mb-1">
                      <h4 className="text-lg font-semibold">Key Statistics</h4>
                      <VoiceOver 
                        text="Key Statistics: Over 42% of South Africans have been victims of fraud or scams. Telecommunications-related fraud increased by 36% since 2019. Debt collection scams disproportionately target historically disadvantaged communities. Financial losses from corporate fraud exceed R6 billion annually."
                        label="Listen to statistics"
                      />
                    </div>
                    <ul className="list-disc pl-5 space-y-2">
                      <li>Over 42% of South Africans have been victims of fraud or scams</li>
                      <li>Telecommunications-related fraud increased by 36% since 2019</li>
                      <li>Debt collection scams disproportionately target historically disadvantaged communities</li>
                      <li>Financial losses from corporate fraud exceed R6 billion annually</li>
                    </ul>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="tactics" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Predatory Business Tactics</CardTitle>
              <CardDescription>Common strategies used to exploit vulnerable communities</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="bg-red-50 dark:bg-red-900/20 p-6 rounded-lg">
                  <h3 className="text-xl font-semibold mb-4">Debt Collection Scams</h3>
                  <div className="flex flex-col gap-4">
                    <img 
                      src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAXUAAACHCAMAAADeDjlcAAAAllBMVEVJxEEsxj3///9AwzgjxjfQ7c7v+e5Gw0DD6cGX2ZOS15AyxjWy4rDq9+k5wzBZyFNtzmjl9eTb8tqK1YdTxk2e25q+6Lxnzmde0Vk7xzPI7MfN5sxOyk9gzWF21HPI58dWy1F21HOh3J5pzWNUx0262bmN2Yq+4b2t3KtExUGj3KDA5r+o4KXW7NVAzkNDyEBKzUlz0G3mPbW/AAAVxElEQVR4nO1daWOiPBMHueQQUPHC+1jr0dbr+3+6J6CgYALWxaedo39fbSHJTyZzZzKbjWbK0o36qxV8zTRvBiUa9WtYXo2jOgv/T9Dxy3PqlyYON8jJvWYt/ow/7ueC+nYl77XVZPx/PgL0wGI1ebZWCxZtpT2TBdXjlXbPKWWmLuU9xjXU5yyotS+/3rDv8sDnhX+63e2lbpT+a3XH/4F2jS0H3HVd02S2O+zz8tO1dN8BgMpvhFB6k1ueZXmeSxwLe7qv6r8W9XpbCxw+8/E5NTf+JzC9v5YDYAAhg4J1Jw6GY9+23YN7YUg9K0J1GZ/xn2o9X6k5tsnOhwBgtRgBQpQBAWlNprmtKdkLaUVAiF8Y/wRSGR/m4yMFhNmLLcPM0wSABp1JdaaO5apYJtPtC6bxD7Tw/8mY3s7GClKBBo35MBCaOwZeabKVdq1XnYNeTqYmcx2/JoL5TXkh2t1pq9dDd0bH9jcAA42dtZZS1DEPVEgXI51LGbQZTfajYgW87V9s/EvR0z3mOi6rxiqLgAC0hlqxIv07qZN6NxKDDLYAECzVDt+2exzq54vUxwM5p7uBYAFYqQizWWGW3Bk19dPHYECZ/e3Jj0a5fmjM8S+Ocp2JCQMxYSQTpfuXO/RrIR/q1Lm2e72DNDK/h02PBP2K/L2gYxnD+H+lR9rMHZamSgBTpnRh+XaOXMp+EvbvIgYC0h2CyyzB84XPwbG3XbNWTwKB/TqhzjQTXw90WJt46tJOTKG9AGEr/YQRw3a9CIYuYVbNcLZLafL8Pag4jXX2mxGdHzBz5VzvOpHUhbiDYQGgwuFBPEeBP85Q96NsJKYZ0lm6x01s8WbUmdFsZX2D3PklYeSOxVc82aLg2qujfLH8Tq9GfG7AQofFSQ2WzOLHKSUL+YxmcjE+oP3hPUln4FhfH+JtIbQOhJEVRQzuClMJfBnHyFu9Buk9z/v6AI8Ddk4i0mHQKVB2A7HQxfQc9LXW/urI6cPf6B59Gu5+JqJdL9dHRRHvStm80PKvjf0voAH16Mfpm9NYDfIgctk5SbXdllqMG0DXB1dgOzvhxCXfK+nE+QyhowGlGbfbsUUjVN0m3ZMdwKD9c9WM7mA0UkQI3QW1B0cNf0yl3S51mwCdHy8OTOGuyxh/W9M7j4HQjqQdV9QujsY1mB1KOXc2v3rGD8eWizom1o+YWzs9NB5Aojw/KHhhjsRCdMv01gGI69MrQ9Cn4odjNJbzZ/vixOsiqMn2/FwAzivyezu48EAAC8lf37IW4rCJC1oVmV3dJfhZ2Cbo3uxHeQwvPL9aTGb69QCY1GZ7/JiEnCwvCQGurVdO+Y/AvieEOuyv12njbUu+gC+xMI32zJPvmWF5cMCcC2e5FuKvMW+CeucmwZUJ9D7vHPwg7DlwL0yY0cOKpkxNzJoMm1OXQmdZcGhFQsXS5ALdXYvR/aXQ3e+P6OtDRLjvl/G9LsE5oj87Cg8mH4mWiwZH0MwOsUwjojMR6U/f9APR90zH/GY2K8kHNPYxf461OIbkHxWmFdXX0x/JlF8OMj9MgN/Yz+kEABYcZt1EnqhLQ0lofTyIbpRHeuuHZLHX+bGIvht5j5bAXLkZ2EQlviBUyLWMfYDm6QH5Jy7Ik7N5Ozha3x+UfwDILnLnrpDzYhwVnTcMKi2vC7A+GUZ28XeLOvaOoN+bNzQf+FZ0OMjjG3jCnwQFDQP0yrOHXiToeMj0n6zQbfdMhN2HZSwHJhf2Ik3rMIAMf6ivx9CrXyN7DtyXNFbcCwp4vu4OEW4mNfjKaVg+oQFjz2V1fQtYoU21dWOcOfXrR+B8FLZ3z+/b2GdOnxvpIJzqGWQY+VLo+mWnqreDfqfSGxmQ+8zlv7BLRaKjS9hhD61F69j2AsfHZGY8ddyEgQ8c7Oze0Ws03WqnD4l0HDwwuvhm7DlLqWm4gHKF1BdZMOUgonvUPU/Fj8xmxPHMQgQ+23Xb7RxpDwRbHx1gOnfuJfIEP8mSvYVpJVm9VsZWvPUBoAL3Qa3UeZGhsZNMMQtWQUm4x9vtHHbexrpVDrNVhPOe4LCuZOyvCKoN58OZXbLjy1bDdW5sBHWfNbjXVjxm4k6n68Yj4+z5/cG4c6tNUwxWqsJYUeG3EzNb6ELPzKZ87CqvyTNHKgf4qH05HYxnEZN0FIbjM/oMfzYNB3rvSgYbHBw3cY2G+/Ol2BT+GEFxJdJl5DFtSXrMfOBMCG2UHWdaTxnVyXS4ngwXjJ2O9lsHRnZcHOqF03vBmLpPgTpfKkzG2XYYxT9Hkct2H6pD+9AXRtqZHxW8dC7Io1WZ9Fw8/MzeVzXVfyBxZoNxfEZLIVGbVRSEazjkTpyXZO8G/Qh9uQJx8fwB4K5w/HF6rGBxOpLORZEVvlM95sVn5W3w5dYzRV32b9XVb18NmRMH1AsTlMm/2XD7Qj+sA+Rr5z/0B0CXKRK+jPHYsUtfvYTu6u+6MiXwfePDnIplQQyAXlXmVZDQiyrxsLLfANRJV7f7O6bOgRyLPRTHKb2P44YAMrk/B/SBm46XvmB9x1iUJV8T2lM+NrM+1J38RNI74SaJqnxiLGRU/QFpMMPrx96Gx+yVqQNmbTf+Lxpf9d5FqM+43hMqfG/iopdXN6N+1ffSYVYNVv2kf/YtHnTxnE+J5UYwPyMnp5ZVdZQWOkTfmgLZN/LqU+Fn47KRYKagzsLgF8rqU7mVjw9J0BjQWDHvhNkN9GQYdGF6L86CG1fMVnFwwn1vP5vJ03ZZDqOvh66HaXAqxJn5AwZN0/ZWF/v7qOB5T0/8s92uBHmMKK0VhHxlOLtQDZgqkzMx6Yfuiz2j5yqqNvP+IPXTwCWrUYYPRZzKpktOksmyrmKCZ4mUGnlXlRrexRKm5g6aXWqNbMf3s51VuRWfKK28I5PX8ZXJe8yquIfWWYZupXR/4R2ld6OOuVdmEsLQoTkNtDCwJlWrVIEzJR3/DmNJZiVxnmQpjc74RVy9Lm0qsv22OHxN4ySQezuxIrT1Ndn5qLPUZZQ6zVaHUBo+zFPNlE94Wd7+9PVZKXzXqbKrD4jjDCXudSl/XVSPv6LS9vfiwW3f/7qvquexCuqYMBs3+oAoXWW1l1FnDhWOQKUZZsw/8+6pQXJZn0yquytxJf2/Vb8q5QcwLw8DdWlWiPRx/IUquBsYLd7NRRRYZZUcE/YTuX4SdJK+iEJ2P1+JmwUrFFDPw6Ct3qz4w/dkIwSqXFX1+KxOdT8EpqXKVd+f56aNX5CdFXz6uipfWZxV22g0u1wdm9iWTsznZKwsL3hkviWyPeRGVrXjCCvTCVdl1TGJVXhpruwvO5wf4/0tB21wTBbrn3lWEspU/GSp2UMnfIU+Ue1a+SqvzoVh6D6p6dPjLlWkZlHreLl70+sE0VkZi+I+Qu1wdkLCyIXZSYbzmAeVF4Iz3/Isu0+VQm1X5f+N42a+eXXi71iI+iA6pSg1p4UbZljkQIszabtajt/tOXB9L+U9OwQgHN78qlJTZfrBxGwjMPh6VjfSBjXTKdcprE4Xdqc0Tpp0i6S0FBvkfZGXsY08AZKcnZHRyfAO2Fx5EqE+OObnzV1TRLWUC9kPaqJQwgLc2OSGnlHIXpxVeBWjPzTmplTQxnF58uqsqhpMLVFM53eRZyPXZaGLIjIRNyq3g6c+cE9G5jk9n4l98wGgT2Q+TnWmRx6NaT7Y+qlrw5JRh4tUlWZ1jrlxunVy78FY1/yiTl41QNYZr0Q9SYTYj7YNJDQwzmdtC8YWJyiTMC9NHR+K7gu5TaEXeSe6s0qLQ9lUVPQqPM/LGRG55MXQIHQCpX+FmIcr5qm6K39wlB15RTMWoMqXb9OAZxrtVo9D/LsrA0CfGOgRwh0ubZzZvbZJmMmxZq4oYp4xJ1ThhCLQY6zzU7cVWiVOLZk7GGT3lMgwqzwQTVgwU0Cdpz4slnqfPg85f6t9Nar3o+/M2oVHY7+hpuZv8Yf8aPIW4P23GCUDpYxpXKNOWWEMBKRvdWMFndhCxvPEeRnqXPpAWEfQzgYmjKxDsA3gR6jvVs0FmNY2n69UZhqnYvU07ZjyVSrTCzFnrNDtUNKtfkNeSs9gCifOlJMxVG+dXB/WvmD9iXMBcqr7HGNdI/tL7Jm11PeM1NaA/Jij6myemj2tLiLcfGI51l2iqDohj3UFZKnGCCT/LQeQUFl/0HYXUhGjJ2bSOt7pRxMVTRe1RVx+H3ZLRzIKSC3W/TIpEh0WZ5vXh+iBJLqyqn0qZJfNK13qqdpFrMf5z09dukw05g/i/V0ejcHkN0nRRuO7u1BJTpQHm9KQiZNKLNZn4lj3gOQhYu6fyTh6LhRfEYtctIGIhmdRQV24pVoV685F1PHgTjKPnuYWrJYNhJwOzk/BinojuRUoVjkbZ5U04Wql9x5IlIu+VV9eCx0WzS2lfFDKXL9tQcTSd0aFV/cqsR5LK7TuUMWVcv/IvZc6dOa3l3iG/4GX8g9Hxjojyt5L55MnvOeWIIAU9NQ3UsNFWRJOsWm+k0sqcQIp1vGx/K0QdY1bSS/h5+DMQb9C/aPeTVKCqhN2VFE/IWK5I+7i9sQyjSVoXJJcctJbPdZzr3RLLl/5O1pC1EtPL0i2aBuqkqGk+pZmH1w5TkZ0Ys2qEqzIl9rZ4EqsRz9n+d88kc6rmtGaqU5IvOB76e9PpO24eMrSXomx1fOqA1eOeuwfQE7ZCZ3lW0uLPdqVvRJtk/U9qYqUr03zpnfeFGVPgHVBrmUF9v1o0wJDh3Q4k6P++Nfp7E2NJ1cCXo/1VQjpqBLKzPFpeSO0pnXU1TqF8MzgmnbxcFhPrRkY8Ga5K9j7mKOeXFU/lXCRCvoIyEE/5lSGKZHzCqwbSXrpUfnBuIk5UiZTTUcBzfYLn/7Ev+fMGQmHG42Zb3uGmkWHleMkYuQSh1gnRuX2eGfLvNeFkm5s5BstS4uXmXKTNtfiF19VfSnWeXrJeCg/l/SdIVHRUYCT85WW33Kcw9Ftt4+H5XQatw6cHQrBE8pOPpfPT1aCMCPpP6fEOn4QDz2TBGszWqnjSi0idZ+7w96c9l2kqAKP1JPiLRJinTdkjnKIyVDtXSVGXQsO4n4Ioj1QZFv5VO9v0UapSi2zirEuMueDfCEJ1R5LyoHD56nS01XanJQSj4TEWOcTzlwJ2F0SX2kPQ86YUXFOvMoOi0BaYIYT63GIdX6zRJVYcspnTXW6cljvK3XAYdq2RvhxYr0YYr3ycRcF1AekxFXvhdRIFhqR9x8aLJFfHiuYQqwnQhgfhFVmH/BSO9JTauM0n3Irhpp/MytP0s/nnNLaYrfg3MV1yZ0S2WD8dq6dPVtCrCeKT8UFZ9nBx+ZHxVifB9y217JNhOTuQkFIhHWOz3V3k9kVsZFSKGBb3DzNrPVDuuOSWVU9u6HYl13lCz4L2ER0jjyxPjcbfKhC56rEeg5qDUlEWDdCrJdvyRh8HZZKvZVYT8yEi5vXlnVb/Z6NtdYJSGtpCbGey1Bh8fUlXKxLXFhCxL3rL7N+vdRZUOm5W3uJHOu8HrfhsVWD9Zhrd+I7UxJbvuSRvtZCRwWKrDP3lKu0EsVHhVg/5pPhHV0V90W2G6zLbyf5FLq+0IwzFYl2Idazl75l8+ZVcKpir3DXSbZcHj1KLxiKsS6zP7R9GU9FTOI+bSGHCcdZK5f//Tb4q8SuHsXH3IYYF18oJ9N3ld4F4NfAqB8aFGMdZ7zUxkEpUfGYs0X0pB9uNUjvO9k1kX7q0VLn3y5T/8Jk/DRYk3lchHVH/K6eelEaAVwpzUE4zfj2qswBfmcIfQclXyxcAkWJvb5n8SnFeE4ixnpP7iqCYuFRdWOIUJxYJzIJtcQbyKg5jE5U9RovgrWy1vJ8LlVYx3GbZgWM40JaQVxOQ0pTCOvZCQmrsI5BvnWYv2D/QbZnpCFHXV1VWOH81gqXudQXRewUTIr1QSrrgvpHHMi0XDkdQNzOgn+P/lYQCZBjPQhb2E5qrPcFSf1wk1vZPV1bJeajf+m2ByTXI8pK0Pz6X71cZ/eF9vTp5Lg8r/4KZO58MQGBnC8mFtVZh/xmZC61G1bsOa18gxZLLfFjr9AZ/OdnWnJYZ8UHnGPGYqyrDpHPqmjyFVOD4U1Z0o9t5kn3FQzKhD7PqydbWdRF81mfzVAp/VWYh9nVsXs9vV+I9XjNtULHzCIYrLEGJc+GxTYgXJQFFkMQ7nFOPXqaKWRdTvnXNVd6tSw1mh6fWRwM7Kw7DyWfE90qC4jP8j2P14JQ1KuKWD9f/OVlojRQvs2mBtrOlUo8/PimVCCcn6Vf8ld/W8tKC30+JN5V6fSgDaXF8YJnxRyXhpnlcyVdpdxWOoVekDz0ey7n4UNmz8b2GUTxOhEG1BW0FRKULb4uqsuxLqr70VuV05zC7ZwHrXvDa/hFoFVaFIZZbDCLnJcnOa9wHR1+Db7j22JRYL3/o+p7wF/Iz0qnnI7rtCdPTaQ+5PuJLFOtV0n1Lm6VBVLyrvl3gNj+RdT9XVYxrjovKb9pFrNlnmq8KIXDvKTu59Qkfx6Qk3kvGNWvVG8V33f94vDa6F5d0C9IkfbCFr/3h3yjL3wvjM+aCyefepfuPVcaxDtJvYwF1/lCsrp6Xbr7a94MQyaLYZEX0SvAk4YhzD2a5yUeGlsvdkVaPgtZHUq0eAaQf0Hy/RR+/QTd3XuUOY7j2bYTjh193IzT4EBPdmwYTR8nvXdCu9ftDoDH/KXNuaQnfhSGGEZjsZt9T7TfHXtOp+f57MQvR3rfvnY5rFGEZrStufUuMvCz0fE983KVmY+4vfq+0m3Y9rPvLfhXoAWkJPzwCGl6+ZKCr+kbKJC01B7vFfpfw15n++7U/l5oe11fZQMZ/I2o/4dR7e8M/kb82/9l/I34/wD6yOVJcKQxwgAAAABJRU5ErkJggg==" 
                      alt="Vox Telecom Logo" 
                      className="w-28 h-auto mx-auto mb-4"
                    />
                    <p>
                      Telecommunications companies are among the most prolific users of predatory debt collection strategies. 
                      These companies send threatening SMS messages claiming breach of contracts that may not exist or have long expired.
                    </p>
                    <div className="mt-4 p-4 bg-white dark:bg-gray-700 rounded-md">
                      <h4 className="font-medium mb-2">Example SMS Fraud:</h4>
                      <p className="text-sm">
                        "RAMOBA, You are in breach of contract relating to your arrangement with Vox Telecom Account:9864438. 
                        Immediate cash payment required to have your account in good standing. Avoid escalation, Call 0871140000 
                        or reply to helpme@vericred.biz for assistance."
                      </p>
                    </div>
                    <div className="mt-4">
                      <h4 className="font-medium mb-2">Red Flags:</h4>
                      <ul className="list-disc pl-5 text-sm">
                        <li>Non-official domain names in email addresses</li>
                        <li>Pressure tactics demanding "immediate payment"</li>
                        <li>References to contracts that consumers don't recognize</li>
                        <li>Phone numbers not matching official company contact details</li>
                      </ul>
                    </div>
                  </div>
                </div>

                <div className="bg-yellow-50 dark:bg-yellow-900/20 p-6 rounded-lg mt-6">
                  <h3 className="text-xl font-semibold mb-4">Exploitative Leadership</h3>
                  <div className="flex flex-col gap-4">
                    <div className="flex flex-col md:flex-row gap-4">
                      <img 
                        src={ceoImagePath} 
                        alt="Jacques du Toit - CEO" 
                        className="w-full md:w-32 h-auto rounded-md"
                      />
                      <div>
                        <h4 className="font-medium">Jacques du Toit – CEO</h4>
                        <p className="text-sm mt-2">
                          Corporate executives who present a polished public image while their companies engage in 
                          exploitative practices against vulnerable South Africans. Their businesses profit from apartheid's 
                          economic legacy while publicly claiming corporate social responsibility.
                        </p>
                      </div>
                    </div>
                    <div className="mt-4">
                      <h4 className="font-medium mb-2">Common Corporate Tactics:</h4>
                      <ul className="list-disc pl-5 text-sm">
                        <li>Using debt collection agencies that employ intimidation tactics</li>
                        <li>Hidden fees and unclear terms in service contracts</li>
                        <li>Deliberately complicated cancellation procedures</li>
                        <li>Targeting areas with limited consumer protection awareness</li>
                      </ul>
                    </div>
                  </div>
                </div>

                <div className="bg-blue-50 dark:bg-blue-900/20 p-6 rounded-lg mt-6">
                  <h3 className="text-xl font-semibold mb-4">Financial Extraction Strategies</h3>
                  <p>
                    Companies employ various techniques to extract wealth from communities still suffering from 
                    the economic effects of apartheid:
                  </p>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                    <div className="bg-white dark:bg-gray-700 p-4 rounded-md">
                      <h4 className="font-medium mb-2">Debt Trapping</h4>
                      <p className="text-sm">
                        Offering easy credit with exorbitant interest rates or penalty terms specifically targeted at 
                        financially vulnerable communities with limited banking options.
                      </p>
                    </div>
                    <div className="bg-white dark:bg-gray-700 p-4 rounded-md">
                      <h4 className="font-medium mb-2">Information Asymmetry</h4>
                      <p className="text-sm">
                        Exploiting knowledge gaps about consumer rights, especially in areas with limited access 
                        to consumer protection resources or legal support.
                      </p>
                    </div>
                    <div className="bg-white dark:bg-gray-700 p-4 rounded-md">
                      <h4 className="font-medium mb-2">Hidden Fees</h4>
                      <p className="text-sm">
                        Adding multiple obscure charges in fine print that substantially increase the actual cost 
                        of services, knowing most consumers won't understand or challenge these fees.
                      </p>
                    </div>
                    <div className="bg-white dark:bg-gray-700 p-4 rounded-md">
                      <h4 className="font-medium mb-2">Aggressive Collection</h4>
                      <p className="text-sm">
                        Using threatening language, excessive calls, and other intimidation tactics to collect 
                        debts, often for amounts that have been artificially inflated.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="cases" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Case Studies</CardTitle>
              <CardDescription>Real examples of modern apartheid profiteering</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-8">
                <div className="bg-gray-100 dark:bg-gray-800 p-6 rounded-lg">
                  <h3 className="text-xl font-semibold mb-3">Case Study: Vox Telecom</h3>
                  <div className="prose prose-sm dark:prose-invert max-w-none">
                    <p>
                      Founded in 1998 (originally as Casey Investment Holdings, later known as DataPro Group), Vox Telecom has been implicated in numerous 
                      complaints regarding aggressive debt collection practices targeting vulnerable communities. Consumer 
                      reports indicate systemic issues with their business practices:
                    </p>
                    
                    <ul className="mt-3">
                      <li>
                        <strong>Fraudulent Debt Collection:</strong> Numerous reports of SMS and email messages claiming unpaid 
                        debts from people who never had accounts with the company
                      </li>
                      <li>
                        <strong>Third-party Collection Agencies:</strong> Use of collection agencies that employ intimidation 
                        tactics and threaten legal action without proper verification of debts
                      </li>
                      <li>
                        <strong>Data Exploitation:</strong> Allegations of purchasing old customer databases from other 
                        telecommunications companies and pursuing dated or settled accounts
                      </li>
                      <li>
                        <strong>Geographic Targeting:</strong> Disproportionate targeting of areas with historically 
                        disadvantaged populations and limited access to legal resources
                      </li>
                    </ul>
                    
                    <div className="mt-4 p-4 bg-blue-50 dark:bg-blue-900/10 rounded-md">
                      <h4 className="font-medium mb-2">Company Overview:</h4>
                      <p className="text-sm mb-2">
                        <strong>Headquarters:</strong> Rutherford Estate, 1 Scott Street, Waverley, Johannesburg, South Africa<br />
                        <strong>Employees:</strong> Approximately 1,500<br />
                        <strong>Industry:</strong> Telecommunications – offering voice, data, cloud, and collaboration services<br />
                        <strong>Ownership:</strong> Privately held, backed by private equity investors
                      </p>
                      
                      <h4 className="font-medium mt-3 mb-2">Leadership Team:</h4>
                      <ul className="text-sm list-disc pl-5">
                        <li>
                          <strong>Jacques du Toit – CEO:</strong> With over two decades in the telecoms industry, Jacques has been instrumental 
                          in steering Vox Telecom's strategic direction and growth.
                        </li>
                        <li>
                          <strong>Gert Koen – CFO:</strong> Gert brings extensive financial expertise, having managed audits for Vox Orion 
                          before ascending to the CFO role.
                        </li>
                        <li>
                          <strong>Abraham van der Merwe – Executive Director:</strong> Founder of Frogfoot Networks, Abraham has been pivotal 
                          in expanding Vox's fibre infrastructure.
                        </li>
                      </ul>
                    </div>
                    
                    <p className="mt-4">
                      <strong>Corporate Structure:</strong> Vox Telecom is privately owned, with significant backing from private equity firms 
                      including Rand Merchant Bank (RMB) Ventures, Investec, Lereko Metier Capital Growth Fund, and Ke Nako Capital. This ownership structure 
                      creates pressure for aggressive financial performance that often comes at the expense of ethical business practices.
                    </p>
                    
                    <div className="mt-4 p-4 bg-yellow-50 dark:bg-yellow-900/10 rounded-md">
                      <h4 className="font-medium mb-2">Company History & Expansion:</h4>
                      <ul className="text-sm list-disc pl-5">
                        <li>1998: Founded as Casey Investment Holdings, later known as DataPro Group</li>
                        <li>2005: Acquired @lantic, a significant move to expand its ISP services</li>
                        <li>2011: Received a R499 million buyout offer from shareholders, leading to delisting from the Johannesburg Stock Exchange</li>
                        <li>2014: Considered a sale but ultimately retained by existing shareholders, focusing on internal growth</li>
                        <li>2022: Rebranded as Vivica Group, reflecting a broader focus beyond traditional telecommunications</li>
                      </ul>
                    </div>
                    

                  </div>
                </div>
                
                <div className="bg-gray-100 dark:bg-gray-800 p-6 rounded-lg">
                  <h3 className="text-xl font-semibold mb-3">Systemic Issues in Telecommunications Industry</h3>
                  <div className="prose prose-sm dark:prose-invert max-w-none">
                    <p>
                      The telecommunications sector has become a prominent area for exploitative practices due to several factors:
                    </p>
                    
                    <ul className="mt-3">
                      <li>
                        <strong>Essential Service:</strong> Mobile and internet services are now essential utilities, creating 
                        dependence that companies can exploit
                      </li>
                      <li>
                        <strong>Complex Contracts:</strong> Service agreements with confusing terms and conditions that hide 
                        fees and make cancellation difficult
                      </li>
                      <li>
                        <strong>Regulatory Gaps:</strong> Insufficient enforcement of consumer protection laws in the 
                        telecommunications sector
                      </li>
                      <li>
                        <strong>Data Profiling:</strong> Use of consumer data to identify vulnerable targets for upselling, 
                        debt collection, or predatory services
                      </li>
                    </ul>
                    
                    <p className="mt-4">
                      These practices disproportionately affect communities still dealing with the economic consequences 
                      of apartheid, who often have fewer alternatives, limited access to legal support, and less knowledge 
                      of their consumer rights.
                    </p>
                    
                    <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="p-3 bg-white dark:bg-gray-700 rounded-md">
                        <h4 className="font-medium mb-1 text-sm">Geographic Disparities:</h4>
                        <p className="text-xs">
                          Research indicates that exploitative practices are 3.5x more common in historically 
                          disadvantaged areas compared to affluent neighborhoods.
                        </p>
                      </div>
                      <div className="p-3 bg-white dark:bg-gray-700 rounded-md">
                        <h4 className="font-medium mb-1 text-sm">Dispute Resolution:</h4>
                        <p className="text-xs">
                          Only 12% of consumers in historically disadvantaged areas successfully 
                          resolve billing disputes compared to 68% in affluent areas.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="defense" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Consumer Self-Defense</CardTitle>
              <CardDescription>Protecting yourself from corporate exploitation</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="prose prose-lg dark:prose-invert max-w-none">
                <p>
                  While systemic change is necessary to address the economic legacy of apartheid, individuals can 
                  take steps to protect themselves from corporate exploitation:
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 my-6">
                  <div className="bg-green-50 dark:bg-green-900/20 p-6 rounded-lg">
                    <h3 className="text-xl font-semibold mb-3">Know Your Rights</h3>
                    <ul className="list-disc pl-5 space-y-2">
                      <li>Familiarize yourself with the Consumer Protection Act (CPA)</li>
                      <li>Understand your right to dispute unrecognized debts</li>
                      <li>Know that debt collectors must verify any debt they attempt to collect</li>
                      <li>Learn about interest rate caps under the National Credit Act</li>
                      <li>Document all interactions with debt collectors and companies</li>
                    </ul>
                  </div>
                  <div className="bg-blue-50 dark:bg-blue-900/20 p-6 rounded-lg">
                    <h3 className="text-xl font-semibold mb-3">Identifying Fraud</h3>
                    <ul className="list-disc pl-5 space-y-2">
                      <li>Be skeptical of unexpected SMS or email demands for payment</li>
                      <li>Verify company contact information through official websites</li>
                      <li>Never provide personal information to unverified callers</li>
                      <li>Check for unofficial email domains or suspicious links</li>
                      <li>Request written verification of any claimed debt before discussing payment</li>
                    </ul>
                  </div>
                </div>

                <h3 className="text-xl font-semibold mt-6">Resources for Assistance</h3>
                <p>
                  If you believe you're being targeted by exploitative corporate practices, these resources can help:
                </p>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 my-6">
                  <div className="p-4 border rounded-lg">
                    <h4 className="font-semibold mb-2">National Consumer Commission</h4>
                    <p className="text-sm">Official government body handling consumer complaints</p>
                    <p className="text-sm mt-2"><strong>Contact:</strong> 012 428 7000</p>
                    <p className="text-sm"><strong>Website:</strong> www.thencc.gov.za</p>
                  </div>
                  <div className="p-4 border rounded-lg">
                    <h4 className="font-semibold mb-2">Legal Aid South Africa</h4>
                    <p className="text-sm">Free legal assistance for qualifying individuals</p>
                    <p className="text-sm mt-2"><strong>Contact:</strong> 0800 110 110</p>
                    <p className="text-sm"><strong>Website:</strong> www.legal-aid.co.za</p>
                  </div>
                  <div className="p-4 border rounded-lg">
                    <h4 className="font-semibold mb-2">Credit Ombud</h4>
                    <p className="text-sm">Resolves complaints about credit agreements and reports</p>
                    <p className="text-sm mt-2"><strong>Contact:</strong> 0861 662 837</p>
                    <p className="text-sm"><strong>Website:</strong> www.creditombud.org.za</p>
                  </div>
                </div>

                <h3 className="text-xl font-semibold mt-6">Community Action</h3>
                <p>
                  Individual action is important, but collective efforts are more effective at creating systemic change:
                </p>

                <ul className="list-disc pl-6 mt-4 space-y-2">
                  <li>
                    <strong>Share Information:</strong> Alert your community about fraudulent schemes and exploitative practices
                  </li>
                  <li>
                    <strong>Document Patterns:</strong> Record and share experiences to help identify systematic targeting
                  </li>
                  <li>
                    <strong>Support Advocacy:</strong> Join consumer rights organizations pushing for stronger protections
                  </li>
                  <li>
                    <strong>Collective Complaints:</strong> Group complaints to regulators often receive more attention
                  </li>
                  <li>
                    <strong>Media Exposure:</strong> Share stories with journalists to bring public attention to exploitative practices
                  </li>
                </ul>

                <div className="bg-yellow-50 dark:bg-yellow-900/20 p-6 rounded-lg mt-6">
                  <h3 className="text-xl font-semibold mb-3">Remember:</h3>
                  <p className="text-lg font-medium">
                    We are not survival tools for corporate profits. Exploitation thrives in silence and isolation. 
                    By understanding our rights, recognizing predatory tactics, and acting collectively, 
                    we can challenge systems that perpetuate economic apartheid.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default ModernFraudsters;