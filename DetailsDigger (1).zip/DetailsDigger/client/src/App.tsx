import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import CorporateDetail from "@/pages/CorporateDetail";
import CorporationsList from "@/pages/CorporationsList";
import InstitutionDetail from "@/pages/InstitutionDetail";
import InstitutionsList from "@/pages/InstitutionsList";
import YouthEmpowerment from "@/pages/YouthEmpowerment";
import ResourceDetail from "@/pages/ResourceDetail";
import CulturalPreservation from "@/pages/CulturalPreservation";
import ModernFraudsters from "@/pages/ModernFraudsters";
import TimelinePage from "@/pages/TimelinePage";
import About from "@/pages/About";
import Search from "@/pages/Search";
import Header from "@/components/layout/Header";
import MobileNavigation from "@/components/layout/MobileNavigation";

function Router() {
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      <div className="flex flex-1">
        <main className="flex-1 p-4 lg:p-8 pb-16 md:pb-8 w-full">
          <Switch>
            <Route path="/" component={ModernFraudsters} />
            <Route path="/home" component={Home} />
            <Route path="/timeline" component={TimelinePage} />
            <Route path="/corporations" component={CorporationsList} />
            <Route path="/corporations/:id" component={CorporateDetail} />
            <Route path="/institutions" component={InstitutionsList} />
            <Route path="/institutions/:id" component={InstitutionDetail} />
            <Route path="/resources/:id" component={ResourceDetail} />
            <Route path="/about" component={About} />
            <Route path="/search" component={Search} />
            <Route path="/youth-empowerment" component={YouthEmpowerment} />
            <Route path="/cultural-preservation" component={CulturalPreservation} />
            <Route path="/modern-fraudsters" component={ModernFraudsters} />
            <Route component={NotFound} />
          </Switch>
        </main>
      </div>
      <MobileNavigation />
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
