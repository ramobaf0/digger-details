import { 
  users, type User, type InsertUser,
  corporations, type Corporation, type InsertCorporation,
  institutions, type Institution, type InsertInstitution,
  timelineEvents, type TimelineEvent, type InsertTimelineEvent,
  resources, type Resource, type InsertResource
} from "@shared/schema";

// modify the interface with any CRUD methods
// you might need
export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Corporations
  getAllCorporations(): Promise<Corporation[]>;
  getCorporation(id: number): Promise<Corporation | undefined>;
  createCorporation(corporation: InsertCorporation): Promise<Corporation>;
  
  // Institutions
  getAllInstitutions(): Promise<Institution[]>;
  getInstitution(id: number): Promise<Institution | undefined>;
  createInstitution(institution: InsertInstitution): Promise<Institution>;
  
  // Timeline Events
  getAllTimelineEvents(): Promise<TimelineEvent[]>;
  getTimelineEvent(id: number): Promise<TimelineEvent | undefined>;
  createTimelineEvent(event: InsertTimelineEvent): Promise<TimelineEvent>;
  
  // Resources
  getAllResources(): Promise<Resource[]>;
  getResource(id: number): Promise<Resource | undefined>;
  createResource(resource: InsertResource): Promise<Resource>;
  
  // Search functionality
  search(query: string): Promise<{
    corporations: Corporation[];
    institutions: Institution[];
    resources: Resource[];
    timelineEvents: TimelineEvent[];
  }>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private corporationsStore: Map<number, Corporation>;
  private institutionsStore: Map<number, Institution>;
  private timelineEventsStore: Map<number, TimelineEvent>;
  private resourcesStore: Map<number, Resource>;
  
  private userCurrentId: number;
  private corporationCurrentId: number;
  private institutionCurrentId: number;
  private timelineEventCurrentId: number;
  private resourceCurrentId: number;

  constructor() {
    this.users = new Map();
    this.corporationsStore = new Map();
    this.institutionsStore = new Map();
    this.timelineEventsStore = new Map();
    this.resourcesStore = new Map();
    
    this.userCurrentId = 1;
    this.corporationCurrentId = 1;
    this.institutionCurrentId = 1;
    this.timelineEventCurrentId = 1;
    this.resourceCurrentId = 1;
    
    this.initializeData();
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userCurrentId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  // Corporation methods
  async getAllCorporations(): Promise<Corporation[]> {
    return Array.from(this.corporationsStore.values());
  }
  
  async getCorporation(id: number): Promise<Corporation | undefined> {
    return this.corporationsStore.get(id);
  }
  
  async createCorporation(insertCorporation: InsertCorporation): Promise<Corporation> {
    const id = this.corporationCurrentId++;
    const corporation: Corporation = { ...insertCorporation, id };
    this.corporationsStore.set(id, corporation);
    return corporation;
  }
  
  // Institution methods
  async getAllInstitutions(): Promise<Institution[]> {
    return Array.from(this.institutionsStore.values());
  }
  
  async getInstitution(id: number): Promise<Institution | undefined> {
    return this.institutionsStore.get(id);
  }
  
  async createInstitution(insertInstitution: InsertInstitution): Promise<Institution> {
    const id = this.institutionCurrentId++;
    const institution: Institution = { ...insertInstitution, id };
    this.institutionsStore.set(id, institution);
    return institution;
  }
  
  // Timeline Event methods
  async getAllTimelineEvents(): Promise<TimelineEvent[]> {
    return Array.from(this.timelineEventsStore.values());
  }
  
  async getTimelineEvent(id: number): Promise<TimelineEvent | undefined> {
    return this.timelineEventsStore.get(id);
  }
  
  async createTimelineEvent(insertEvent: InsertTimelineEvent): Promise<TimelineEvent> {
    const id = this.timelineEventCurrentId++;
    const event: TimelineEvent = { ...insertEvent, id };
    this.timelineEventsStore.set(id, event);
    return event;
  }
  
  // Resource methods
  async getAllResources(): Promise<Resource[]> {
    return Array.from(this.resourcesStore.values());
  }
  
  async getResource(id: number): Promise<Resource | undefined> {
    return this.resourcesStore.get(id);
  }
  
  async createResource(insertResource: InsertResource): Promise<Resource> {
    const id = this.resourceCurrentId++;
    const resource: Resource = { ...insertResource, id };
    this.resourcesStore.set(id, resource);
    return resource;
  }
  
  // Search functionality
  async search(query: string): Promise<{
    corporations: Corporation[];
    institutions: Institution[];
    resources: Resource[];
    timelineEvents: TimelineEvent[];
  }> {
    const lowercaseQuery = query.toLowerCase();
    
    const corporations = Array.from(this.corporationsStore.values()).filter(corp => 
      corp.name.toLowerCase().includes(lowercaseQuery) || 
      corp.industry.toLowerCase().includes(lowercaseQuery) ||
      corp.description.toLowerCase().includes(lowercaseQuery) ||
      corp.apartheidRole.toLowerCase().includes(lowercaseQuery) ||
      corp.post1994.toLowerCase().includes(lowercaseQuery)
    );
    
    const institutions = Array.from(this.institutionsStore.values()).filter(inst => 
      inst.name.toLowerCase().includes(lowercaseQuery) ||
      inst.description.toLowerCase().includes(lowercaseQuery) ||
      inst.historicalRole.toLowerCase().includes(lowercaseQuery) ||
      inst.currentImpact.toLowerCase().includes(lowercaseQuery)
    );
    
    const resources = Array.from(this.resourcesStore.values()).filter(res => 
      res.title.toLowerCase().includes(lowercaseQuery) ||
      res.description.toLowerCase().includes(lowercaseQuery) ||
      res.category.toLowerCase().includes(lowercaseQuery)
    );
    
    const timelineEvents = Array.from(this.timelineEventsStore.values()).filter(event => 
      event.title.toLowerCase().includes(lowercaseQuery) ||
      event.description.toLowerCase().includes(lowercaseQuery) ||
      event.category.toLowerCase().includes(lowercaseQuery)
    );
    
    return {
      corporations,
      institutions,
      resources,
      timelineEvents
    };
  }
  
  // Initialize sample data for the educational platform
  private initializeData() {
    // Initialize corporations data
    const corporationsData: InsertCorporation[] = [
      {
        name: "Anglo American",
        industry: "Mining (gold, diamonds, platinum)",
        description: "One of the world's largest mining companies, founded in South Africa in 1917, with significant operations in gold, diamonds, and platinum.",
        apartheidRole: "Exploited cheap Black labor under hazardous conditions. Partnered with the state in maintaining a racially exclusive economy.",
        post1994: "Remains a dominant player in the South African economy and global mining sector. Criticized for land degradation and limited transformation.",
        apartheidPractices: [
          "Utilized the migrant labor system that separated Black workers from their families",
          "Operated mines with hazardous conditions that led to high injury and death rates",
          "Paid Black workers a fraction of white workers' wages for the same work",
          "Supported government policies that displaced communities for mining operations"
        ],
        currentPractices: [
          "Continues to hold significant land through historical acquisitions",
          "Environmental impacts affect predominantly Black communities",
          "Leadership remains predominantly white despite some BEE initiatives",
          "Continues to extract resources with limited local beneficiation"
        ],
        economicImpact: {
          revenue: "$30+ billion annually",
          marketShare: "Dominant in platinum, significant in diamonds and other minerals",
          employees: "90,000+ globally",
          beeStatus: "Level 4 contributor"
        },
        resources: [
          {
            title: "Anglo American Annual Report",
            url: "https://www.angloamerican.com/investors/annual-reporting"
          },
          {
            title: "Mining and Apartheid: The Challenges of Transformation",
            url: "#research-paper"
          }
        ]
      },
      {
        name: "De Beers",
        industry: "Diamonds",
        description: "Founded in 1888, De Beers is a world leader in diamond exploration, mining, and marketing, with historical roots deeply embedded in South Africa.",
        apartheidRole: "Profited from forced removals and exploited Black miners. Aligned with apartheid labor policies.",
        post1994: "Maintains global dominance in diamond markets, rebranded but with unaddressed historical injustices.",
        apartheidPractices: [
          "Utilized migrant labor systems that separated Black workers from families",
          "Benefited from land appropriations that displaced indigenous communities",
          "Maintained segregated facilities and discriminatory promotion policies",
          "Collaborated with the apartheid government on diamond export strategies"
        ],
        currentPractices: [
          "Has undergone partial transformation but leadership remains predominantly white",
          "Continues to dominate the diamond sector with historic market advantages",
          "Limited reparations to communities displaced during apartheid",
          "Beneficiation initiatives criticized as inadequate"
        ],
        economicImpact: {
          revenue: "$5.8 billion annually",
          marketShare: "30% of global diamond market",
          employees: "20,000+ globally",
          beeStatus: "Level 3 contributor"
        },
        resources: [
          {
            title: "De Beers Corporate Responsibility Report",
            url: "https://www.debeersgroup.com/reports"
          },
          {
            title: "Diamonds, Development and Democracy",
            url: "#research-paper"
          }
        ]
      },
      {
        name: "Sasol",
        industry: "Petrochemicals",
        description: "Founded in 1950, Sasol is an integrated energy and chemical company that developed technology to produce synthetic fuels from coal and gas.",
        apartheidRole: "State-created to bypass sanctions; developed synthetic fuels. Received massive public subsidies.",
        post1994: "Profitable, yet criticized for environmental harm and poor corporate transformation.",
        apartheidPractices: [
          "Operated with significant state support as a sanctions-busting initiative",
          "Discriminatory employment practices with rigid racial hierarchies",
          "Developed coal-to-liquid fuel technology that extended apartheid's lifespan",
          "Built entire towns with segregated living conditions for workers"
        ],
        currentPractices: [
          "High carbon emissions affecting primarily disadvantaged communities",
          "Significant operations continue to benefit from apartheid-era infrastructure",
          "Criticized for slow pace of racial transformation in senior positions",
          "Limited environmental remediation in historically affected communities"
        ],
        economicImpact: {
          revenue: "$15+ billion annually",
          marketShare: "Dominant in synthetic fuels in South Africa",
          employees: "30,000+ globally",
          beeStatus: "Level 4 contributor"
        },
        resources: [
          {
            title: "Sasol Sustainability Report",
            url: "https://www.sasol.com/investor-centre/annual-reporting"
          },
          {
            title: "Fueling Apartheid: Oil and Gas Corporations",
            url: "#research-paper"
          }
        ]
      },
      {
        name: "Remgro (Rupert Family Holdings)",
        industry: "Finance, luxury goods, healthcare",
        description: "A major investment holding company controlled by the Rupert family, with significant interests across various sectors of the South African economy.",
        apartheidRole: "Benefited from racially exclusive markets. Close to National Party elites.",
        post1994: "Maintains a powerful economic presence, particularly in private healthcare and consumer goods.",
        apartheidPractices: [
          "Built business empire within protected white-only markets",
          "Had close political relationships with apartheid-era officials",
          "Operated in segregated business zones with preferential access",
          "Benefited from tax advantages available primarily to white businesses"
        ],
        currentPractices: [
          "Continues to hold significant investments across key economic sectors",
          "Limited Black ownership in core business operations",
          "Transformation primarily at superficial levels rather than ownership",
          "Benefits from historical accumulation of capital and land"
        ],
        economicImpact: {
          revenue: "$9+ billion annually (combined holdings)",
          marketShare: "Significant investments across multiple sectors",
          employees: "Variable across holdings",
          beeStatus: "Level 5 contributor"
        },
        resources: [
          {
            title: "Remgro Annual Report",
            url: "https://www.remgro.com/investor-relations/financial-results"
          },
          {
            title: "Wealth Accumulation Under Apartheid",
            url: "#research-paper"
          }
        ]
      },
      {
        name: "Naspers",
        industry: "Media, technology",
        description: "Founded in 1915 as a publisher, Naspers has evolved into a global internet and technology group with significant investments, including a major stake in Tencent.",
        apartheidRole: "Publisher of pro-apartheid propaganda. Tied ideologically to the regime.",
        post1994: "One of Africa's most valuable companies, facing calls for restitution and transformation.",
        apartheidPractices: [
          "Published newspapers that supported apartheid policies (Die Burger, Beeld)",
          "Maintained close connections with the National Party leadership",
          "Helped shape public opinion in favor of segregationist policies",
          "Benefited from government advertising and preferential treatment"
        ],
        currentPractices: [
          "Leveraged historical advantage to acquire global tech investments",
          "Limited acknowledgment of historical role in promoting apartheid",
          "Minimal reparations for role in supporting discriminatory systems",
          "Value primarily derived from Tencent investment rather than local operations"
        ],
        economicImpact: {
          revenue: "$29+ billion annually",
          marketShare: "Dominant in media through Media24 subsidiary",
          employees: "25,000+ globally",
          beeStatus: "Level 3 contributor"
        },
        resources: [
          {
            title: "Naspers Integrated Annual Report",
            url: "https://www.naspers.com/investors"
          },
          {
            title: "Media Power and Apartheid Propaganda",
            url: "#research-paper"
          }
        ]
      },
      {
        name: "Sanlam",
        industry: "Insurance, financial services",
        description: "Founded in 1918, Sanlam is one of South Africa's largest financial services groups, providing insurance, investment, and wealth management services.",
        apartheidRole: "Served only white populations; denied services to Black communities.",
        post1994: "Major player in finance, with limited structural change.",
        apartheidPractices: [
          "Originally established to promote Afrikaner economic empowerment",
          "Excluded Black South Africans from insurance and investment products",
          "Invested heavily in other apartheid-supporting businesses",
          "Maintained discriminatory hiring and promotion practices"
        ],
        currentPractices: [
          "Has undergone some transformation but historic advantages remain",
          "Limited redress for communities previously denied financial services",
          "Continues to benefit from monopoly-like position in certain markets",
          "Financial products still inaccessible to many previously disadvantaged groups"
        ],
        economicImpact: {
          revenue: "$10+ billion annually",
          marketShare: "One of the largest financial services providers in Africa",
          employees: "20,000+ across operations",
          beeStatus: "Level 2 contributor"
        },
        resources: [
          {
            title: "Sanlam Integrated Report",
            url: "https://www.sanlam.com/investors"
          },
          {
            title: "Financial Apartheid: Banking and Insurance",
            url: "#research-paper"
          }
        ]
      }
    ];
    
    // Initialize institutions data
    const institutionsData: InsertInstitution[] = [
      {
        name: "University of Pretoria",
        established: "1908",
        description: "One of South Africa's largest research universities, historically catering primarily to Afrikaner students during apartheid.",
        historicalRole: "Afrikaner nationalist hub. Educated many apartheid bureaucrats and ideologues.",
        currentImpact: "Still sends many graduates into the civil service and corporate South Africa with a Eurocentric outlook.",
        transformationStatus: "Moderate progress",
        areasOfInfluence: "Government, law, engineering",
        keyHistoricalFacts: [
          "Founded as an Afrikaans-medium institution with strong ties to Afrikaner nationalism",
          "Trained many civil servants who implemented apartheid policies",
          "Developed academic justifications for separate development theories",
          "Did not admit Black students until the late apartheid era"
        ],
        transformationChallenges: "Despite policy changes, the university continues to struggle with creating an inclusive environment. Language policies remain contentious, and faculty demographics don't reflect national demographics.",
        curriculumIssues: "Many academic programs continue to center European and American scholarship while marginalizing African knowledge systems and perspectives.",
        staffDiversity: "Academic staff remains predominantly white, especially at senior levels and in certain faculties like law and engineering.",
        infrastructure: "Modern facilities with significant resources, benefiting from decades of preferential funding during apartheid.",
        resources: [
          {
            title: "University of Pretoria History Project",
            url: "https://www.up.ac.za/about"
          },
          {
            title: "Educational Transformation in Post-Apartheid Universities",
            url: "#research-paper"
          }
        ]
      },
      {
        name: "Stellenbosch University",
        established: "1866",
        description: "One of South Africa's oldest universities and historically the intellectual center of Afrikaner nationalism and apartheid ideology.",
        historicalRole: "Known as the intellectual engine of apartheid. Influenced social, economic, and linguistic policies.",
        currentImpact: "Still struggles with transformation and has faced racism scandals. Remains influential in business and politics.",
        transformationStatus: "Limited progress",
        areasOfInfluence: "Politics, business, agriculture",
        keyHistoricalFacts: [
          "Considered the 'cradle of apartheid' where many apartheid theorists were educated",
          "Produced most of the National Party's prime ministers and cabinet members",
          "Developed 'volkekunde' (ethnology) that provided 'scientific' basis for racial separation",
          "Maintained Afrikaans-only instruction as a political stance"
        ],
        transformationChallenges: "The university has faced ongoing controversies regarding language policy, racial incidents, and campus culture. Progress in transforming institutional culture has been slow and contested.",
        curriculumIssues: "Decolonization of curriculum has been minimal in many departments, with continued emphasis on Western-centric approaches across disciplines.",
        staffDiversity: "Faculty remains predominantly white, with slowest transformation in senior academic and leadership positions.",
        infrastructure: "Extensive, well-maintained campus facilities developed through decades of preferential funding.",
        resources: [
          {
            title: "Stellenbosch University Transformation Office",
            url: "https://www.sun.ac.za/english/Pages/default.aspx"
          },
          {
            title: "Apartheid's Universities: Higher Education and Ideology",
            url: "#research-paper"
          }
        ]
      },
      {
        name: "University of Cape Town",
        established: "1829",
        description: "South Africa's oldest university and consistently ranked as Africa's top university, with a historically liberal reputation compared to other white institutions during apartheid.",
        historicalRole: "Though more liberal than other universities, it catered to elite white students and benefited from state support.",
        currentImpact: "Internationally acclaimed, but transformation remains slow—Black students and academics underrepresented in many disciplines.",
        transformationStatus: "Progressive but incomplete",
        areasOfInfluence: "Medicine, law, finance",
        keyHistoricalFacts: [
          "While more liberal than Afrikaans universities, still operated within the apartheid framework",
          "Admitted limited numbers of Black students in certain fields before most universities",
          "Had some faculty who opposed apartheid but institutional complicity remained",
          "Benefited from apartheid-era funding structures and preferential treatment"
        ],
        transformationChallenges: "Despite progressive policies, the university faces ongoing challenges with inclusivity, representation, and accessibility. The Rhodes Must Fall movement highlighted unresolved colonial legacies.",
        curriculumIssues: "Efforts to decolonize the curriculum vary widely between departments, with some progressive changes but persistent Eurocentric foundations.",
        staffDiversity: "While more diverse than some other historically white institutions, significant disparities remain at senior academic levels.",
        infrastructure: "Extensive resources and facilities, with historical advantages in research infrastructure and funding.",
        resources: [
          {
            title: "UCT Transformation Report",
            url: "https://www.uct.ac.za"
          },
          {
            title: "Rhodes Must Fall: Decolonization of South African Universities",
            url: "#research-paper"
          }
        ]
      },
      {
        name: "University of the Witwatersrand",
        established: "1896",
        description: "A leading research-intensive university in Johannesburg that had a reputation for some opposition to apartheid while still operating within its constraints.",
        historicalRole: "More progressive than others during apartheid, but still benefitted from white privilege and exclusion.",
        currentImpact: "Today it's a feeder school for private sector executives and policy-makers, with high fees and Westernized curricula.",
        transformationStatus: "Significant progress",
        areasOfInfluence: "Business, economics, media",
        keyHistoricalFacts: [
          "Known for some anti-apartheid activism among students and faculty",
          "Still maintained racially exclusionary practices despite liberal reputation",
          "Admitted a small number of Black students in certain fields earlier than other universities",
          "Benefited from apartheid economic structure despite institutional criticism"
        ],
        transformationChallenges: "While making progress in representation, challenges remain in addressing financial accessibility, institutional culture, and structural inequalities.",
        curriculumIssues: "Some departments have embraced curriculum transformation while others maintain traditional Western-focused approaches and canons.",
        staffDiversity: "Improved diversity at junior levels but senior faculty and leadership positions show slower transformation.",
        infrastructure: "Well-resourced campus with significant research facilities and historical funding advantages.",
        resources: [
          {
            title: "Wits Transformation and Employment Equity",
            url: "https://www.wits.ac.za"
          },
          {
            title: "Urban Universities and Social Change in South Africa",
            url: "#research-paper"
          }
        ]
      }
    ];
    
    // Initialize timeline events data
    const timelineEventsData: InsertTimelineEvent[] = [
      {
        year: 1948,
        title: "Apartheid Begins",
        description: "National Party wins election and begins implementing formal apartheid policies.",
        category: "political",
        linkedCorporations: [1, 2, 5],
        linkedInstitutions: [1, 2],
        furtherReading: [
          {
            title: "The Rise of Apartheid",
            url: "#history-resource"
          }
        ]
      },
      {
        year: 1950,
        title: "Group Areas Act",
        description: "Legislation to segregate different racial groups into different residential and business sections in urban areas.",
        category: "legal",
        linkedCorporations: [1, 2, 4],
        linkedInstitutions: [],
        furtherReading: [
          {
            title: "Forced Removals and Urban Planning",
            url: "#history-resource"
          }
        ]
      },
      {
        year: 1953,
        title: "Bantu Education Act",
        description: "Created separate and inferior education system for Black South Africans, designed to prepare them for subordinate roles.",
        category: "educational",
        linkedCorporations: [],
        linkedInstitutions: [1, 2, 3, 4],
        furtherReading: [
          {
            title: "Educational Apartheid and Its Legacy",
            url: "#education-resource"
          }
        ]
      },
      {
        year: 1960,
        title: "Sharpeville Massacre",
        description: "Police kill 69 people during peaceful protest against pass laws. State of emergency declared.",
        category: "political",
        linkedCorporations: [],
        linkedInstitutions: [],
        furtherReading: [
          {
            title: "Sharpeville: A Turning Point",
            url: "#history-resource"
          }
        ]
      },
      {
        year: 1964,
        title: "Rivonia Trial",
        description: "Nelson Mandela and other ANC leaders sentenced to life imprisonment. Increased international attention on apartheid.",
        category: "political",
        linkedCorporations: [],
        linkedInstitutions: [],
        furtherReading: [
          {
            title: "The Rivonia Trial and International Response",
            url: "#history-resource"
          }
        ]
      },
      {
        year: 1970,
        title: "Black Consciousness Movement",
        description: "Steve Biko leads movement emphasizing Black pride, self-reliance, and psychological liberation.",
        category: "cultural",
        linkedCorporations: [],
        linkedInstitutions: [4],
        furtherReading: [
          {
            title: "Black Consciousness and Self-Reliance",
            url: "#cultural-resource"
          }
        ]
      },
      {
        year: 1976,
        title: "Soweto Uprising",
        description: "Students protest against Afrikaans as medium of instruction. Corporate investments face international scrutiny.",
        category: "educational",
        linkedCorporations: [1, 2, 3, 5],
        linkedInstitutions: [1, 2],
        furtherReading: [
          {
            title: "June 16th and Its Aftermath",
            url: "#history-resource"
          }
        ]
      },
      {
        year: 1980,
        title: "Sanctions Era Begins",
        description: "International sanctions pressure South African regime. Many companies develop workarounds.",
        category: "economic",
        linkedCorporations: [1, 2, 3, 4, 5, 6],
        linkedInstitutions: [],
        furtherReading: [
          {
            title: "Corporate Responses to Sanctions",
            url: "#economic-resource"
          }
        ]
      },
      {
        year: 1985,
        title: "Sasol Expansion",
        description: "Government expands synthetic fuel investments to counter oil sanctions, creating environmental impacts on Black communities.",
        category: "economic",
        linkedCorporations: [3],
        linkedInstitutions: [],
        furtherReading: [
          {
            title: "Sanctions Busting and Environmental Justice",
            url: "#economic-resource"
          }
        ]
      },
      {
        year: 1989,
        title: "Corporate Disinvestment Peak",
        description: "Over 200 U.S. companies have left South Africa. Some sell to local management, maintaining de facto control.",
        category: "economic",
        linkedCorporations: [1, 2, 4, 6],
        linkedInstitutions: [],
        furtherReading: [
          {
            title: "Disinvestment: Real Change or Window Dressing?",
            url: "#economic-resource"
          }
        ]
      },
      {
        year: 1990,
        title: "Mandela Released",
        description: "Nelson Mandela freed after 27 years. Negotiations for democratic transition begin.",
        category: "political",
        linkedCorporations: [],
        linkedInstitutions: [],
        furtherReading: [
          {
            title: "The Road to Democracy",
            url: "#history-resource"
          }
        ]
      },
      {
        year: 1994,
        title: "Democratic Transition",
        description: "First democratic elections. Nelson Mandela becomes president. Corporate structures remain largely intact.",
        category: "political",
        linkedCorporations: [1, 2, 3, 4, 5, 6],
        linkedInstitutions: [1, 2, 3, 4],
        furtherReading: [
          {
            title: "Democracy and Economic Continuity",
            url: "#political-resource"
          }
        ]
      },
      {
        year: 1996,
        title: "Truth and Reconciliation Commission",
        description: "Commission established to investigate human rights abuses. Limited corporate accountability.",
        category: "legal",
        linkedCorporations: [1, 2, 3, 5],
        linkedInstitutions: [],
        furtherReading: [
          {
            title: "Corporate Accountability and Reconciliation",
            url: "#legal-resource"
          }
        ]
      },
      {
        year: 2004,
        title: "Black Economic Empowerment",
        description: "Formalized BEE policies to increase Black participation in economy. Critics cite elite enrichment rather than broad transformation.",
        category: "economic",
        linkedCorporations: [1, 2, 3, 4, 5, 6],
        linkedInstitutions: [],
        furtherReading: [
          {
            title: "Evaluating BEE: Success or Failure?",
            url: "#economic-resource"
          }
        ]
      },
      {
        year: 2015,
        title: "Rhodes Must Fall Movement",
        description: "Student protests calling for decolonization of education and removal of colonial symbols. Highlights continued institutional racism.",
        category: "educational",
        linkedCorporations: [],
        linkedInstitutions: [3, 4],
        furtherReading: [
          {
            title: "Student Movements and Decolonization",
            url: "#educational-resource"
          }
        ]
      },
      {
        year: 2023,
        title: "Present Day",
        description: "Economic inequality persists. Corporations and institutions that benefited from apartheid continue to hold dominant positions.",
        category: "economic",
        linkedCorporations: [1, 2, 3, 4, 5, 6],
        linkedInstitutions: [1, 2, 3, 4],
        furtherReading: [
          {
            title: "Apartheid's Economic Legacy Today",
            url: "#economic-resource"
          }
        ]
      }
    ];
    
    // Initialize resources data
    const resourcesData: InsertResource[] = [
      {
        title: "Community Education Toolkit",
        description: "Resources for starting community history classes, study groups, and knowledge-sharing networks outside formal institutions.",
        category: "education",
        icon: '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-book-open"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></svg>',
        files: [
          {
            id: "ce1",
            name: "Facilitation Guide (PDF)",
            type: "pdf",
            description: "Step-by-step guide for setting up community education programs"
          },
          {
            id: "ce2",
            name: "Presentation Templates",
            type: "presentation",
            description: "Customizable slide decks on various historical and economic topics"
          },
          {
            id: "ce3",
            name: "Video Learning Series",
            type: "video",
            description: "Downloadable video modules on apartheid history and legacy"
          }
        ],
        useInstructions: "This toolkit is designed for community educators, activists, and organizers who want to create independent educational spaces. The materials can be adapted for different age groups and contexts.",
        useCases: [
          {
            title: "Weekly History Circle",
            description: "Regular community meetings to discuss historical topics and their contemporary relevance."
          },
          {
            title: "Youth Education Program",
            description: "After-school programs focusing on history not covered in mainstream curriculum."
          },
          {
            title: "Elder Oral History Project",
            description: "Recording and preserving community memories and experiences."
          },
          {
            title: "Teacher Resource Network",
            description: "Supporting educators in mainstream institutions who want to supplement curriculum."
          }
        ],
        implementationSteps: [
          {
            title: "Community Needs Assessment",
            description: "Survey local community to identify specific educational gaps and interests."
          },
          {
            title: "Resource Team Formation",
            description: "Assemble a diverse team of educators, historians, and community members."
          },
          {
            title: "Curriculum Development",
            description: "Adapt materials to local context and specific learning objectives."
          },
          {
            title: "Facilitation Training",
            description: "Prepare community educators to lead discussions and activities effectively."
          },
          {
            title: "Program Launch",
            description: "Start with pilot sessions and gather feedback for improvement."
          }
        ],
        relatedResources: [
          {
            id: 2,
            title: "Economic Initiative Platform",
            description: "Tools for community economic development and cooperation."
          },
          {
            id: 3,
            title: "Advocacy & Policy Tools",
            description: "Resources for organizing and advocating for systemic change."
          }
        ]
      },
      {
        title: "Economic Initiative Platform",
        description: "Tools for creating community-based economic structures, cooperatives, and local trade networks independent of legacy corporations.",
        category: "economic",
        icon: '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-bar-chart"><line x1="12" x2="12" y1="20" y2="10"/><line x1="18" x2="18" y1="20" y2="4"/><line x1="6" x2="6" y1="20" y2="16"/></svg>',
        files: [
          {
            id: "ei1",
            name: "Cooperative Guide (PDF)",
            type: "pdf",
            description: "Comprehensive guide to establishing community cooperatives"
          },
          {
            id: "ei2",
            name: "Financial Planning Tools",
            type: "pdf",
            description: "Budgeting, planning, and sustainability worksheets"
          },
          {
            id: "ei3",
            name: "Partnership Templates",
            type: "pdf",
            description: "Legal frameworks for community economic partnerships"
          }
        ],
        useInstructions: "This platform provides practical tools for communities seeking economic self-reliance through cooperative structures, community-owned enterprises, and local exchange systems.",
        useCases: [
          {
            title: "Community Savings Cooperative",
            description: "Pooled community resources for internal lending and investment."
          },
          {
            title: "Local Producer Network",
            description: "Coordinated production and distribution of essential goods."
          },
          {
            title: "Skills Exchange System",
            description: "Platform for trading services within communities without currency."
          },
          {
            title: "Cooperative Land Trust",
            description: "Collective land ownership for housing, agriculture, or business."
          }
        ],
        implementationSteps: [
          {
            title: "Economic Mapping",
            description: "Identify community assets, skills, resources, and economic needs."
          },
          {
            title: "Legal Structure Selection",
            description: "Choose appropriate legal framework for community economic initiative."
          },
          {
            title: "Governance Design",
            description: "Establish democratic decision-making processes for the initiative."
          },
          {
            title: "Resource Mobilization",
            description: "Gather necessary startup resources and community commitments."
          },
          {
            title: "Operations Planning",
            description: "Develop practical systems for day-to-day functioning and growth."
          }
        ],
        relatedResources: [
          {
            id: 1,
            title: "Community Education Toolkit",
            description: "Educational resources to support economic literacy and skills."
          },
          {
            id: 3,
            title: "Advocacy & Policy Tools",
            description: "Resources for advocating for supportive economic policies."
          }
        ]
      },
      {
        title: "Advocacy & Policy Tools",
        description: "Resources for organizing campaigns, drafting policy proposals, and advocating for systemic change and reparative justice.",
        category: "advocacy",
        icon: '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-scale"><path d="m16 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z"/><path d="m2 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z"/><path d="M7 21h10"/><path d="M12 3v18"/><path d="M3 7h2c2 0 5-1 7-2 2 1 5 2 7 2h2"/></svg>',
        files: [
          {
            id: "ap1",
            name: "Policy Template Kit (PDF)",
            type: "pdf",
            description: "Frameworks for drafting evidence-based policy proposals"
          },
          {
            id: "ap2",
            name: "Campaign Strategy Guide",
            type: "pdf",
            description: "Comprehensive guide to organizing effective advocacy campaigns"
          },
          {
            id: "ap3",
            name: "Community Organizing Manual",
            type: "pdf",
            description: "Methods for building grassroots support and mobilization"
          }
        ],
        useInstructions: "These tools are designed for community activists, policy advocates, and grassroots organizations seeking to advance systemic change and accountability for historical injustices.",
        useCases: [
          {
            title: "Corporate Accountability Campaign",
            description: "Organizing to pressure apartheid profiteers for reparations and transformation."
          },
          {
            title: "Policy Reform Initiative",
            description: "Developing and advocating for legislative changes to address systemic inequality."
          },
          {
            title: "Truth and Justice Documentation",
            description: "Collecting evidence of corporate and institutional complicity in apartheid."
          },
          {
            title: "Community Rights Defense",
            description: "Protecting communities from ongoing harmful corporate practices."
          }
        ],
        implementationSteps: [
          {
            title: "Issue Analysis",
            description: "Research and document specific focus areas for advocacy."
          },
          {
            title: "Stakeholder Mapping",
            description: "Identify decision-makers, allies, and potential opposition."
          },
          {
            title: "Strategy Development",
            description: "Create comprehensive plan with clear goals and tactics."
          },
          {
            title: "Coalition Building",
            description: "Form alliances with aligned organizations and communities."
          },
          {
            title: "Public Engagement",
            description: "Develop materials and approaches for public education and mobilization."
          }
        ],
        relatedResources: [
          {
            id: 1,
            title: "Community Education Toolkit",
            description: "Educational resources to support advocacy awareness."
          },
          {
            id: 2,
            title: "Economic Initiative Platform",
            description: "Tools for building economic alternatives while advocating for change."
          },
          {
            id: 4,
            title: "Cultural Preservation Resources",
            description: "Tools for preserving indigenous knowledge and cultural heritage."
          }
        ]
      },
      {
        title: "Cultural Preservation Resources",
        description: "Comprehensive tools for documenting, preserving, and revitalizing indigenous knowledge systems, languages, and cultural practices that were suppressed during apartheid.",
        category: "cultural",
        icon: '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-landmark"><line x1="3" x2="21" y1="22" y2="22"/><line x1="6" x2="6" y1="18" y2="22"/><line x1="18" x2="18" y1="18" y2="22"/><line x1="12" x2="12" y1="18" y2="22"/><path d="M12 2v4"/><path d="m4.93 10.93 1.41 1.41"/><path d="M20 12h-4"/><path d="M12 20v-4"/><path d="m19.07 10.93-1.41 1.41"/><path d="M4 12h4"/><path d="m17.66 10.59-5.66 5.66-5.66-5.66 5.66-5.66 5.66 5.66Z"/></svg>',
        files: [
          {
            id: "cp1",
            name: "Language Documentation Guide",
            type: "pdf",
            description: "Methodologies for documenting and preserving indigenous languages"
          },
          {
            id: "cp2",
            name: "Cultural Knowledge Systems Archive",
            type: "pdf",
            description: "Templates for documenting traditional knowledge and practices"
          },
          {
            id: "cp3",
            name: "Digital Preservation Toolkit",
            type: "pdf",
            description: "Tools for digitizing and preserving cultural artifacts and oral histories"
          },
          {
            id: "cp4",
            name: "Community Cultural Center Blueprint",
            type: "pdf",
            description: "Models for establishing local cultural preservation centers"
          }
        ],
        useInstructions: "These resources are designed for community elders, cultural practitioners, educators, and activists working to reclaim, preserve, and revitalize cultural knowledge that was systematically suppressed during apartheid.",
        useCases: [
          {
            title: "Language Revitalization Program",
            description: "Curriculum and methods for teaching endangered indigenous languages."
          },
          {
            title: "Oral History Archive",
            description: "Documenting elders' testimonies, stories, and cultural knowledge."
          },
          {
            title: "Traditional Knowledge Database",
            description: "Cataloging indigenous knowledge systems, including medicinal practices."
          },
          {
            title: "Cultural Arts Revival",
            description: "Reintroducing traditional arts, music, and performance practices."
          }
        ],
        implementationSteps: [
          {
            title: "Cultural Asset Mapping",
            description: "Inventory existing cultural resources, knowledge holders, and practices."
          },
          {
            title: "Documentation Methodology",
            description: "Develop appropriate and respectful approaches to knowledge documentation."
          },
          {
            title: "Preservation Structure",
            description: "Create physical and digital archives with appropriate access protocols."
          },
          {
            title: "Intergenerational Transmission",
            description: "Establish programs for knowledge transfer between generations."
          },
          {
            title: "Public Engagement",
            description: "Develop educational materials and community celebration of cultural heritage."
          }
        ],
        relatedResources: [
          {
            id: 1,
            title: "Community Education Toolkit",
            description: "Educational approaches that can incorporate cultural heritage learning."
          },
          {
            id: 3,
            title: "Advocacy & Policy Tools",
            description: "Resources for advocating for recognition and protection of cultural rights."
          }
        ]
      }
    ];
    
    // Save all data to the storage
    corporationsData.forEach(corp => {
      const corporation: Corporation = { ...corp, id: this.corporationCurrentId++ };
      this.corporationsStore.set(corporation.id, corporation);
    });
    
    institutionsData.forEach(inst => {
      const institution: Institution = { ...inst, id: this.institutionCurrentId++ };
      this.institutionsStore.set(institution.id, institution);
    });
    
    timelineEventsData.forEach(event => {
      const timelineEvent: TimelineEvent = { ...event, id: this.timelineEventCurrentId++ };
      this.timelineEventsStore.set(timelineEvent.id, timelineEvent);
    });
    
    resourcesData.forEach(res => {
      const resource: Resource = { ...res, id: this.resourceCurrentId++ };
      this.resourcesStore.set(resource.id, resource);
    });
  }
}

export const storage = new MemStorage();
