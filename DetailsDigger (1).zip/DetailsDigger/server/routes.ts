import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import path from "path";
import fs from "fs";

export async function registerRoutes(app: Express): Promise<Server> {
  // Corporations API
  app.get("/api/corporations", async (req, res) => {
    try {
      const corporations = await storage.getAllCorporations();
      res.json(corporations);
    } catch (error) {
      res.status(500).json({ message: "Error fetching corporations", error });
    }
  });

  app.get("/api/corporations/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }

      const corporation = await storage.getCorporation(id);
      if (!corporation) {
        return res.status(404).json({ message: "Corporation not found" });
      }

      res.json(corporation);
    } catch (error) {
      res.status(500).json({ message: "Error fetching corporation", error });
    }
  });

  // Institutions API
  app.get("/api/institutions", async (req, res) => {
    try {
      const institutions = await storage.getAllInstitutions();
      res.json(institutions);
    } catch (error) {
      res.status(500).json({ message: "Error fetching institutions", error });
    }
  });

  app.get("/api/institutions/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }

      const institution = await storage.getInstitution(id);
      if (!institution) {
        return res.status(404).json({ message: "Institution not found" });
      }

      res.json(institution);
    } catch (error) {
      res.status(500).json({ message: "Error fetching institution", error });
    }
  });

  // Timeline API
  app.get("/api/timeline", async (req, res) => {
    try {
      const events = await storage.getAllTimelineEvents();
      res.json(events);
    } catch (error) {
      res.status(500).json({ message: "Error fetching timeline events", error });
    }
  });

  app.get("/api/timeline/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }

      const event = await storage.getTimelineEvent(id);
      if (!event) {
        return res.status(404).json({ message: "Timeline event not found" });
      }

      res.json(event);
    } catch (error) {
      res.status(500).json({ message: "Error fetching timeline event", error });
    }
  });

  // Resources API
  app.get("/api/resources", async (req, res) => {
    try {
      const resources = await storage.getAllResources();
      res.json(resources);
    } catch (error) {
      res.status(500).json({ message: "Error fetching resources", error });
    }
  });

  app.get("/api/resources/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }

      const resource = await storage.getResource(id);
      if (!resource) {
        return res.status(404).json({ message: "Resource not found" });
      }

      res.json(resource);
    } catch (error) {
      res.status(500).json({ message: "Error fetching resource", error });
    }
  });

  // Resource download endpoint - this would typically generate a PDF or serve a file
  app.get("/api/resources/download/:resourceId/:fileId", async (req, res) => {
    try {
      const resourceId = parseInt(req.params.resourceId);
      const fileId = req.params.fileId;
      
      if (isNaN(resourceId)) {
        return res.status(400).json({ message: "Invalid resource ID format" });
      }

      const resource = await storage.getResource(resourceId);
      if (!resource) {
        return res.status(404).json({ message: "Resource not found" });
      }

      // Handle resource files with proper type checking
      if (!resource.files || !Array.isArray(resource.files)) {
        return res.status(404).json({ message: "Resource files not found" });
      }
      
      const file = resource.files.find((f: any) => f.id === fileId);
      if (!file) {
        return res.status(404).json({ message: "File not found" });
      }

      // In a real app, this would serve an actual file or generate a PDF
      // For this demo, we'll create a simple text response
      res.setHeader('Content-Type', 'text/plain');
      res.setHeader('Content-Disposition', `attachment; filename="${file.name}"`);
      res.send(`This is a placeholder for ${file.name} from the ${resource.title} resource.

Content would typically include:
- Educational materials about apartheid history
- Information about corporate profiteers
- Self-reliance resources for communities
- Implementation guides and methodologies
      `);
    } catch (error) {
      res.status(500).json({ message: "Error downloading resource", error });
    }
  });

  // Search API
  app.get("/api/search", async (req, res) => {
    try {
      const query = z.string().min(1).parse(req.query.q);
      
      const results = await storage.search(query);
      res.json(results);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid search query", error });
      }
      res.status(500).json({ message: "Error performing search", error });
    }
  });



  const httpServer = createServer(app);

  return httpServer;
}
