import { pgTable, text, serial, integer, jsonb, date, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema (keeping the original)
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Corporation schema
export const corporations = pgTable("corporations", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  industry: text("industry").notNull(),
  description: text("description").notNull(),
  apartheidRole: text("apartheid_role").notNull(),
  post1994: text("post_1994").notNull(),
  apartheidPractices: jsonb("apartheid_practices").notNull(),
  currentPractices: jsonb("current_practices").notNull(),
  economicImpact: jsonb("economic_impact"),
  resources: jsonb("resources"),
});

export const insertCorporationSchema = createInsertSchema(corporations).pick({
  name: true,
  industry: true,
  description: true,
  apartheidRole: true,
  post1994: true,
  apartheidPractices: true,
  currentPractices: true,
  economicImpact: true,
  resources: true,
});

export type InsertCorporation = z.infer<typeof insertCorporationSchema>;
export type Corporation = typeof corporations.$inferSelect;

// Institution schema
export const institutions = pgTable("institutions", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  established: text("established").notNull(),
  description: text("description").notNull(),
  historicalRole: text("historical_role").notNull(),
  currentImpact: text("current_impact").notNull(),
  transformationStatus: text("transformation_status").notNull(),
  areasOfInfluence: text("areas_of_influence").notNull(),
  keyHistoricalFacts: jsonb("key_historical_facts"),
  transformationChallenges: text("transformation_challenges"),
  curriculumIssues: text("curriculum_issues"),
  staffDiversity: text("staff_diversity"),
  infrastructure: text("infrastructure"),
  resources: jsonb("resources"),
});

export const insertInstitutionSchema = createInsertSchema(institutions).pick({
  name: true,
  established: true,
  description: true,
  historicalRole: true,
  currentImpact: true,
  transformationStatus: true,
  areasOfInfluence: true,
  keyHistoricalFacts: true,
  transformationChallenges: true,
  curriculumIssues: true,
  staffDiversity: true,
  infrastructure: true,
  resources: true,
});

export type InsertInstitution = z.infer<typeof insertInstitutionSchema>;
export type Institution = typeof institutions.$inferSelect;

// Timeline schema
export const timelineEvents = pgTable("timeline_events", {
  id: serial("id").primaryKey(),
  year: integer("year").notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(),
  linkedCorporations: jsonb("linked_corporations"),
  linkedInstitutions: jsonb("linked_institutions"),
  furtherReading: jsonb("further_reading"),
});

export const insertTimelineEventSchema = createInsertSchema(timelineEvents).pick({
  year: true,
  title: true,
  description: true,
  category: true,
  linkedCorporations: true,
  linkedInstitutions: true,
  furtherReading: true,
});

export type InsertTimelineEvent = z.infer<typeof insertTimelineEventSchema>;
export type TimelineEvent = typeof timelineEvents.$inferSelect;

// Resource schema
export const resources = pgTable("resources", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(),
  icon: text("icon").notNull(),
  files: jsonb("files").notNull(),
  useInstructions: text("use_instructions"),
  useCases: jsonb("use_cases"),
  implementationSteps: jsonb("implementation_steps"),
  relatedResources: jsonb("related_resources"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertResourceSchema = createInsertSchema(resources).pick({
  title: true,
  description: true,
  category: true,
  icon: true,
  files: true,
  useInstructions: true,
  useCases: true,
  implementationSteps: true,
  relatedResources: true,
});

export type InsertResource = z.infer<typeof insertResourceSchema>;
export type Resource = typeof resources.$inferSelect;
